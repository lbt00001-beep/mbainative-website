@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo Deteniendo Restaurador Super 8 (procesos, terminales y puerto 8765)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\detener.ps1" -Puerto 8765
echo Hecho.
timeout /t 3 >nul
endlocal
