@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
title Restaurador Super 8 - arrancando
cd /d "%~dp0"
set "APP=%~dp0"
set "PUERTO=8765"
set "RESTAURA8_PUERTO=%PUERTO%"
if not exist "run\trabajos" mkdir "run\trabajos"

rem --- Contador de ejecuciones: a partir de la segunda se cierra la anterior ---
set "N=0"
if exist "run\ejecuciones.txt" set /p N=<"run\ejecuciones.txt"
set /a N=N+1 2>nul
if !N! LSS 1 set "N=1"
> "run\ejecuciones.txt" echo !N!

echo.
echo  ==============================================
echo    Restaurador Super 8 / 8 mm   (ejecucion !N!)
echo  ==============================================
echo.
if !N! GTR 1 (
  echo [1/4] Cerrando la ejecucion anterior: procesos, terminales y puerto %PUERTO%...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%APP%scripts\detener.ps1" -Puerto %PUERTO% -RegistrarConsola
) else (
  echo [1/4] Primera ejecucion: no hay nada que cerrar.
  powershell -NoProfile -ExecutionPolicy Bypass -File "%APP%scripts\detener.ps1" -Puerto %PUERTO% -SoloRegistrar
)
title RESTAURA8_SRV Restaurador Super 8

echo.
echo [2/4] Comprobando la instalacion. La primera vez descarga dependencias
echo       (PyTorch con CUDA, FFmpeg, RIFE y Real-ESRGAN) y puede tardar bastante.
powershell -NoProfile -ExecutionPolicy Bypass -Command "& '%APP%scripts\instalar.ps1' *>&1 | Tee-Object -FilePath '%APP%run\instalacion.txt'"
if errorlevel 1 (
  echo.
  echo ERROR durante la instalacion. Revisa los mensajes anteriores.
  echo El detalle tambien esta en run\instalacion.txt
  pause
  exit /b 1
)
if exist "%APP%herramientas\rutas.cmd" call "%APP%herramientas\rutas.cmd"

echo.
echo [3/4] El navegador se abrira cuando el servidor este listo.
start "" /b powershell -NoProfile -ExecutionPolicy Bypass -File "%APP%scripts\abrir_navegador.ps1" -Puerto %PUERTO%

echo [4/4] App en http://127.0.0.1:%PUERTO%
echo       Cierra esta ventana para detenerla. Si vuelves a ejecutar EJECUTAR.bat,
echo       esta ventana y sus procesos se cerraran automaticamente.
echo.
"%APP%.venv\Scripts\python.exe" "%APP%servidor.py"
set "RC=!errorlevel!"
if exist "%APP%run\servidor.pid" del /q "%APP%run\servidor.pid" >nul 2>&1
if not "!RC!"=="0" (
  echo.
  echo El servidor se detuvo con codigo !RC!. El detalle esta en run\servidor_log.txt
  pause
)
endlocal
