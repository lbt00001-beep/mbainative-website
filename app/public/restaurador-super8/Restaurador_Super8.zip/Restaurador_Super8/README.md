# Restaurador Super 8 / 8 mm

Aplicación local para restaurar películas de 8 mm y Super 8 ya digitalizadas, con aceleración
por GPU NVIDIA (RTX). Se usa desde el navegador, pero todo se procesa en tu equipo.

## Arranque

1. Doble clic en **EJECUTAR.bat**.
2. La primera vez se instala todo lo necesario. Puede tardar entre 10 y 30 minutos y descarga unos 3–4 GB:
   - Python 3.12 (con winget, si no lo tienes);
   - numpy, OpenCV, FastAPI y PyTorch con CUDA;
   - FFmpeg, RIFE y Real-ESRGAN (versiones Vulkan, en `herramientas\`).
3. Se abre el navegador en http://127.0.0.1:8765.

A partir de la **segunda ejecución**, EJECUTAR.bat cierra antes la ejecución anterior:

- la terminal anterior;
- el servidor y los trabajos en curso;
- lo que ocupe el puerto 8765;
- los procesos que queden de la app (python, ffmpeg, RIFE, Real-ESRGAN).

Nunca cierra la terminal desde la que se lanza. **DETENER.bat** cierra todo sin volver a arrancar.

## Uso

1. **Vídeo:** arrastra el archivo o pega su ruta. Con la ruta no se copia, que es mejor para archivos grandes.
2. **Diagnóstico:** detecta la cadencia de rodaje, los duplicados, el entrelazado, el recorte, el ruido, el polvo, el parpadeo y la dominante de color. Después carga una receta propuesta.
3. **Ajustes:** elige un preajuste (Archivo fiel, Equilibrado o Máximo realce) y retoca lo que quieras. En "Receta completa (JSON)" están todos los parámetros.
4. **Procesar:**
   - *Procesar muestra* hace 3–30 s y genera un vídeo con el original y el restaurado lado a lado.
   - *Procesar vídeo completo* genera el máster y la copia mejorada.

Los resultados se guardan en `resultados\` (las muestras, en `resultados\muestras\`):

- `*_master.mkv`: máster fiel (FFV1 sin pérdida, cadencia de rodaje, resolución original).
- `*_mejorado.mp4`: copia interpolada, escalada y con acabado (H.264/H.265; NVENC si está disponible).
- `*_informe.json` y `*_receta.json`: qué se hizo y con qué parámetros.

Los intermedios de cada vídeo se guardan en `datos\cache\`. Si solo cambias la parte de "Mejora", la limpieza no se repite. Borra esa carpeta para liberar espacio.

## Qué hace la GPU

| Etapa | Dónde se ejecuta |
|---|---|
| Limpieza temporal (polvo, ruido), nitidez y grano | GPU con PyTorch CUDA |
| Flujo óptico (baja resolución), estabilización y color | CPU (OpenCV) |
| Interpolación RIFE y escalado Real-ESRGAN | GPU con Vulkan |
| Codificación H.264/H.265 | NVENC de la GPU |

En la cabecera de la app se ve qué está activo, con la memoria en uso y el driver. Si la GPU está ocupada por otro programa (Ollama, LM Studio, un juego) o en modo de cómputo exclusivo, la app lo detecta, dice qué programa la ocupa, reintenta un par de veces y, si sigue sin poder, procesa por CPU y lo anota en el trabajo en vez de fallar. Lo mismo si CUDA se cae a mitad de un trabajo: sigue por CPU.

Si PyTorch no consigue usar CUDA (por ejemplo, con un controlador antiguo), la limpieza va por CPU. Para reintentar tras actualizar el controlador:

```
powershell -ExecutionPolicy Bypass -File scripts\instalar.ps1 -Reintentar
```

## Orden del proceso

Normalización (duplicados, desentrelazado, recorte) → análisis → estabilización → parpadeo → motas → ruido y grano → rayas → color → nitidez → **máster** → interpolación RIFE por escena → escalado Real-ESRGAN (máximo 2160 px de alto) → nitidez y grano → **copia mejorada**.

## Comparador a pantalla completa

En un trabajo terminado, botón **"Comparar a pantalla completa"**: original y restaurado superpuestos, con cortinilla arrastrable, modo lado a lado y botones de "solo original" / "solo restaurado". Los dos vídeos van sincronizados aunque tengan distinta cadencia, y en una muestra el original arranca justo en el segundo del fragmento.

Atajos: **espacio** reproducir y pausar, **←/→** cinco segundos, **F** pantalla completa, **Esc** cerrar.

## Plan automático

En Ajustes, "Plan automático": dile el **tiempo de que dispones** y la app decide los parámetros.

1. **Mide el material:** frecuencia de corte del escaneo (cuánto detalle hay de verdad), ruido, parpadeo, movimiento.
2. **Mide tu equipo:** cronometra unos fotogramas con cada motor disponible (limpieza, RIFE, cada modelo de escalado, NVENC).
3. **Propone:** la mejor combinación que quepa en ese tiempo, con el motivo escrito y las alternativas medidas.

La regla clave: **no escala por encima del doble de la resolución útil del escaneo**. Si el escáner resolvió 800 px reales, 4K no añade nada y la app lo dice y fija la salida más abajo.

Por línea de comandos: `python -m restaura8 planificar pelicula.mp4 --minutos 60 --prioridad 0.9 --guardar-receta receta.json`

## Medidas en el informe

Cada informe compara con números el vídeo normalizado y el máster, sobre 12 fotogramas repartidos: ruido σ, temblor residual en píxeles, parpadeo, nitidez de bordes, frecuencia de corte y resolución útil. El temblor se calcula con la trayectoria real de estabilización, no estimado.

## Modelos de IA

Dos motores de escalado:

- **Real-ESRGAN ncnn** (incluido, Vulkan): rápido. Modelos `realesr-animevideov3` (1,2 MB, pensado para animación) y `realesrgan-x4plus` (33 MB, imagen real).
- **Modelo PyTorch (.pth)** con [spandrel](https://github.com/chaiNNer-org/spandrel): admite cientos de modelos de OpenModelDB y similares (ESRGAN, SPAN, DAT, SwinIR, SCUNet…). Elige "Modelo PyTorch" como motor y el modelo en Ajustes.

La app descarga sola, la primera vez que se usan, `realesr-general-x4v3` (5 MB, escalado general de imagen real) y `RealESRGAN_x4plus` (64 MB). Cualquier otro modelo: deja el `.pth` en `herramientas\modelos\` y aparecerá en la lista.

**Interpolación:** RIFE ncnn, modelos `rife-v4.6` (por defecto) y anteriores, 10,6 MB cada uno.

**Caras (desactivado por defecto).** Detecta rostros con YuNet de OpenCV (230 KB) y los reconstruye con `GFPGANv1.4` (349 MB, se descarga solo al activarlo). Se aplica **únicamente a la copia mejorada**, nunca al máster. Ten presente que **inventa**: genera un rostro verosímil, no el que había, y puede variar entre fotogramas. Para ver en familia, sí; para archivo, no.

## Problemas frecuentes

- **El puerto 8765 está ocupado por otro programa.** EJECUTAR.bat lo cierra. Para usar otro puerto, cambia `PUERTO` en EJECUTAR.bat.
- **Falla la descarga de alguna herramienta.** Vuelve a ejecutar: solo se descarga lo que falta. También puedes descomprimirlas a mano en `herramientas\ffmpeg`, `herramientas\realesrgan` o `herramientas\rife`.
- **Cadencia de rodaje.** La app solo la cambia cuando puede deducirla de los fotogramas duplicados del telecine, o cuando el archivo ya viene a 16, 18 o 24 fps. Si no, conserva la del archivo para no alterar la velocidad, y en el diagnóstico te dice cuánto cambiaría la duración si la fijas tú. Los duplicados solo se eliminan cuando son los del telecine.
- **Real-ESRGAN inventa detalle.** Baja el "Peso de la IA". El máster fiel nunca usa IA.

## Estructura

```
EJECUTAR.bat / DETENER.bat
servidor.py            servidor local (FastAPI)
web\index.html         interfaz
restaura8\             motor de restauración (también por línea de comandos: python -m restaura8 --help)
presets\               preajustes
scripts\               instalación, cierre y apertura del navegador
herramientas\          FFmpeg, RIFE, Real-ESRGAN (se crean al instalar)
datos\ resultados\ run\  se crean al usar la app
```

## Limitaciones

Es la fase 0/1 de la especificación:

- procesa en 8 bits por canal;
- las rayas anchas o curvas no se corrigen;
- no tiene perfiles de color por emulsión, restauración de caras ni colorización;
- los umbrales conviene calibrarlos con bobinas reales.
