"""restaura8 — prototipo de restauración de película de 8 mm y Super 8 digitalizada."""
__version__ = "0.1.0"
