"""Línea de comandos:  python -m restaura8 {diagnosticar,restaurar,muestra} ..."""
from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path

from .diagnose import diagnose
from . import medidas as MED
from . import plan as PLAN
from .pipeline import Job, log
from .recipe import deep_update, load_recipe, save_recipe
from .video_io import run_ffmpeg


def cmd_diagnosticar(a):
    rep = diagnose(a.video, film_format=a.formato, max_frames=a.max_fotogramas)
    txt = json.dumps(rep, indent=2, ensure_ascii=False)
    print(txt)
    if a.salida_json:
        Path(a.salida_json).write_text(txt, encoding="utf-8")
    if a.guardar_receta:
        save_recipe(rep["receta_propuesta"], a.guardar_receta)
        log(f"Receta propuesta guardada en {a.guardar_receta}")


def cmd_planificar(a):
    rep = None
    if getattr(a, "diagnostico", None) and Path(a.diagnostico).exists():
        try:
            rep = json.loads(Path(a.diagnostico).read_text(encoding="utf-8"))
            log("Reutilizando el diagnóstico ya hecho de este vídeo")
        except Exception:  # noqa: BLE001
            rep = None
    if rep is None:
        log("Analizando el vídeo…")
        rep = diagnose(a.video, film_format=a.formato, max_frames=a.max_fotogramas, verbose=False)
    med = MED.metricas(a.video, recorte=rep.get("recorte_propuesto"))
    log("Midiendo la velocidad de este equipo…")
    marcas = PLAN.cronometrar(a.video, rep.get("recorte_propuesto"))
    plan = PLAN.proponer(rep, med, marcas, minutos=a.minutos, prioridad=a.prioridad,
                         tope_alto=a.tope_alto, fluidez=not a.sin_fluidez)
    plan["diagnostico"] = rep
    for linea in plan["explicacion"]:
        log("  " + linea)
    log(f"  Estimado: {plan['estimado_s'] / 60:.0f} min")
    if a.guardar_receta:
        save_recipe(plan["receta"], a.guardar_receta)
        log(f"Receta guardada en {a.guardar_receta}")
    if a.salida_json:
        Path(a.salida_json).write_text(json.dumps(plan, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({k: v for k, v in plan.items() if k != "receta"}, indent=2, ensure_ascii=False))


def build_recipe(a) -> dict:
    if a.receta == "auto":
        log("Diagnóstico automático para construir la receta")
        rep = diagnose(a.video, film_format=a.formato, max_frames=a.max_fotogramas, verbose=False)
        for n in rep["notas"]:
            log(f"  nota: {n}")
        a._notas = rep["notas"]
        a._cadencia_origen = rep.get("cadencia_origen", "")
        rec = rep["receta_propuesta"]
        if a.preajuste != "equilibrado":
            base = load_recipe(a.preajuste)
            base["normalizar"] = rec["normalizar"]
            base["deflicker"].update({k: rec["deflicker"][k] for k in ("activo", "zonas")})
            rec = base
    else:
        rec = load_recipe(a.receta)
    over = {}
    if a.film_fps:
        over.setdefault("normalizar", {})["film_fps"] = a.film_fps
    if a.fps_salida is not None:
        over.setdefault("mejora", {})["fps_salida"] = a.fps_salida or None
    if a.escala:
        over.setdefault("mejora", {})["escala"] = a.escala
    if a.sin_mejora:
        over.setdefault("mejora", {})["activo"] = False
    if a.motor_escala:
        over.setdefault("mejora", {})["motor_escala"] = a.motor_escala
    if a.motor_interpolacion:
        over.setdefault("mejora", {})["motor_interpolacion"] = a.motor_interpolacion
    return deep_update(rec, over)


def cmd_restaurar(a):
    rec = build_recipe(a)
    work = Path(a.trabajo or Path(a.salida) / f".trabajo_{Path(a.video).stem}")
    job = Job(a.video, work, rec)
    job.notas = list(getattr(a, "_notas", []))
    job.stats["cadencia_origen"] = getattr(a, "_cadencia_origen", "")
    rep = job.run(a.salida)
    print(json.dumps(rep["salidas"], indent=2, ensure_ascii=False))


def cmd_muestra(a):
    """Procesa un fragmento corto y genera una comparación lado a lado."""
    out = Path(a.salida)
    out.mkdir(parents=True, exist_ok=True)
    clip = out / f"{Path(a.video).stem}_fragmento.mkv"
    run_ffmpeg(["-ss", str(a.inicio), "-i", a.video, "-t", str(a.duracion),
                "-c:v", "ffv1", "-c:a", "flac", str(clip)])
    a_video = a.video
    a.video = str(clip)
    rec = build_recipe(a)
    # La muestra genera su propio comparativo (con el original completo, no el fragmento),
    # así que el pipeline no debe hacer otro.
    rec.setdefault("exportar", {})["comparacion_seg"] = 0
    job = Job(clip, out / ".trabajo_muestra", rec)
    job.notas = list(getattr(a, "_notas", []))
    job.stats["cadencia_origen"] = getattr(a, "_cadencia_origen", "")
    rep = job.run(out)
    src_for_cmp = rep["salidas"].get("mejorado") or rep["salidas"]["master"]
    cmp_file = out / f"{Path(a_video).stem}_comparacion.mp4"
    from . import comparar as CMP
    CMP.crear(a_video, src_for_cmp, cmp_file, inicio=CMP.segundos(a.inicio), duracion=float(a.duracion))
    log(f"Comparación: {cmp_file}")
    print(f"@@COMPARACION {cmp_file}", flush=True)


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
    ap = argparse.ArgumentParser(prog="restaura8", description="Restauración de 8 mm y Super 8 digitalizados")
    sub = ap.add_subparsers(dest="cmd", required=True)

    d = sub.add_parser("diagnosticar", help="Analiza el vídeo y propone una receta")
    d.add_argument("video")
    d.add_argument("--formato", choices=["super8", "8mm"], default="super8")
    d.add_argument("--max-fotogramas", type=int, default=3000)
    d.add_argument("--guardar-receta", metavar="RECETA.json")
    d.add_argument("--salida-json", metavar="INFORME.json")
    d.set_defaults(func=cmd_diagnosticar)

    def common(p):
        p.add_argument("video")
        p.add_argument("-o", "--salida", default="restaurado")
        p.add_argument("--receta", default="auto", help="auto | fiel | equilibrado | maximo | receta.json")
        p.add_argument("--preajuste", default="equilibrado", choices=["fiel", "equilibrado", "maximo"],
                       help="Preajuste que se combina con el diagnóstico cuando --receta=auto")
        p.add_argument("--formato", choices=["super8", "8mm"], default="super8")
        p.add_argument("--film-fps", type=float, help="Cadencia de rodaje (16, 18, 24)")
        p.add_argument("--fps-salida", type=float, help="Cadencia final (0 = la de rodaje)")
        p.add_argument("--escala", type=int, choices=[1, 2, 4])
        p.add_argument("--sin-mejora", action="store_true", help="Solo máster fiel")
        p.add_argument("--motor-escala", choices=["auto", "realesrgan-ncnn", "lanczos"])
        p.add_argument("--motor-interpolacion", choices=["auto", "rife-ncnn", "minterpolate", "repetir"])
        p.add_argument("--max-fotogramas", type=int, default=3000, help="Fotogramas usados en el diagnóstico")
        p.add_argument("--trabajo", help="Carpeta de archivos intermedios")

    r = sub.add_parser("restaurar", help="Proceso completo")
    common(r)
    r.set_defaults(func=cmd_restaurar)

    pl = sub.add_parser("planificar", help="Analiza, mide el equipo y propone parámetros para un tiempo dado")
    pl.add_argument("video")
    pl.add_argument("--minutos", type=float, default=60, help="Presupuesto de tiempo")
    pl.add_argument("--prioridad", type=float, default=0.5, help="0 = rápido, 1 = calidad")
    pl.add_argument("--tope-alto", type=int, default=2160)
    pl.add_argument("--sin-fluidez", action="store_true", help="No proponer interpolación")
    pl.add_argument("--formato", choices=["super8", "8mm"], default="super8")
    pl.add_argument("--max-fotogramas", type=int, default=3000)
    pl.add_argument("--guardar-receta", metavar="RECETA.json")
    pl.add_argument("--salida-json", metavar="PLAN.json")
    pl.add_argument("--diagnostico", metavar="DIAG.json", help="Reutiliza un diagnóstico ya hecho")
    pl.set_defaults(func=cmd_planificar)

    m = sub.add_parser("muestra", help="Vista previa de un fragmento con comparación")
    common(m)
    m.add_argument("--inicio", default="0", help="Segundo o hh:mm:ss de inicio")
    m.add_argument("--duracion", type=float, default=10)
    m.set_defaults(func=cmd_muestra)

    a = ap.parse_args(argv)
    a.func(a)


if __name__ == "__main__":
    sys.exit(main())
