"""Análisis: duplicados, cadencia, cortes, recorte, ruido, polvo, parpadeo, color y movimiento."""
from __future__ import annotations

import subprocess
from dataclasses import dataclass, field

import cv2
import numpy as np

FILM_RATES = (16.0, 18.0, 24.0)
ANALYSIS_WIDTH = 480


def small_gray(frame: np.ndarray, width: int = ANALYSIS_WIDTH) -> np.ndarray:
    h, w = frame.shape[:2]
    scale = width / w
    g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    return cv2.resize(g, (width, max(2, int(round(h * scale)))), interpolation=cv2.INTER_AREA)


def frame_diff(a: np.ndarray, b: np.ndarray) -> float:
    """Diferencia media absoluta entre dos grises reducidos (0–255)."""
    return float(cv2.absdiff(a, b).mean())


def hsv_hist(frame_small_bgr: np.ndarray) -> np.ndarray:
    hsv = cv2.cvtColor(frame_small_bgr, cv2.COLOR_BGR2HSV)
    hist = cv2.calcHist([hsv], [0, 1], None, [18, 8], [0, 180, 0, 256])
    return cv2.normalize(hist, hist).flatten()


def duplicate_flags(diffs: np.ndarray, rel: float = 0.2, abs_max: float = 1.5) -> np.ndarray:
    """diffs[i] = diferencia entre el fotograma i y el i-1 (diffs[0] = inf).
    Un fotograma es duplicado si su diferencia es muy pequeña respecto a la mediana
    de las diferencias 'reales'. El ruido del escáner impide exigir igualdad exacta."""
    d = np.asarray(diffs, float)
    finite = d[np.isfinite(d)]
    if finite.size == 0:
        return np.zeros_like(d, bool)
    # Mediana de las diferencias que claramente no son duplicados.
    moving = finite[finite > np.percentile(finite, 30)]
    ref = float(np.median(moving)) if moving.size else float(np.median(finite))
    thr = min(abs_max, rel * ref) if ref > 0 else abs_max
    flags = d <= thr
    flags[0] = False
    return flags


def estimate_film_fps(container_fps: float, dup_ratio: float) -> tuple[float, float, str]:
    """Devuelve (cadencia sin duplicados, cadencia de rodaje propuesta, origen).

    origen:
      'deducida'   — los duplicados dan la cadencia de rodaje (telecine o proyector filmado);
      'contenedor' — la cadencia del archivo ya es de película (escaneo fotograma a fotograma);
      'conservada' — no hay forma de deducirla: se conserva la del archivo para NO alterar la velocidad.

    Nunca se supone una cadencia que cambiaría la duración: esa decisión es del usuario.
    """
    unique_fps = container_fps * (1.0 - dup_ratio)
    cercana = min(FILM_RATES, key=lambda r: abs(r - unique_fps))
    if dup_ratio > 0.05 and abs(cercana - unique_fps) / cercana < 0.08:
        return unique_fps, cercana, "deducida"
    cercana_c = min(FILM_RATES, key=lambda r: abs(r - container_fps))
    if abs(cercana_c - container_fps) / cercana_c < 0.05:
        return unique_fps, cercana_c, "contenedor"
    return unique_fps, round(container_fps, 3), "conservada"


def detect_scene_cuts(hists: list[np.ndarray], diffs: np.ndarray, corr_thr: float = 0.5,
                      min_gap: int = 8) -> list[int]:
    """Índices de fotograma donde empieza una escena nueva (el 0 siempre incluido)."""
    cuts = [0]
    d = np.asarray(diffs, float)
    finite = d[np.isfinite(d)]
    moving = finite[finite > 0.5]
    med = float(np.median(moving)) if moving.size else 1.0
    last = 0  # último fotograma no duplicado, para comparar histogramas
    for i in range(1, len(hists)):
        corr = cv2.compareHist(hists[last], hists[i], cv2.HISTCMP_CORREL)
        if corr < corr_thr and d[i] > 1.3 * med and i - cuts[-1] >= min_gap:
            cuts.append(i)
        if d[i] > 0.5:
            last = i
    return cuts


def detect_crop(stack: np.ndarray, rel: float = 0.35, margin: int | None = None) -> tuple[int, int, int, int]:
    """Recorte (x, y, w, h) en coordenadas de la imagen reducida.
    Las zonas fuera de la imagen (bordes, perforaciones) son casi estáticas en el tiempo."""
    tstd = stack.astype(np.float32).std(axis=0)
    if margin is None:
        margin = max(2, int(round(0.01 * stack.shape[2])))
    cols, rows = tstd.mean(axis=0), tstd.mean(axis=1)

    def bounds(profile):
        thr = rel * np.median(profile)
        idx = np.where(profile > thr)[0]
        if idx.size == 0:
            return 0, profile.size
        return int(idx[0]), int(idx[-1]) + 1

    x0, x1 = bounds(cols)
    y0, y1 = bounds(rows)
    H, W = tstd.shape
    x0, y0 = min(W - 1, x0 + margin), min(H - 1, y0 + margin)
    x1, y1 = max(x0 + 1, x1 - margin), max(y0 + 1, y1 - margin)
    # Si el recorte es casi toda la imagen, no recortar.
    if (x1 - x0) > 0.97 * W and (y1 - y0) > 0.97 * H:
        return 0, 0, W, H
    return x0, y0, x1 - x0, y1 - y0


def noise_sigma(gray: np.ndarray) -> float:
    """Estimación rápida del ruido (Immerkær, 1996)."""
    k = np.array([[1, -2, 1], [-2, 4, -2], [1, -2, 1]], np.float32)
    conv = cv2.filter2D(gray.astype(np.float32), -1, k)
    h, w = gray.shape
    return float(np.sum(np.abs(conv)) * np.sqrt(0.5 * np.pi) / (6 * (w - 2) * (h - 2)))


_DIS = None


def dense_flow(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Flujo óptico denso de a hacia b (DIS, mucho más rápido que Farnebäck)."""
    global _DIS
    if _DIS is None:
        _DIS = cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_MEDIUM)
    return _DIS.calc(a, b, None)


def flow_warp(src: np.ndarray, dst_gray_small: np.ndarray, src_gray_small: np.ndarray) -> np.ndarray:
    """Deforma `src` (tamaño completo) para alinearlo con el fotograma cuyo gris reducido es
    `dst_gray_small`, usando flujo óptico Farnebäck calculado a baja resolución."""
    flow = dense_flow(dst_gray_small, src_gray_small)
    H, W = src.shape[:2]
    sh, sw = dst_gray_small.shape
    fx = cv2.resize(flow[..., 0], (W, H), interpolation=cv2.INTER_LINEAR) * (W / sw)
    fy = cv2.resize(flow[..., 1], (W, H), interpolation=cv2.INTER_LINEAR) * (H / sh)
    gx, gy = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))
    return cv2.remap(src, gx + fx, gy + fy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)


def lowpass(img: np.ndarray, factor: int = 16) -> np.ndarray:
    """Paso bajo rápido: reducir, suavizar y ampliar."""
    h, w = img.shape[:2]
    small = cv2.resize(img, (max(2, w // factor), max(2, h // factor)), interpolation=cv2.INTER_AREA)
    small = cv2.GaussianBlur(small, (0, 0), 1.0)
    return cv2.resize(small, (w, h), interpolation=cv2.INTER_LINEAR)


def dust_mask(cur: np.ndarray, prev_w: np.ndarray, next_w: np.ndarray, thr: float = 28.0,
              agree: float = 14.0, max_area: int = 400) -> np.ndarray:
    """Máscara de motas: píxeles que (1) difieren mucho de ambos vecinos alineados, en el mismo
    sentido, (2) mientras los vecinos coinciden entre sí y (3) son una anomalía local en el propio
    fotograma. Antes se iguala el brillo local de los vecinos (parpadeo) y se descartan manchas
    grandes (movimiento mal compensado)."""
    c = cv2.cvtColor(cur, cv2.COLOR_BGR2GRAY).astype(np.float32)
    p = cv2.cvtColor(prev_w, cv2.COLOR_BGR2GRAY).astype(np.float32)
    n = cv2.cvtColor(next_w, cv2.COLOR_BGR2GRAY).astype(np.float32)
    cb = lowpass(c) + 1
    p *= cb / (lowpass(p) + 1)
    n *= cb / (lowpass(n) + 1)
    dp, dn = c - p, c - n
    local = c - cv2.medianBlur(np.clip(c, 0, 255).astype(np.uint8), 5).astype(np.float32)
    m = ((np.abs(dp) > thr) & (np.abs(dn) > thr) & (np.sign(dp) == np.sign(dn))
         & (np.abs(p - n) < agree) & (np.abs(local) > thr * 0.6) & (np.sign(local) == np.sign(dp)))
    m = m.astype(np.uint8)
    if not m.any():
        return m
    num, labels, stats, _ = cv2.connectedComponentsWithStats(m, connectivity=8)
    keep = np.zeros(num, np.uint8)
    keep[1:] = (stats[1:, cv2.CC_STAT_AREA] <= max_area).astype(np.uint8)
    m = keep[labels]
    return cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))


def rigid_transform(prev_small: np.ndarray, cur_small: np.ndarray) -> tuple[float, float, float]:
    """(dx, dy, dángulo) de prev a cur, en píxeles de la imagen reducida."""
    pts = cv2.goodFeaturesToTrack(prev_small, maxCorners=300, qualityLevel=0.01, minDistance=12,
                                  blockSize=7)
    if pts is None or len(pts) < 8:
        return 0.0, 0.0, 0.0
    nxt, st, _ = cv2.calcOpticalFlowPyrLK(prev_small, cur_small, pts, None)
    ok = st.reshape(-1) == 1
    if ok.sum() < 8:
        return 0.0, 0.0, 0.0
    m, inl = cv2.estimateAffinePartial2D(pts[ok], nxt[ok], method=cv2.RANSAC, ransacReprojThreshold=1.5)
    if m is None or inl is None or inl.sum() < 8:
        return 0.0, 0.0, 0.0
    dx, dy, da = float(m[0, 2]), float(m[1, 2]), float(np.arctan2(m[1, 0], m[0, 0]))
    scale = float(np.hypot(m[0, 0], m[1, 0]))
    # m rota alrededor del origen (0, 0); se expresa la traslación respecto al centro.
    h, w = prev_small.shape
    c = np.array([w / 2, h / 2])
    tc = m[:, :2] @ c + m[:, 2] - c
    dx, dy = float(tc[0]), float(tc[1])
    # Estimaciones implausibles para un vaivén o un movimiento normal: se descartan.
    if abs(da) > 0.03 or abs(scale - 1) > 0.05 or abs(dx) > 0.15 * w or abs(dy) > 0.15 * h:
        return 0.0, 0.0, 0.0
    return dx, dy, da


def idet_interlaced_ratio(path: str, frames: int = 400) -> float:
    """Proporción de fotogramas entrelazados según el filtro idet de FFmpeg."""
    try:
        res = subprocess.run(
            ["ffmpeg", "-v", "info", "-i", str(path), "-frames:v", str(frames), "-an",
             "-vf", "idet", "-f", "null", "-"], capture_output=True, text=True, timeout=300)
    except Exception:
        return 0.0
    line = [l for l in res.stderr.splitlines() if "Multi frame detection" in l]
    if not line:
        return 0.0
    import re
    vals = dict((k, int(v)) for k, v in re.findall(r"(TFF|BFF|Progressive|Undetermined):\s*(\d+)", line[-1]))
    inter = vals.get("TFF", 0) + vals.get("BFF", 0)
    total = inter + vals.get("Progressive", 0)
    return inter / total if total else 0.0


@dataclass
class SceneColor:
    start: int
    end: int
    gains: list[float] = field(default_factory=lambda: [1.0, 1.0, 1.0])
    low: float = 0.0
    high: float = 255.0


def smooth_1d(x: np.ndarray, radius: int) -> np.ndarray:
    if radius <= 0 or x.size == 0:
        return x.copy()
    k = 2 * radius + 1
    pad = np.pad(x, radius, mode="edge")
    return np.convolve(pad, np.ones(k) / k, mode="valid")


def scratch_columns(gray: np.ndarray, thr: float = 5.0, max_width: int = 3) -> np.ndarray:
    """Columnas con raya vertical: diferencia persistente con sus vecinas horizontales."""
    g = gray.astype(np.float32)
    pad = np.pad(g, ((0, 0), (4, 4)), mode="edge")
    W = g.shape[1]
    a, b, c2, e = (pad[:, k:k + W] for k in (0, 1, 7, 8))
    lo = np.minimum(np.minimum(a, b), np.minimum(c2, e))
    hi = np.maximum(np.maximum(a, b), np.maximum(c2, e))
    d = g - (a + b + c2 + e - lo - hi) / 2  # mediana de 4 vecinas
    # Mediana por columna sobre una submuestra de filas (suficiente y mucho más rápido)
    score = np.median(d[::4], axis=0)
    cols = np.abs(score) > thr
    # Solo rayas estrechas (los bordes de objetos verticales anchos no cuentan)
    out = np.zeros_like(cols)
    i = 0
    n = cols.size
    while i < n:
        if cols[i]:
            j = i
            while j < n and cols[j]:
                j += 1
            if j - i <= max_width:
                out[i:j] = True
            i = j
        else:
            i += 1
    return out
