"""Motores externos de IA (Real-ESRGAN y RIFE en versión ncnn-Vulkan) con alternativas sin IA."""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path


def find_bin(env: str, names: list[str]) -> str | None:
    p = os.environ.get(env)
    if p and Path(p).exists():
        return p
    for n in names:
        found = shutil.which(n)
        if found:
            return found
    return None


def realesrgan_bin() -> str | None:
    return find_bin("RESTAURA8_REALESRGAN", ["realesrgan-ncnn-vulkan", "realesrgan-ncnn-vulkan.exe"])


def rife_bin() -> str | None:
    return find_bin("RESTAURA8_RIFE", ["rife-ncnn-vulkan", "rife-ncnn-vulkan.exe"])


def hay_spandrel() -> bool:
    try:
        import spandrel  # noqa: F401
        import torch  # noqa: F401
    except Exception:  # noqa: BLE001
        return False
    return True


_VULKAN: dict = {}


def vulkan_ok() -> bool:
    """¿Hay una tarjeta (dedicada o integrada) con Vulkan que ncnn pueda usar? Se comprueba de
    verdad escalando una imagen diminuta. En un PC sin GPU compatible, RIFE y Real-ESRGAN
    fallarían o irían por CPU a paso de tortuga; entonces «auto» elige Lanczos y minterpolate."""
    if "ok" in _VULKAN:
        return _VULKAN["ok"]
    exe = realesrgan_bin()
    ok = False
    if exe:
        import tempfile

        import cv2
        import numpy as np
        d = Path(tempfile.mkdtemp(prefix="restaura8_vk_"))
        try:
            (d / "i").mkdir()
            cv2.imwrite(str(d / "i" / "a.png"), np.full((32, 32, 3), 128, np.uint8))
            run_realesrgan(d / "i", d / "o", 2, "realesr-animevideov3", timeout=90)
            ok = any((d / "o").glob("*.png"))
        except Exception:  # noqa: BLE001
            ok = False
        finally:
            shutil.rmtree(d, ignore_errors=True)
    if exe and not ok:
        print("[aviso] No hay una tarjeta gráfica con Vulkan utilizable: el escalado usará Lanczos "
              "y la interpolación minterpolate (por CPU).", flush=True)
    _VULKAN["ok"] = ok
    return ok


def resolve_upscaler(choice: str) -> str:
    if choice == "auto":
        if realesrgan_bin() and vulkan_ok():
            return "realesrgan-ncnn"
        return "spandrel" if hay_spandrel() else "lanczos"
    if choice == "realesrgan-ncnn" and not realesrgan_bin():
        raise RuntimeError("No se encuentra realesrgan-ncnn-vulkan (define RESTAURA8_REALESRGAN o añádelo al PATH)")
    if choice == "spandrel" and not hay_spandrel():
        raise RuntimeError("Falta el paquete spandrel: ejecuta scripts\\instalar.ps1")
    return choice


def resolve_interpolator(choice: str) -> str:
    if choice == "auto":
        return "rife-ncnn" if (rife_bin() and vulkan_ok()) else "minterpolate"
    if choice == "rife-ncnn" and not rife_bin():
        raise RuntimeError("No se encuentra rife-ncnn-vulkan (define RESTAURA8_RIFE o añádelo al PATH)")
    return choice


def _models_dir(env: str, exe: str, sub: str) -> Path:
    d = os.environ.get(env)
    return Path(d) if d else Path(exe).resolve().parent / sub


def realesrgan_models() -> list[str]:
    exe = realesrgan_bin()
    if not exe:
        return []
    d = _models_dir("RESTAURA8_REALESRGAN_MODELS", exe, "models")
    return sorted({p.stem.rsplit("-x", 1)[0] if p.stem.startswith("realesr-animevideov3") else p.stem
                   for p in d.glob("*.param")})


def rife_models() -> list[str]:
    exe = rife_bin()
    if not exe:
        return []
    d = _models_dir("RESTAURA8_RIFE_MODELS", exe, "")
    return sorted(p.name for p in d.iterdir() if p.is_dir() and p.name.startswith("rife"))


def pick_rife_model(wanted: str) -> str:
    models = rife_models()
    if not models or wanted in models:
        return wanted
    for m in ("rife-v4.6", "rife-v4", "rife-v3.1", "rife-v2.4", "rife-anime"):
        if m in models:
            return m
    return models[-1]


def _ejecutar(cmd: list, cwd: str, timeout: float | None) -> None:
    """Lanza un motor externo. Con timeout, si se cuelga (GPU bloqueada, Vulkan perdido) se mata
    el proceso y se lanza TimeoutError en lugar de esperar indefinidamente."""
    if timeout is None:
        subprocess.run(cmd, check=True, cwd=cwd)
        return
    try:
        subprocess.run(cmd, check=True, cwd=cwd, timeout=timeout,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except subprocess.TimeoutExpired as exc:
        raise TimeoutError(f"{Path(cmd[0]).name} no respondió en {timeout:.0f} s") from exc


def run_realesrgan(in_dir: Path, out_dir: Path, scale: int, model: str, tile: int = 0, gpu: int = 0,
                   timeout: float | None = None) -> None:
    exe = realesrgan_bin()
    out_dir.mkdir(parents=True, exist_ok=True)
    models_dir = _models_dir("RESTAURA8_REALESRGAN_MODELS", exe, "models")
    cmd = [exe, "-i", str(in_dir.resolve()), "-o", str(out_dir.resolve()), "-n", model, "-s", str(scale),
           "-f", "png", "-g", str(gpu), "-m", str(models_dir)]
    if tile:
        cmd += ["-t", str(tile)]
    _ejecutar(cmd, str(Path(exe).resolve().parent), timeout)


def run_rife(in_dir: Path, out_dir: Path, n_frames: int, model: str, gpu: int = 0, uhd: bool = False,
             timeout: float | None = None) -> None:
    exe = rife_bin()
    out_dir.mkdir(parents=True, exist_ok=True)
    model_path = _models_dir("RESTAURA8_RIFE_MODELS", exe, "") / pick_rife_model(model)
    cmd = [exe, "-i", str(in_dir.resolve()), "-o", str(out_dir.resolve()), "-n", str(n_frames),
           "-m", str(model_path), "-g", str(gpu), "-f", "%08d.png"]
    if uhd:
        cmd.append("-u")
    _ejecutar(cmd, str(Path(exe).resolve().parent), timeout)
