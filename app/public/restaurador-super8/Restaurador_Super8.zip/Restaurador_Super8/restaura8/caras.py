"""Restauración de caras: detección con YuNet (OpenCV) y reconstrucción con GFPGAN.

Solo se aplica a la copia mejorada, nunca al máster fiel: estos modelos **reconstruyen**
un rostro plausible, no recuperan el que había. Está desactivada por defecto.
"""
from __future__ import annotations

import cv2
import numpy as np

from . import torchmodels as TM

# Plantilla de 5 puntos (ojo izq., ojo der., nariz, comisura izq., comisura der.) para 512×512
PLANTILLA = np.array([[192.98138, 239.94708], [318.90277, 240.19360], [256.63416, 314.01935],
                      [186.77223, 371.15043], [314.19183, 371.60583]], np.float32)
_DET = None


def detector(ancho: int, alto: int, umbral: float = 0.7):
    global _DET
    ruta = str(TM.ruta_modelo("yunet"))
    if _DET is None:
        _DET = cv2.FaceDetectorYN_create(ruta, "", (ancho, alto), umbral, 0.3, 5000)
    _DET.setInputSize((ancho, alto))
    return _DET


def detectar(img: np.ndarray, minimo: int = 80) -> list[np.ndarray]:
    """Devuelve los 5 puntos faciales de cada cara suficientemente grande."""
    h, w = img.shape[:2]
    escala = min(1.0, 640 / max(h, w))
    pequeno = cv2.resize(img, None, fx=escala, fy=escala, interpolation=cv2.INTER_AREA) if escala < 1 else img
    _, caras = detector(pequeno.shape[1], pequeno.shape[0]).detect(pequeno)
    salida = []
    if caras is None:
        return salida
    for c in caras:
        if c[2] / escala < minimo:      # ancho de la cara en el original
            continue
        pts = c[4:14].reshape(5, 2).astype(np.float32) / escala
        # Ordenar por si el detector cambia el orden: ojos arriba, comisuras abajo
        ojos = sorted(pts[:2], key=lambda p: p[0])
        bocas = sorted(pts[3:5], key=lambda p: p[0])
        salida.append(np.array([ojos[0], ojos[1], pts[2], bocas[0], bocas[1]], np.float32))
    return salida


def _mascara(tam: int = 512) -> np.ndarray:
    m = np.zeros((tam, tam), np.float32)
    cv2.ellipse(m, (tam // 2, int(tam * 0.56)), (int(tam * 0.37), int(tam * 0.46)), 0, 0, 360, 1.0, -1)
    return cv2.GaussianBlur(m, (0, 0), tam * 0.045)


_MASCARA = None


def restaurar(img: np.ndarray, intensidad: float = 0.6, modelo: str = "GFPGANv1.4",
              minimo: int = 80) -> tuple[np.ndarray, int]:
    """Devuelve (imagen, nº de caras tratadas)."""
    global _MASCARA
    if intensidad <= 0:
        return img, 0
    caras = detectar(img, minimo)
    if not caras:
        return img, 0
    if _MASCARA is None:
        _MASCARA = _mascara()
    salida = img.astype(np.float32)
    tratadas = 0
    for pts in caras:
        M, _ = cv2.estimateAffinePartial2D(pts, PLANTILLA, method=cv2.LMEDS)
        if M is None:
            continue
        recorte = cv2.warpAffine(img, M, (512, 512), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        try:
            nuevo = TM.aplicar(recorte, modelo, tile=0)
        except Exception as exc:  # noqa: BLE001
            print(f"[aviso] No se pudo restaurar una cara: {exc}", flush=True)
            return img, tratadas
        if nuevo.shape[:2] != (512, 512):
            nuevo = cv2.resize(nuevo, (512, 512), interpolation=cv2.INTER_AREA)
        Minv = cv2.invertAffineTransform(M)
        h, w = img.shape[:2]
        vuelta = cv2.warpAffine(nuevo, Minv, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
        peso = cv2.warpAffine(_MASCARA, Minv, (w, h), flags=cv2.INTER_LINEAR)[..., None] * float(intensidad)
        salida = salida * (1 - peso) + vuelta.astype(np.float32) * peso
        tratadas += 1
    return np.clip(salida, 0, 255).astype(np.uint8), tratadas
