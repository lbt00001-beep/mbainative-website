"""Vídeo comparativo: original y restaurado, uno al lado del otro."""
from __future__ import annotations

from pathlib import Path

from .video_io import encoder_works, probe, run_ffmpeg


def segundos(txt: str | float | None) -> float:
    """Acepta «90», «1,5» o «00:01:30»."""
    if txt is None:
        return 0.0
    if isinstance(txt, (int, float)):
        return float(txt)
    t = str(txt).strip().replace(",", ".")
    if ":" in t:
        partes = [float(x or 0) for x in t.split(":")]
        while len(partes) < 3:
            partes.insert(0, 0.0)
        return partes[0] * 3600 + partes[1] * 60 + partes[2]
    try:
        return float(t)
    except ValueError:
        return 0.0


def crear(original: str | Path, restaurado: str | Path, destino: str | Path,
          inicio: float = 0.0, duracion: float | None = None, alto: int = 720) -> Path:
    """Genera un MP4 con las dos versiones sincronizadas, a la misma altura.

    `inicio` y `duracion` se aplican a AMBOS: en una muestra, el original hay que
    adelantarlo hasta donde empezaba el fragmento.
    """
    destino = Path(destino)
    info_r = probe(restaurado)
    fps = info_r.fps
    # La app conserva la duración (quitar duplicados o interpolar no cambia el tiempo real),
    # así que el mismo segundo corresponde a la misma escena en los dos vídeos.
    factor = 1.0
    ini_o = max(inicio, 0.0)
    ini_r = ini_o * factor
    args = ["-ss", f"{ini_o:.3f}"]
    if duracion:
        args += ["-t", f"{duracion:.3f}"]
    args += ["-i", str(original), "-ss", f"{ini_r:.3f}"]
    if duracion:
        args += ["-t", f"{duracion * factor:.3f}"]
    args += ["-i", str(restaurado)]
    # Si la cadencia cambió, el original se reproduce al ritmo del restaurado
    lento = f",setpts=PTS*{factor:.6f}" if abs(factor - 1) > 0.01 else ""
    # Con NVENC la comparación de una bobina entera tarda poco; si no, x264 rápido
    codec = (["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", "21", "-b:v", "0"]
             if encoder_works("h264_nvenc") else ["-c:v", "libx264", "-crf", "20", "-preset", "veryfast"])
    run_ffmpeg([*args, "-filter_complex",
                f"[0:v]setpts=PTS-STARTPTS{lento},fps={fps.numerator}/{fps.denominator},scale=-2:{alto}:flags=lanczos,setsar=1[a];"
                f"[1:v]setpts=PTS-STARTPTS,fps={fps.numerator}/{fps.denominator},scale=-2:{alto}:flags=lanczos,setsar=1[b];"
                "[a][b]hstack=inputs=2:shortest=1,format=yuv420p",
                "-an", *codec,
                "-movflags", "+faststart", str(destino)])
    return destino
