"""Diagnóstico del vídeo subido y propuesta de receta."""
from __future__ import annotations

import cv2
import numpy as np

from . import analysis as A
from .video_io import probe, read_frames


def diagnose(path: str, film_format: str = "super8", max_frames: int = 3000, verbose: bool = True) -> dict:
    info = probe(path)
    fps = info.fps_float
    diffs, hists, lumas, noises, stack = [], [], [], [], []
    dust_masks = []
    mean_frame = None
    prev = None
    window = []  # últimos 3 fotogramas reducidos en color, para medir polvo
    sample_every = max(1, min(info.nb_frames or max_frames, max_frames) // 120)

    for i, fr in enumerate(read_frames(path)):
        if i >= max_frames:
            break
        g = A.small_gray(fr)
        h, w = g.shape
        col = cv2.resize(fr, (w, h), interpolation=cv2.INTER_AREA)
        diffs.append(np.inf if prev is None else A.frame_diff(prev, g))
        hists.append(A.hsv_hist(col))
        lumas.append(float(g.mean()))
        if i % sample_every == 0:
            stack.append(g)
            noises.append(A.noise_sigma(g))
            f = col.astype(np.float32)
            mean_frame = f if mean_frame is None else mean_frame + f
        # Polvo: sobre fotogramas distintos consecutivos, cada 10 muestras
        if prev is None or diffs[-1] > 1.5:
            window.append((col, g))
            window = window[-3:]
            if len(window) == 3 and i % (sample_every * 4 or 1) == 0:
                (pc, pg), (cc, cg), (nc, ng) = window
                pw = A.flow_warp(pc, cg, pg)
                nw = A.flow_warp(nc, cg, ng)
                dust_masks.append(A.dust_mask(cc, pw, nw, max_area=60))
        prev = g
        if verbose and i % 250 == 0:
            print(f"  diagnóstico: fotograma {i}", flush=True)

    n = len(diffs)
    d = np.array(diffs)
    dup = A.duplicate_flags(d)
    dup_ratio = float(dup.mean()) if n else 0.0
    unique_fps, film_fps, origen = A.estimate_film_fps(fps, dup_ratio)
    sugerida = 16.0 if film_format == "8mm" else 18.0

    cuts = A.detect_scene_cuts(hists, d)
    stack_arr = np.stack(stack) if stack else np.zeros((1, 2, 2), np.uint8)
    cx, cy, cw, ch = A.detect_crop(stack_arr)
    sh, sw = stack_arr.shape[1:]
    sx, sy = info.width / sw, info.height / sh
    crop = [int(cx * sx), int(cy * sy), int(cw * sx) // 2 * 2, int(ch * sy) // 2 * 2]
    full_crop = crop == [0, 0, info.width // 2 * 2, info.height // 2 * 2] or (cw == sw and ch == sh)

    lum = np.array(lumas)[~dup] if n else np.array([0.0])
    resid = lum - A.smooth_1d(lum, 12)
    flicker = float(np.std(resid))

    hotspot = 1.0
    cast = [0.0, 0.0]
    if mean_frame is not None:
        mf = (mean_frame / len(stack)).astype(np.uint8)
        mf = mf[cy:cy + ch, cx:cx + cw]
        mg = cv2.cvtColor(mf, cv2.COLOR_BGR2GRAY).astype(np.float32)
        H, W = mg.shape
        center = mg[H // 3: 2 * H // 3, W // 3: 2 * W // 3].mean()
        corners = np.mean([mg[:H // 6, :W // 6].mean(), mg[:H // 6, -W // 6:].mean(),
                           mg[-H // 6:, :W // 6].mean(), mg[-H // 6:, -W // 6:].mean()])
        hotspot = float(center / max(corners, 1.0))
        lab = cv2.cvtColor(mf, cv2.COLOR_BGR2LAB).astype(np.float32)
        cast = [float(lab[..., 1].mean() - 128), float(lab[..., 2].mean() - 128)]

    interlaced = A.idet_interlaced_ratio(str(path))
    noise = float(np.median(noises)) if noises else 0.0
    dust = (float(np.mean([m[cy:cy + ch, cx:cx + cw].mean() for m in dust_masks]))
            if dust_masks else 0.0)

    if dup_ratio > 0.05 or interlaced > 0.3 or hotspot > 1.35:
        source = "telecine / proyector filmado"
    elif dup_ratio <= 0.05:
        source = "probable escaneo fotograma a fotograma"
    else:
        source = "indeterminado"

    notes = []
    if origen == "deducida":
        notes.append(f"Cadencia de rodaje deducida de los duplicados: {film_fps:g} fps.")
    elif origen == "contenedor":
        notes.append(f"El archivo ya está a {film_fps:g} fps, una cadencia de película: se conserva la velocidad.")
    else:
        dur_actual = info.duration
        dur_sug = dur_actual * fps / sugerida if sugerida else dur_actual
        notes.append(
            f"No hay duplicados ni una cadencia reconocible ({fps:g} fps): no se puede deducir a qué velocidad "
            f"se filmó. Se conserva la del archivo, así que la duración no cambia. Si sabes que se filmó a "
            f"{sugerida:g} fps, cámbialo en Ajustes: la duración pasaría de {dur_actual / 60:.0f}:{dur_actual % 60:02.0f} "
            f"a {dur_sug / 60:.0f}:{dur_sug % 60:02.0f}.")
    if hotspot > 1.35:
        notes.append("Centro más brillante que las esquinas: posible 'hotspot' de proyector; activa deflicker por zonas.")
    if abs(cast[0]) > 6 or abs(cast[1]) > 8:
        notes.append("Dominante de color apreciable: se recomienda corrección de color por escena.")

    report = {
        "archivo": str(path),
        "resolucion": [info.width, info.height],
        "fps_contenedor": round(fps, 3),
        "fotogramas_analizados": n,
        "duplicados_pct": round(100 * dup_ratio, 1),
        "fps_sin_duplicados": round(unique_fps, 2),
        "fps_rodaje_propuesto": film_fps,
        "cadencia_origen": origen,
        "cadencia_fiable": origen == "deducida",
        "fps_rodaje_alternativa": sugerida,
        "duracion": round(info.duration, 2),
        "entrelazado_pct": round(100 * interlaced, 1),
        "origen_probable": source,
        "recorte_propuesto": None if full_crop else crop,
        "escenas": len(cuts),
        "ruido_sigma": round(noise, 2),
        "polvo_pct_pixeles": round(100 * dust, 4),
        "parpadeo_std": round(flicker, 2),
        "hotspot_ratio": round(hotspot, 2),
        "dominante_lab_ab": [round(c, 1) for c in cast],
        "notas": notes,
    }
    report["receta_propuesta"] = propose_recipe(report)
    return report


def propose_recipe(r: dict) -> dict:
    """Traduce el diagnóstico a una receta basada en el preajuste 'equilibrado'."""
    from .recipe import load_preset
    rec = load_preset("equilibrado")
    rec["normalizar"]["film_fps"] = r["fps_rodaje_propuesto"]
    # Solo se quitan duplicados cuando son los del telecine (la cadencia se dedujo de ellos).
    # Si no, quitarlos aceleraría la película.
    rec["normalizar"]["quitar_duplicados"] = r.get("cadencia_origen") == "deducida"
    rec["normalizar"]["desentrelazar"] = r["entrelazado_pct"] > 30
    rec["normalizar"]["recorte"] = r["recorte_propuesto"]
    rec["deflicker"]["zonas"] = r["hotspot_ratio"] > 1.35
    rec["deflicker"]["activo"] = r["parpadeo_std"] > 0.8 or r["hotspot_ratio"] > 1.35
    noise = r["ruido_sigma"]
    rec["ruido"]["temporal"] = float(np.clip(noise / 6.0, 0.3, 1.0))
    # La limpieza de motas comparte el flujo óptico con la reducción temporal de ruido:
    # si esa ya se hace, quitar motas apenas cuesta, así que se deja puesta salvo que el
    # material esté impecable. Con poco polvo se sube el umbral para no inventar correcciones.
    polvo_pct = r["polvo_pct_pixeles"]
    rec["polvo"]["activo"] = polvo_pct > 0.0001 or rec["ruido"]["temporal"] > 0
    rec["polvo"]["umbral"] = 32 if polvo_pct < 0.002 else (28 if polvo_pct < 0.02 else 24)
    rec["polvo"]["rayas"] = True
    cast = r["dominante_lab_ab"]
    rec["color"]["balance"] = 0.9 if (abs(cast[0]) > 6 or abs(cast[1]) > 8) else 0.6
    return rec
