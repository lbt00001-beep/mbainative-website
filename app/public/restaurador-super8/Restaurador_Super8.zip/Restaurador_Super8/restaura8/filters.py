"""Filtros por fotograma: estabilización, deflicker, limpieza temporal, color, nitidez y grano."""
from __future__ import annotations

import math

import cv2
import numpy as np

from . import analysis as A
from . import gpu as G

_GRID_CACHE: dict = {}


def stabilize(frame: np.ndarray, corr: tuple[float, float, float], zoom: float) -> np.ndarray:
    h, w = frame.shape[:2]
    dx, dy, da = corr
    M = cv2.getRotationMatrix2D((w / 2, h / 2), -math.degrees(da), zoom)
    M[0, 2] += dx * zoom
    M[1, 2] += dy * zoom
    return cv2.warpAffine(frame, M, (w, h), flags=cv2.INTER_LANCZOS4, borderMode=cv2.BORDER_REFLECT)


def apply_gain(frame: np.ndarray, gain) -> np.ndarray:
    """gain: escalar o mapa HxW (float)."""
    f = frame.astype(np.float32)
    if np.isscalar(gain):
        f *= gain
    else:
        f *= gain[..., None]
    return np.clip(f, 0, 255).astype(np.uint8)


def gain_map(grid_gain: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    h, w = shape
    return cv2.resize(grid_gain.astype(np.float32), (w, h), interpolation=cv2.INTER_CUBIC)


def _warp_full(src: np.ndarray, flow: np.ndarray, small_shape) -> np.ndarray:
    H, W = src.shape[:2]
    sh, sw = small_shape
    key = (H, W)
    if key not in _GRID_CACHE:
        gx, gy = np.meshgrid(np.arange(W, dtype=np.float32), np.arange(H, dtype=np.float32))
        _GRID_CACHE[key] = (gx, gy)
    gx, gy = _GRID_CACHE[key]
    fx = cv2.resize(flow[..., 0], (W, H), interpolation=cv2.INTER_LINEAR) * (W / sw)
    fy = cv2.resize(flow[..., 1], (W, H), interpolation=cv2.INTER_LINEAR) * (H / sh)
    return cv2.remap(src, gx + fx, gy + fy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)


def temporal_clean(prev: np.ndarray | None, cur: np.ndarray, nxt: np.ndarray | None, cfg_dust: dict,
                   cfg_noise: dict) -> tuple[np.ndarray, float]:
    """Elimina motas y reduce ruido usando los vecinos alineados por flujo óptico.
    Devuelve (fotograma, proporción de píxeles corregidos como polvo)."""
    if prev is None and nxt is None:
        return cur, 0.0
    prev = prev if prev is not None else nxt
    nxt = nxt if nxt is not None else prev
    cg = A.small_gray(cur)
    pg = A.small_gray(prev)
    ng = A.small_gray(nxt)
    fp = A.dense_flow(cg, pg)
    fn = A.dense_flow(cg, ng)
    if G.device() is not None:
        try:
            return G.temporal_clean(prev, cur, nxt, (fp, fn), cfg_dust, cfg_noise)
        except Exception as exc:  # noqa: BLE001  (CUDA ocupada, sin memoria, driver...)
            G.desactivar(f"la GPU falló durante la limpieza ({type(exc).__name__}: {exc})"[:300])
    pw = _warp_full(prev, fp, cg.shape)
    nw = _warp_full(nxt, fn, cg.shape)

    out = cur.astype(np.float32)
    ratio = 0.0
    if cfg_dust.get("activo", True):
        scale = (cur.shape[1] / 1440.0) ** 2
        m = A.dust_mask(cur, pw, nw, thr=cfg_dust.get("umbral", 28),
                        max_area=int(cfg_dust.get("area_max", 400) * max(scale, 0.25)))
        if m.any():
            ratio = float(m.mean())
            fill = (pw.astype(np.float32) + nw.astype(np.float32)) / 2
            soft = cv2.GaussianBlur(m.astype(np.float32), (0, 0), 1.0)[..., None]
            soft = np.clip(soft * 1.5, 0, 1)
            out = out * (1 - soft) + fill * soft

    t = float(cfg_noise.get("temporal", 0.0))
    keep = float(cfg_noise.get("grano", 0.5))
    wmix = t * (1 - keep)
    if wmix > 0:
        inv = 1.0 / (14.0 * 3)
        pf, nf = pw.astype(np.float32), nw.astype(np.float32)
        wp = cv2.absdiff(pf, out).sum(axis=2) * inv
        wn = cv2.absdiff(nf, out).sum(axis=2) * inv
        wp = np.maximum(0, 1 - wp * wp)[..., None]   # aproximación barata de exp(-x²)
        wn = np.maximum(0, 1 - wn * wn)[..., None]
        avg = (out + wp * pf + wn * nf) / (1 + wp + wn)
        out = cv2.addWeighted(out, 1 - wmix, avg, wmix, 0)
    return np.clip(out, 0, 255).astype(np.uint8), ratio


def remove_scratches(frame: np.ndarray, thr: float = 5.0) -> tuple[np.ndarray, int]:
    """Detecta rayas verticales estrechas y las rellena por inpainting."""
    g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    cols = A.scratch_columns(g, thr)
    if not cols.any():
        return frame, 0
    mask = np.zeros(g.shape, np.uint8)
    mask[:, cols] = 255
    mask = cv2.dilate(mask, np.ones((1, 3), np.uint8))
    return cv2.inpaint(frame, mask, 3, cv2.INPAINT_TELEA), int(cols.sum())


def spatial_denoise(frame: np.ndarray, strength: float) -> np.ndarray:
    if strength <= 0:
        return frame
    h = 3 + 9 * strength
    return cv2.fastNlMeansDenoisingColored(frame, None, h, h * 0.8, 5, 15)


def color_correct(frame: np.ndarray, gains, low: float, high: float, saturation: float) -> np.ndarray:
    # Tabla de consulta por canal: ganancia + niveles en una sola pasada
    x = np.arange(256, dtype=np.float32)
    k = 255.0 / (high - low) if high - low > 10 else 1.0
    lo = low if high - low > 10 else 0.0
    luts = [np.clip((x * g - lo) * k, 0, 255).astype(np.uint8) for g in gains]
    f = cv2.merge([cv2.LUT(ch, lut) for ch, lut in zip(cv2.split(frame), luts)])
    if abs(saturation - 1.0) > 1e-3:
        gray = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
        g3 = cv2.merge([gray, gray, gray])
        f = cv2.addWeighted(f, saturation, g3, 1.0 - saturation, 0)
    return f


def adaptive_sharpen(frame: np.ndarray, amount: float, radius: float = 1.2) -> np.ndarray:
    """Máscara de enfoque ponderada por bordes: realza contornos sin amplificar zonas planas."""
    if amount <= 0:
        return frame
    f = frame.astype(np.float32)
    blur = cv2.GaussianBlur(f, (0, 0), radius)
    detail = f - blur
    g = cv2.cvtColor(cv2.GaussianBlur(frame, (0, 0), 1.0), cv2.COLOR_BGR2GRAY).astype(np.float32)
    mag = cv2.magnitude(cv2.Sobel(g, cv2.CV_32F, 1, 0), cv2.Sobel(g, cv2.CV_32F, 0, 1))
    w = np.clip(mag / 60.0, 0, 1)[..., None]
    out = f + amount * 1.5 * detail * w
    return np.clip(out, 0, 255).astype(np.uint8)


def regrain(frame: np.ndarray, amount: float, seed: int) -> np.ndarray:
    """Grano sintético dependiente de la luminancia (más en medios tonos)."""
    if amount <= 0:
        return frame
    rng = np.random.default_rng(seed)
    h, w = frame.shape[:2]
    noise = rng.standard_normal((h, w)).astype(np.float32)
    noise = cv2.GaussianBlur(noise, (0, 0), 0.7 * max(1.0, w / 1920))
    noise /= noise.std() + 1e-6
    lum = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0
    weight = 0.35 + 2.6 * lum * (1 - lum)
    chroma = rng.standard_normal((h, w, 3)).astype(np.float32) * 0.15
    grain = (noise[..., None] + chroma) * (weight[..., None] * amount * 14.0)
    return np.clip(frame.astype(np.float32) + grain, 0, 255).astype(np.uint8)


STANDARD_HEIGHTS = (720, 1080, 1440, 2160)


def finish(frame: np.ndarray, sharp: float, radius: float, grain: float, seed: int) -> np.ndarray:
    """Nitidez + grano del acabado, en GPU si está disponible."""
    if G.device() is not None:
        try:
            return G.sharpen_and_grain(frame, sharp, radius, grain, seed)
        except Exception as exc:  # noqa: BLE001
            G.desactivar(f"la GPU falló durante el acabado ({type(exc).__name__}: {exc})"[:300])
    return regrain(adaptive_sharpen(frame, sharp, radius), grain, seed)


def fit_canvas_vf(w: int, h: int, canvas: str) -> str | None:
    """Filtro FFmpeg final: con '16:9' ajusta a una altura estándar (720/1080/1440/2160)
    y añade bandas laterales sin deformar la imagen 4:3."""
    if canvas != "16:9":
        return None if (w % 2 == 0 and h % 2 == 0) else "crop=trunc(iw/2)*2:trunc(ih/2)*2"
    H = next((s for s in STANDARD_HEIGHTS if s >= 0.9 * h), STANDARD_HEIGHTS[-1])
    W = H * 16 // 9
    # Encajar dentro del lienzo (también si el recorte dejó una imagen más ancha que 16:9)
    return (f"scale={W}:{H}:force_original_aspect_ratio=decrease:force_divisible_by=2:flags=lanczos,setsar=1,"
            f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:black")
