"""Aceleración con PyTorch (CUDA) de los filtros más costosos del máster y del acabado.

Si PyTorch o CUDA no están disponibles, el resto del programa usa las versiones de OpenCV.
El flujo óptico se sigue calculando en CPU a baja resolución (DIS es rápido); la deformación
a resolución completa, la detección de motas, el promedio temporal, la nitidez y el grano
se hacen en la GPU."""
from __future__ import annotations

import os
import shutil
import subprocess

import numpy as np

try:  # pragma: no cover - depende del equipo
    import torch
    import torch.nn.functional as TF
except Exception:  # noqa: BLE001
    torch = None
    TF = None

_DEVICE = None
_MOTIVO = ""
_GRID = {}


def device():
    """Dispositivo PyTorch activo o None. RESTAURA8_DISPOSITIVO=cpu|cuda lo fuerza."""
    global _DEVICE
    if _DEVICE is not None:
        return _DEVICE if _DEVICE != "none" else None
    want = os.environ.get("RESTAURA8_DISPOSITIVO", "auto").lower()
    if torch is None or want == "opencv":
        _DEVICE = "none"
    elif want == "cpu":
        _DEVICE = torch.device("cpu")
    elif torch.cuda.is_available():
        _DEVICE = torch.device("cuda")
        torch.backends.cudnn.benchmark = True
    else:
        _DEVICE = "none"
    return _DEVICE if _DEVICE != "none" else None


def nombre_gpu() -> str:
    """Nombre de la GPU según nvidia-smi: no crea contexto CUDA (que bloquearía la tarjeta)."""
    exe = shutil.which("nvidia-smi") or r"C:\Windows\System32\nvidia-smi.exe"
    try:
        r = subprocess.run([exe, "--query-gpu=name", "--format=csv,noheader"],
                           capture_output=True, text=True, timeout=15)
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout.strip().splitlines()[0].strip()
    except Exception:  # noqa: BLE001
        pass
    return "NVIDIA"


def describe() -> str:
    d = device()
    if d is None:
        if _MOTIVO:
            return f"CPU (OpenCV) — {_MOTIVO}"
        return "CPU (OpenCV)" + ("" if torch is not None else " — PyTorch no instalado")
    if d.type == "cuda":
        return f"GPU {nombre_gpu()} (PyTorch {torch.__version__})"
    return f"CPU (PyTorch {torch.__version__})"


def desactivar(motivo: str) -> None:
    """Pasa a CPU en caliente (por ejemplo si CUDA falla a mitad de un trabajo)."""
    global _DEVICE, _MOTIVO
    _DEVICE = "none"
    _MOTIVO = motivo
    _GRID.clear()
    print(f"[aviso] Se continúa por CPU: {motivo}", flush=True)


def _nvidia_smi(args: list[str]) -> str:
    exe = shutil.which("nvidia-smi") or r"C:\Windows\System32\nvidia-smi.exe"
    try:
        r = subprocess.run([exe, *args], capture_output=True, text=True, timeout=15)
        if r.returncode == 0:
            return r.stdout.strip()
    except Exception:  # noqa: BLE001
        pass
    return ""


def modo_computo() -> str:
    lineas = _nvidia_smi(["--query-gpu=compute_mode", "--format=csv,noheader"]).splitlines()
    return lineas[0].strip() if lineas else ""


# Procesos que usan la GPU solo para dibujar la pantalla: no compiten por CUDA.
_GRAFICOS = {"explorer.exe", "searchhost.exe", "startmenuexperiencehost.exe", "dwm.exe", "shellexperiencehost.exe",
             "textinputhost.exe", "widgets.exe", "sihost.exe", "applicationframehost.exe", "lockapp.exe"}


def procesos_gpu() -> list[str]:
    """Programas que están usando la GPU para cómputo, con su memoria.
    Se descartan los del escritorio de Windows, que solo la usan para dibujar."""
    salida = _nvidia_smi(["--query-compute-apps=pid,process_name,used_memory", "--format=csv,noheader"])
    fuera = []
    yo = str(os.getpid())
    for linea in salida.splitlines():
        partes = [x.strip() for x in linea.split(",")]
        if len(partes) < 3 or partes[0] == yo:
            continue
        nombre = os.path.basename(partes[1])
        if nombre.lower() in _GRAFICOS:
            continue
        if "insufficient permissions" in nombre.lower():
            fuera.append("un programa que Windows no deja identificar sin permisos de administrador")
            continue
        mem = partes[2]
        fuera.append(nombre + ("" if mem.upper().startswith("[N/A") else f" ({mem})"))
    return fuera


def sesion_remota() -> bool:
    """En una sesión de Escritorio remoto, Windows no da acceso CUDA a la tarjeta."""
    s = os.environ.get("SESSIONNAME", "")
    return s.upper().startswith(("RDP-", "ICA-"))


def prueba_en_subproceso() -> tuple[bool, str]:
    """Prueba CUDA en un proceso nuevo y limpio: distingue 'la máquina no puede'
    de 'este proceso concreto no puede'."""
    import sys
    codigo = ("import torch;t=torch.zeros(8,8,device='cuda');print('OK',torch.version.cuda,"
              "torch.cuda.get_device_name(0))")
    try:
        r = subprocess.run([sys.executable, "-c", codigo], capture_output=True, text=True, timeout=180)
        return r.returncode == 0, (r.stdout + r.stderr).strip()[-600:]
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


def volcado_diagnostico(destino=None) -> str:
    """Escribe todo lo que hace falta para entender por qué CUDA no arranca."""
    import platform
    import sys
    from datetime import datetime
    from pathlib import Path

    if destino is None:
        destino = Path(__file__).resolve().parent.parent / "run" / "gpu_diagnostico.txt"
    destino = Path(destino)
    ok_sub, salida_sub = prueba_en_subproceso()
    partes = [
        f"===== {datetime.now():%Y-%m-%d %H:%M:%S} =====",
        f"Windows: {platform.platform()}  ·  usuario: {os.environ.get('USERNAME', '?')}",
        f"SESSIONNAME: {os.environ.get('SESSIONNAME', '(no definida)')}"
        + ("   <-- SESIÓN REMOTA: Windows no da acceso CUDA en Escritorio remoto" if sesion_remota() else ""),
        f"Python: {sys.version.split()[0]}  ·  {sys.executable}",
        f"PyTorch: {getattr(torch, '__version__', 'no instalado')}  ·  CUDA de la compilación: "
        f"{getattr(getattr(torch, 'version', None), 'cuda', '?')}",
        f"Prueba de CUDA en un proceso limpio: {'FUNCIONA' if ok_sub else 'FALLA'}",
        salida_sub,
        "--- nvidia-smi --query-gpu ---",
        _nvidia_smi(["--query-gpu=name,driver_version,compute_mode,display_mode,display_active,persistence_mode,"
                     "memory.used,memory.total,utilization.gpu", "--format=csv"]),
        "--- nvidia-smi (tabla de procesos) ---",
        _nvidia_smi([]),
    ]
    texto = "\n".join(str(x) for x in partes) + "\n\n"
    try:
        destino.parent.mkdir(parents=True, exist_ok=True)
        with open(destino, "a", encoding="utf-8", errors="replace") as fh:
            fh.write(texto)
    except Exception:  # noqa: BLE001
        pass
    return texto


def memoria_gpu() -> tuple[int, int]:
    """(MiB usados, MiB totales) o (0, 0) si no se puede saber."""
    linea = _nvidia_smi(["--query-gpu=memory.used,memory.total", "--format=csv,noheader,nounits"]).splitlines()
    if not linea:
        return 0, 0
    try:
        usada, total = [int(x.strip()) for x in linea[0].split(",")[:2]]
        return usada, total
    except Exception:  # noqa: BLE001
        return 0, 0


def version_driver() -> str:
    lineas = _nvidia_smi(["--query-gpu=driver_version", "--format=csv,noheader"]).splitlines()
    return lineas[0].strip() if lineas else ""


def cuda_del_driver() -> str:
    """Versión máxima de CUDA que admite el controlador instalado."""
    import re
    m = re.search(r"CUDA Version:\s*([0-9.]+)", _nvidia_smi([]))
    return m.group(1) if m else ""


def _driver_insuficiente() -> str:
    """Compara la CUDA del controlador con la de PyTorch. Es la causa más habitual
    de 'busy or unavailable' con la tarjeta libre."""
    if torch is None:
        return ""
    cuda_torch = getattr(getattr(torch, "version", None), "cuda", "") or ""
    cuda_drv = cuda_del_driver()
    try:
        if cuda_torch and cuda_drv and float(cuda_drv) < float(".".join(cuda_torch.split(".")[:2])):
            return (f"el controlador NVIDIA ({version_driver()}) llega solo hasta CUDA {cuda_drv} y este PyTorch "
                    f"necesita CUDA {cuda_torch}: actualiza el controlador o reinstala PyTorch con una "
                    f"compilación más antigua (scripts\\instalar.ps1 -Reintentar)")
    except ValueError:
        pass
    return ""


def diagnostico_gpu() -> str:
    partes = []
    if sesion_remota():
        partes.append("estás en una sesión de Escritorio remoto, y Windows no da acceso CUDA desde ahí "
                      "(hay que ejecutar la app en el equipo, o usar VNC/AnyDesk en vez de RDP)")
    modo = modo_computo()
    if modo and modo.lower() not in ("default", "n/a"):
        partes.append(f"la tarjeta está en modo de cómputo '{modo}', que solo admite un programa a la vez")
    drv = _driver_insuficiente()
    if drv:
        partes.append(drv)
    usada, total = memoria_gpu()
    if total and usada > 0.5 * total:
        apps = procesos_gpu()
        partes.append(f"hay {usada} MiB de {total} MiB ocupados"
                      + (" (" + ", ".join(apps[:3]) + ")" if apps else ""))
    elif total and not partes:
        partes.append(f"la tarjeta está libre ({usada} MiB de {total} MiB), así que no la bloquea otro programa: "
                      "el detalle está en run\\gpu_diagnostico.txt")
    return "; ".join(partes)


def comprobar(intentos: int = 3, espera: float = 6.0) -> bool:
    """Prueba de verdad la GPU (una operación pequeña). Si falla, pasa a CPU y explica por qué.
    Evita abortar un trabajo largo a mitad por una tarjeta ocupada por otro programa."""
    import time

    d = device()
    if d is None or d.type != "cuda":
        return False
    ultimo = ""
    for intento in range(1, max(1, intentos) + 1):
        try:
            t = torch.zeros((8, 8), device=d)
            _ = (t + 1).sum().item()
            if intento > 1:
                print(f"[aviso] La GPU ya está libre (intento {intento}).", flush=True)
            return True
        except Exception as exc:  # noqa: BLE001
            ultimo = f"{type(exc).__name__}: {exc}"
            pista = diagnostico_gpu()
            if intento < intentos:
                detalle = pista or "sin programas de cómputo a la vista"
                print(f"[aviso] La GPU no responde ({detalle}). "
                      f"Reintento {intento}/{intentos - 1} en {espera:.0f} s.", flush=True)
                time.sleep(espera)
                # Un contexto CUDA fallido no se recupera dentro del proceso; se reevalúa igualmente
                try:
                    torch.cuda.synchronize()
                except Exception:  # noqa: BLE001
                    pass
    pista = diagnostico_gpu()
    volcado_diagnostico()
    if not pista:
        pista = ("no se ve ningún programa ocupándola; el detalle está en run\\gpu_diagnostico.txt")
    desactivar((f"no se pudo usar la GPU ({ultimo})" + (f" — {pista}" if pista else ""))[:400])
    return False


def to_t(img: np.ndarray):
    """uint8 HxWx3 → float32 1x3xHxW en [0, 255]."""
    return torch.from_numpy(np.ascontiguousarray(img)).to(device(), non_blocking=True) \
        .permute(2, 0, 1).unsqueeze(0).float()


def to_np(t) -> np.ndarray:
    return t.clamp(0, 255).round().byte().squeeze(0).permute(1, 2, 0).contiguous().cpu().numpy()


def _gray(t):
    return (0.114 * t[:, 0:1] + 0.587 * t[:, 1:2] + 0.299 * t[:, 2:3])  # BGR


def _base_grid(h, w):
    key = (h, w)
    if key not in _GRID:
        ys = torch.linspace(-1, 1, h, device=device())
        xs = torch.linspace(-1, 1, w, device=device())
        gy, gx = torch.meshgrid(ys, xs, indexing="ij")
        _GRID[key] = torch.stack((gx, gy), dim=-1).unsqueeze(0)
    return _GRID[key]


def warp(src, flow_small: np.ndarray):
    """Deforma src (1x3xHxW) con un flujo calculado a baja resolución (hxwx2, píxeles)."""
    _, _, H, W = src.shape
    sh, sw = flow_small.shape[:2]
    f = torch.from_numpy(flow_small).to(device()).permute(2, 0, 1).unsqueeze(0)
    f = TF.interpolate(f, size=(H, W), mode="bilinear", align_corners=False)
    fx = f[:, 0] * (W / sw) * (2.0 / max(W - 1, 1))
    fy = f[:, 1] * (H / sh) * (2.0 / max(H - 1, 1))
    grid = _base_grid(H, W) + torch.stack((fx, fy), dim=-1)
    return TF.grid_sample(src, grid, mode="bilinear", padding_mode="border", align_corners=True)


def _lowpass(x, factor=16):
    _, _, h, w = x.shape
    s = TF.interpolate(x, size=(max(2, h // factor), max(2, w // factor)), mode="area")
    s = _blur(s, 1.0)
    return TF.interpolate(s, size=(h, w), mode="bilinear", align_corners=False)


def _gauss_kernel(sigma: float):
    r = max(1, int(round(3 * sigma)))
    x = torch.arange(-r, r + 1, device=device(), dtype=torch.float32)
    k = torch.exp(-(x ** 2) / (2 * sigma * sigma))
    return k / k.sum(), r


def _blur(x, sigma: float):
    k, r = _gauss_kernel(sigma)
    c = x.shape[1]
    kx = k.view(1, 1, 1, -1).repeat(c, 1, 1, 1)
    ky = k.view(1, 1, -1, 1).repeat(c, 1, 1, 1)
    x = TF.conv2d(TF.pad(x, (r, r, 0, 0), mode="replicate"), kx, groups=c)
    return TF.conv2d(TF.pad(x, (0, 0, r, r), mode="replicate"), ky, groups=c)


def _median5(x):
    """Mediana 5x5 sobre 1x1xHxW."""
    p = TF.pad(x, (2, 2, 2, 2), mode="replicate")
    u = TF.unfold(p, 5)  # 1x25xN
    med = u.median(dim=1).values
    return med.view_as(x)


def _dust_mask(c, p, n, thr, agree, max_area):
    cg, pg, ng = _gray(c), _gray(p), _gray(n)
    cb = _lowpass(cg) + 1
    pg = pg * cb / (_lowpass(pg) + 1)
    ng = ng * cb / (_lowpass(ng) + 1)
    dp, dn = cg - pg, cg - ng
    local = cg - _median5(cg)
    m = ((dp.abs() > thr) & (dn.abs() > thr) & (torch.sign(dp) == torch.sign(dn))
         & ((pg - ng).abs() < agree) & (local.abs() > thr * 0.6) & (torch.sign(local) == torch.sign(dp)))
    m = m.float()
    # Descartar manchas grandes: la densidad local de una mota pequeña es baja.
    side = int(np.clip(np.sqrt(max_area) * 1.5, 5, 61)) | 1
    dens = TF.avg_pool2d(m, side, stride=1, padding=side // 2, count_include_pad=False)
    m = m * (dens * side * side <= max_area).float()
    return TF.max_pool2d(m, 5, stride=1, padding=2)  # dilatación 5x5


def temporal_clean(prev: np.ndarray | None, cur: np.ndarray, nxt: np.ndarray | None,
                   flows: tuple[np.ndarray, np.ndarray] | None, cfg_dust: dict, cfg_noise: dict):
    """Versión GPU de filters.temporal_clean. `flows` = (flujo cur→prev, flujo cur→next)."""
    if prev is None and nxt is None:
        return cur, 0.0
    prev = prev if prev is not None else nxt
    nxt = nxt if nxt is not None else prev
    with torch.inference_mode():
        c = to_t(cur)
        pw = warp(to_t(prev), flows[0])
        nw = warp(to_t(nxt), flows[1])
        out = c
        ratio = 0.0
        if cfg_dust.get("activo", True):
            scale = (cur.shape[1] / 1440.0) ** 2
            m = _dust_mask(c, pw, nw, float(cfg_dust.get("umbral", 28)), 14.0,
                           int(cfg_dust.get("area_max", 400) * max(scale, 0.25)))
            ratio = float(m.mean())
            if ratio > 0:
                soft = (_blur(m, 1.0) * 1.5).clamp(0, 1)
                out = out * (1 - soft) + (pw + nw) / 2 * soft
        t = float(cfg_noise.get("temporal", 0.0))
        wmix = t * (1 - float(cfg_noise.get("grano", 0.5)))
        if wmix > 0:
            inv = 1.0 / (14.0 * 3)
            wp = (1 - ((pw - out).abs().sum(1, keepdim=True) * inv) ** 2).clamp_min(0)
            wn = (1 - ((nw - out).abs().sum(1, keepdim=True) * inv) ** 2).clamp_min(0)
            avg = (out + wp * pw + wn * nw) / (1 + wp + wn)
            out = out * (1 - wmix) + avg * wmix
        return to_np(out), ratio


def _sobel_mag(g):
    kx = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], device=device(), dtype=torch.float32).view(1, 1, 3, 3)
    gp = TF.pad(g, (1, 1, 1, 1), mode="replicate")
    gx = TF.conv2d(gp, kx)
    gy = TF.conv2d(gp, kx.transpose(2, 3))
    return torch.sqrt(gx * gx + gy * gy)


def sharpen_and_grain(frame: np.ndarray, amount: float, radius: float, grain: float, seed: int) -> np.ndarray:
    """Nitidez adaptativa + grano sintético en un solo viaje a la GPU."""
    if amount <= 0 and grain <= 0:
        return frame
    with torch.inference_mode():
        f = to_t(frame)
        if amount > 0:
            detail = f - _blur(f, radius)
            g = _gray(_blur(f, 1.0))
            w = (_sobel_mag(g) / 60.0).clamp(0, 1)
            f = f + amount * 1.5 * detail * w
        if grain > 0:
            gen = torch.Generator(device=device()).manual_seed(int(seed))
            _, _, h, wd = f.shape
            noise = torch.randn((1, 1, h, wd), generator=gen, device=device())
            noise = _blur(noise, 0.7 * max(1.0, wd / 1920))
            noise = noise / (noise.std() + 1e-6)
            lum = (_gray(f) / 255.0).clamp(0, 1)
            weight = 0.35 + 2.6 * lum * (1 - lum)
            chroma = torch.randn((1, 3, h, wd), generator=gen, device=device()) * 0.15
            f = f + (noise + chroma) * weight * grain * 14.0
        return to_np(f)
