"""Informe final en HTML: qué se ha cambiado, con cifras y fotogramas antes/después."""
from __future__ import annotations

import base64
import html
import subprocess
import tempfile
from pathlib import Path

from .video_io import probe

CSS = """
:root{--bg:#f6f3ee;--panel:#fffdf9;--ink:#1f1b16;--muted:#6c6358;--line:#e2d9cc;--accent:#b8501a;--ok:#2f7d4f}
@media (prefers-color-scheme:dark){:root{--bg:#15130f;--panel:#1e1b17;--ink:#f0ebe3;--muted:#a89e91;--line:#38322b;--accent:#e0773a;--ok:#6cc08d}}
*{box-sizing:border-box}
body{margin:0;padding:28px 20px 60px;background:var(--bg);color:var(--ink);
 font:15px/1.5 "Segoe UI",system-ui,-apple-system,sans-serif}
.wrap{max-width:1000px;margin:0 auto}
h1{font-size:23px;margin:0 0 4px} h2{font-size:17px;margin:30px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--line)}
.sub{color:var(--muted);font-size:13px;margin-bottom:22px}
table{border-collapse:collapse;width:100%;background:var(--panel);border:1px solid var(--line);border-radius:10px;overflow:hidden}
th,td{padding:9px 12px;text-align:left;border-bottom:1px solid var(--line);vertical-align:top}
th{font-size:12px;text-transform:uppercase;letter-spacing:.4px;color:var(--muted);font-weight:600}
tr:last-child td{border-bottom:0}
td.n{font-variant-numeric:tabular-nums;white-space:nowrap}
.tarjetas{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:12px;margin:8px 0 4px}
.t{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:11px 13px}
.t .k{font-size:11px;text-transform:uppercase;letter-spacing:.4px;color:var(--muted)}
.t .v{font-size:19px;font-weight:600;margin-top:3px}
.par{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:14px 0;align-items:start}
.par figure{margin:0}
.par img{width:100%;border-radius:8px;border:1px solid var(--line);background:#000;display:block}
.par figcaption{font-size:12px;color:var(--muted);margin-top:5px}
.nota{background:var(--panel);border-left:3px solid var(--accent);border-radius:0 8px 8px 0;padding:10px 13px;margin:12px 0;font-size:14px}
ul{margin:8px 0 0 18px;padding:0} li{margin:3px 0}
footer{margin-top:34px;color:var(--muted);font-size:12px}
"""


def _fotograma(video: Path, t: float, ancho: int = 760) -> str | None:
    """Fotograma en el segundo t, como JPEG en base64 (para incrustarlo en el HTML)."""
    try:
        with tempfile.TemporaryDirectory() as tmp:
            dst = Path(tmp) / "f.jpg"
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{max(t, 0):.3f}", "-i", str(video),
                            "-frames:v", "1", "-vf", f"scale={ancho}:-2:flags=lanczos", "-q:v", "4", str(dst)],
                           check=True, timeout=120)
            return base64.b64encode(dst.read_bytes()).decode()
    except Exception:  # noqa: BLE001
        return None


def _img(b64: str | None, pie: str) -> str:
    if not b64:
        return f"<figure><figcaption>{html.escape(pie)} (no se pudo extraer)</figcaption></figure>"
    return (f'<figure><img src="data:image/jpeg;base64,{b64}" alt="{html.escape(pie)}">'
            f'<figcaption>{html.escape(pie)}</figcaption></figure>')


def _fila(concepto: str, antes: str, despues: str, nota: str = "") -> str:
    return (f"<tr><td>{html.escape(concepto)}</td><td class='n'>{html.escape(antes)}</td>"
            f"<td class='n'>{html.escape(despues)}</td><td>{nota}</td></tr>")


def _mb(p: Path) -> str:
    try:
        b = p.stat().st_size
    except OSError:
        return "—"
    return f"{b / 1e9:.2f} GB" if b > 1e9 else f"{b / 1e6:.0f} MB"


def _dur(s: float) -> str:
    s = int(round(s))
    h, m = divmod(s // 60, 60)
    return (f"{h} h {m:02d} min" if h else f"{m} min {s % 60:02d} s") if s >= 60 else f"{s} s"


def crear(destino: Path, src: Path, master: Path, mejorado: Path | None, receta: dict,
          stats: dict, tiempos: dict, escenas: int, dispositivo: str, motores: dict,
          codificador: str, notas_diagnostico: list[str] | None = None) -> Path:
    """Escribe el informe HTML y devuelve su ruta."""
    o = probe(src)
    m = probe(master)
    e = probe(mejorado) if mejorado and Path(mejorado).exists() else None
    fin = e or m
    norm, est, mej = receta["normalizar"], receta["estabilizar"], receta["mejora"]
    smaster = stats.get("master", {})
    snorm = stats.get("normalizar", {})

    filas = [
        _fila("Resolución", f"{o.width}×{o.height}", f"{fin.width}×{fin.height}",
              "Recorte de los bordes de ventanilla" + (f", escalado ×{mej['escala']}" if e and mej.get("escala", 1) > 1 else "")),
        _fila("Cadencia", f"{o.fps_float:.3f} fps", f"{fin.fps_float:.3f} fps",
              {"deducida": "Deducida de los duplicados del telecine",
               "contenedor": "La del archivo ya era de película",
               "conservada": "No se pudo deducir: se conservó la del archivo"}.get(
                  stats.get("cadencia_origen", ""), "")),
        _fila("Duración", _dur(o.duration), _dur(fin.duration),
              "Igual: no se ha alterado la velocidad" if abs(o.duration - fin.duration) < 0.5
              else "<b>Ha cambiado la velocidad de la película</b>"),
        _fila("Fotogramas", str(o.nb_frames), str(fin.nb_frames),
              (f"{snorm.get('descartados', 0)} duplicados eliminados; " if snorm.get("descartados") else "")
              + (f"interpolados con {motores.get('interpolacion', '')}" if e and mej.get("fps_salida") else "")),
        _fila("Tamaño", _mb(src), _mb(Path(mejorado) if e else master), ""),
    ]

    cambios = []
    if norm.get("recorte"):
        x, y, w, h = norm["recorte"]
        cambios.append(f"<b>Encuadre:</b> recortados los bordes y la perforación → {w}×{h} desde ({x}, {y}).")
    if norm.get("desentrelazar"):
        cambios.append("<b>Entrelazado:</b> eliminado con bwdif.")
    if est.get("activo"):
        cambios.append(f"<b>Estabilización:</b> vaivén corregido al {est.get('vaiven', 1) * 100:.0f} %, "
                       f"suavizado de cámara al {est.get('camara', 0) * 100:.0f} %, "
                       f"ampliación ×{est.get('zoom', 1):.2f} para ocultar bordes.")
    if receta["deflicker"].get("activo"):
        cambios.append("<b>Parpadeo:</b> brillo igualado por escena"
                       + (" y por zonas (hotspot de proyector)." if receta["deflicker"].get("zonas") else "."))
    polvo = smaster.get("polvo_medio_pct", 0)
    cambios.append(f"<b>Motas:</b> corregido el {polvo:.4f} % de los píxeles por fotograma"
                   + (" (material ya muy limpio, o umbral alto)." if polvo < 0.001 else "."))
    rayas = smaster.get("columnas_raya_por_fotograma", 0)
    cambios.append(f"<b>Rayas verticales:</b> {rayas:.1f} columnas corregidas por fotograma de media."
                   if rayas else "<b>Rayas verticales:</b> no se detectaron.")
    cambios.append(f"<b>Ruido y grano:</b> reducción temporal al {receta['ruido'].get('temporal', 0) * 100:.0f} %, "
                   f"conservando el {receta['ruido'].get('grano', 0) * 100:.0f} % del grano original.")
    if receta["color"].get("activo"):
        cambios.append(f"<b>Color:</b> balance de blancos y niveles por escena "
                       f"({receta['color'].get('balance', 0) * 100:.0f} % y {receta['color'].get('niveles', 0) * 100:.0f} %), "
                       f"saturación ×{receta['color'].get('saturacion', 1):.2f}.")
    if e:
        modelo = mej.get("modelo_pth") if motores.get("escalado") == "spandrel" else mej.get("modelo_escala")
        cambios.append(f"<b>Escalado:</b> ×{mej.get('escala')} con {motores.get('escalado')} "
                       f"(modelo {modelo}), mezcla con Lanczos al {mej.get('mezcla_ia', 0) * 100:.0f} % de IA.")
        car = receta.get("caras", {})
        if car.get("activo"):
            n = stats.get("caras", {})
            cambios.append(f"<b>Caras:</b> reconstruidas con {car.get('modelo')} al "
                           f"{float(car.get('intensidad', 0)) * 100:.0f} % de intensidad; "
                           f"{n.get('tratadas', 0)} caras en total ({n.get('por_fotograma', 0)} por fotograma). "
                           f"<b>Este paso inventa rasgos</b> y no se aplica al máster.")
        if mej.get("fps_salida"):
            cambios.append(f"<b>Interpolación:</b> a {mej['fps_salida']} fps con {motores.get('interpolacion')} "
                           f"(modelo {mej.get('modelo_interpolacion')}), sin interpolar entre escenas.")
        cambios.append(f"<b>Acabado:</b> nitidez {mej.get('nitidez', 0) * 100:.0f} %, "
                       f"grano añadido {mej.get('regranulado', 0) * 100:.0f} %, "
                       f"lienzo {mej.get('lienzo')}, codificado con {codificador}.")

    # Fotogramas comparados: tres momentos de la película
    pares = ""
    for frac, etiqueta in ((0.25, "al 25 %"), (0.5, "a la mitad"), (0.75, "al 75 %")):
        a = _fotograma(src, o.duration * frac)
        b = _fotograma(Path(mejorado) if e else master, fin.duration * frac)
        pares += (f"<div class='par'>{_img(a, f'Original, {etiqueta}')}"
                  f"{_img(b, ('Restaurado y mejorado' if e else 'Restaurado') + f', {etiqueta}')}</div>")

    med = stats.get("medidas") or {}
    tabla_med = ""
    if med.get("antes") and med.get("despues"):
        a_, d_ = med["antes"], med["despues"]

        def fila_med(nombre, clave, unidad="", mejor="menos", nota=""):
            va, vd = a_.get(clave), d_.get(clave)
            if va is None or vd is None:
                return ""
            if va:
                cambio = (vd - va) / abs(va) * 100
                bien = (cambio < -3) if mejor == "menos" else (cambio > 3)
                col = "var(--ok)" if bien else ("var(--muted)" if abs(cambio) <= 3 else "var(--accent)")
                txt = f'<span style="color:{col}">{cambio:+.0f} %</span>'
            else:
                txt = "—"
            return (f"<tr><td>{html.escape(nombre)}</td><td class='n'>{va}{unidad}</td>"
                    f"<td class='n'>{vd}{unidad}</td><td class='n'>{txt}</td><td>{nota}</td></tr>")

        tabla_med = f"""<h2>Medido, no supuesto</h2>
<div class="sub">Comparación entre el vídeo ya normalizado (mismo recorte y misma cadencia) y el máster
restaurado, sobre 12 fotogramas repartidos por la película. Así se aísla lo que han hecho los filtros.</div>
<table><tr><th>Medida</th><th>Antes</th><th>Máster</th><th>Cambio</th><th>Qué significa</th></tr>
{fila_med("Ruido (σ)", "ruido", "", "menos", "Menos es mejor, salvo que se lleve por delante el grano.")}
{fila_med("Temblor residual", "temblor", " px", "menos", "Movimiento que queda respecto a la trayectoria suavizada.")}
{fila_med("Parpadeo", "parpadeo", "", "menos", "Variación de brillo entre fotogramas.")}
{fila_med("Nitidez (bordes)", "nitidez", "", "mas", "Energía de bordes: sube con el realce, y también con el ruido.")}
{fila_med("Detalle real", "corte_espectral", "", "mas", "Frecuencia de corte, 1 = el máximo que permite la resolución.")}
{fila_med("Resolución útil", "resolucion_util", " px", "mas", "Ancho con información real. Escalar por encima del doble no añade detalle.")}
</table>"""

    t_filas = "".join(f"<tr><td>{html.escape(k)}</td><td class='n'>{_dur(v)}</td></tr>"
                      for k, v in tiempos.items() if v >= 1)

    notas = "".join(f"<div class='nota'>{html.escape(n)}</div>" for n in (notas_diagnostico or []))

    doc = f"""<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Informe de restauración — {html.escape(src.name)}</title><style>{CSS}</style></head><body><div class="wrap">
<h1>Informe de restauración</h1>
<div class="sub">{html.escape(src.name)} · procesado en {html.escape(dispositivo)} · {html.escape(_dur(sum(tiempos.values())))} de proceso</div>

<div class="tarjetas">
  <div class="t"><div class="k">Resolución final</div><div class="v">{fin.width}×{fin.height}</div></div>
  <div class="t"><div class="k">Cadencia final</div><div class="v">{fin.fps_float:.3g} fps</div></div>
  <div class="t"><div class="k">Escenas</div><div class="v">{escenas}</div></div>
  <div class="t"><div class="k">Fotogramas</div><div class="v">{fin.nb_frames}</div></div>
</div>
{notas}

<h2>Qué ha cambiado</h2>
<table><tr><th>Concepto</th><th>Original</th><th>Resultado</th><th>Cómo</th></tr>{''.join(filas)}</table>

<h2>Tratamientos aplicados</h2>
<ul>{''.join(f'<li>{c}</li>' for c in cambios)}</ul>

<h2>Comparación</h2>
<div class="sub">Fotogramas en el mismo punto de la película. El original incluye los bordes de ventanilla.</div>
{pares}

{tabla_med}

<h2>Tiempos</h2>
<table><tr><th>Etapa</th><th>Duración</th></tr>{t_filas}</table>

<h2>Archivos</h2>
<table><tr><th>Archivo</th><th>Qué es</th><th>Tamaño</th></tr>
<tr><td>{html.escape(Path(master).name)}</td><td>Máster fiel, sin pérdida, resolución y cadencia originales. Para conservar.</td><td class="n">{_mb(Path(master))}</td></tr>
{f'<tr><td>{html.escape(Path(mejorado).name)}</td><td>Copia mejorada: escalada, interpolada y con acabado. Para ver y compartir.</td><td class="n">{_mb(Path(mejorado))}</td></tr>' if e else ''}
</table>

<footer>Generado por Restaurador Super 8. La receta exacta está en el archivo <code>_receta.json</code>, y sirve para repetir este mismo resultado.</footer>
</div></body></html>"""
    destino = Path(destino)
    destino.write_text(doc, encoding="utf-8")
    return destino
