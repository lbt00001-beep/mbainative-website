"""Medidas objetivas del material: detalle real, ruido, nitidez, parpadeo y temblor.

Sirven para dos cosas: decidir automáticamente hasta dónde merece la pena procesar
(no tiene sentido escalar por encima del detalle que el escáner capturó) y para
comparar con números el antes y el después en el informe.
"""
from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

from . import analysis as A
from .video_io import probe, read_frames


def corte_espectral(gris: np.ndarray, factor: float = 3.0) -> float:
    """Frecuencia de corte efectiva, como fracción de Nyquist (0–1).

    Se toma el espectro promediado por anillos y se busca dónde la señal se hunde en el
    suelo de ruido (grano y ruido del escáner): ahí acaba el detalle real. Compararlo con
    la energía de las frecuencias bajas no sirve, porque en una imagen natural la energía
    cae como 1/f² y el resultado dependería del tamaño de la imagen.
    """
    g = gris.astype(np.float32)
    g = g - g.mean()
    h, w = g.shape
    if min(h, w) < 64:
        return 0.0
    ventana = np.outer(np.hanning(h), np.hanning(w)).astype(np.float32)
    esp = np.abs(np.fft.fftshift(np.fft.fft2(g * ventana))) ** 2
    cy, cx = h // 2, w // 2
    y, x = np.ogrid[:h, :w]
    r = np.sqrt(((y - cy) / cy) ** 2 + ((x - cx) / cx) ** 2)
    n_bins = 64
    bins = np.linspace(0, 1, n_bins + 1)
    idx = np.digitize(r.ravel(), bins) - 1
    valido = (idx >= 0) & (idx < n_bins)
    suma = np.bincount(idx[valido], esp.ravel()[valido], minlength=n_bins)
    cuenta = np.bincount(idx[valido], minlength=n_bins)
    perfil = suma[:n_bins] / np.maximum(cuenta[:n_bins], 1)
    if perfil.max() <= 0:
        return 0.0
    suelo = float(np.median(perfil[int(n_bins * 0.85):])) or float(perfil.min())
    if suelo <= 0:
        return 1.0
    for i in range(n_bins - 1, 0, -1):
        if perfil[i] > factor * suelo:
            return round(bins[i + 1], 3)
    return round(bins[1], 3)


def nitidez(gris: np.ndarray) -> float:
    """Energía de bordes normalizada por el contraste local (proxy de nitidez)."""
    lap = cv2.Laplacian(gris.astype(np.float32), cv2.CV_32F, ksize=3)
    return float(lap.std() / max(gris.std(), 1.0) * 100)


def metricas(video: str | Path, muestras: int = 16, recorte: list[int] | None = None) -> dict:
    """Recorre unos cuantos fotogramas repartidos y devuelve las medidas medias."""
    info = probe(video)
    total = max(info.nb_frames, 1)
    paso = max(1, total // max(muestras, 1))
    cortes, ruidos, nitideces, lumas, difs = [], [], [], [], []
    previo = None
    for i, fr in enumerate(read_frames(video)):
        g = A.small_gray(fr)                 # siempre del fotograma entero: tamaño constante
        lumas.append(float(g.mean()))
        if previo is not None:
            difs.append(A.frame_diff(previo, g))
        previo = g
        if i % paso and i > 0:
            continue
        trozo = fr
        if recorte:
            x, y, w, h = recorte
            trozo = fr[y:y + h, x:x + w]
        gris = cv2.cvtColor(trozo, cv2.COLOR_BGR2GRAY)
        cortes.append(corte_espectral(gris))
        ruidos.append(A.noise_sigma(gris))
        nitideces.append(nitidez(gris))
        if len(cortes) >= muestras:
            break

    lum = np.array(lumas) if lumas else np.zeros(1)
    residuo = lum - A.smooth_1d(lum, 12)
    return {
        "corte_espectral": round(float(np.median(cortes)), 3) if cortes else 0.0,
        "resolucion_util": int(round((recorte[2] if recorte else info.width) * float(np.median(cortes))))
        if cortes else 0,
        "ruido": round(float(np.median(ruidos)), 2) if ruidos else 0.0,
        "nitidez": round(float(np.median(nitideces)), 2) if nitideces else 0.0,
        "parpadeo": round(float(np.std(residuo)), 2),
        "movimiento": round(float(np.median(difs)), 2) if difs else 0.0,
        "ancho": info.width,
        "alto": info.height,
    }


def temblor(video: str | Path, maximo: int = 240, recorte: list[int] | None = None) -> float:
    """Temblor residual en píxeles: cuánto se mueve la imagen respecto a su
    trayectoria suavizada. Mide de verdad si la estabilización ha servido."""
    previo = None
    trans = []
    for i, fr in enumerate(read_frames(video)):
        if i >= maximo:
            break
        if recorte:   # imprescindible: los bordes de ventanilla son fijos y falsearían la medida
            x, y, w, h = recorte
            fr = fr[y:y + h, x:x + w]
        g = A.small_gray(fr)
        if previo is not None:
            trans.append(A.rigid_transform(previo, g)[:2])
        previo = g
    if len(trans) < 8:
        return 0.0
    t = np.array(trans, float)
    tray = np.cumsum(t, axis=0)
    suave = np.stack([A.smooth_1d(tray[:, k], 3) for k in range(2)], axis=1)
    escala = (recorte[2] if recorte else probe(video).width) / A.ANALYSIS_WIDTH
    return round(float(np.abs(tray - suave).mean() * escala), 2)
