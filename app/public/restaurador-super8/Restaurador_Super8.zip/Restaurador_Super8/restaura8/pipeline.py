"""Orquestación del proceso completo por etapas con caché."""
from __future__ import annotations

import hashlib
import json
import shutil
import time
from fractions import Fraction
from pathlib import Path

import cv2
import numpy as np

from . import analysis as A
from . import backends as B
from . import filters as F
from .recipe import save_recipe
from . import gpu as G
from . import comparar as CMP
from . import informe as INF
from . import medidas as MED
from .video_io import FrameWriter, encoder_works, probe, progress, read_frames, run_ffmpeg


def espacio_libre_gb(ruta: Path) -> float:
    try:
        return shutil.disk_usage(ruta).free / 1e9
    except Exception:  # noqa: BLE001
        return 999.0


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


class Job:
    def __init__(self, src: str | Path, workdir: str | Path, recipe: dict):
        self.src = Path(src).resolve()
        self.work = Path(workdir).resolve()
        self.work.mkdir(parents=True, exist_ok=True)
        self.recipe = recipe
        self.state_path = self.work / "estado.json"
        self.state = json.loads(self.state_path.read_text()) if self.state_path.exists() else {}
        self.info = probe(self.src)
        self.stats = {}
        self.tiempos: dict[str, float] = {}
        self.codificador = "libx264"
        self.notas: list[str] = []      # notas del diagnóstico, para el informe

    # ---------- caché ----------
    def _key(self, *sections: str, extra: str = "") -> str:
        st = self.src.stat()
        payload = json.dumps([str(self.src), st.st_size, st.st_mtime,
                              [self.recipe.get(s) for s in sections], extra], sort_keys=True)
        return hashlib.sha1(payload.encode()).hexdigest()[:16]

    def _cached(self, name: str, key: str, path: Path) -> bool:
        return self.state.get(name) == key and path.exists()

    def _done(self, name: str, key: str) -> None:
        self.state[name] = key
        self.state_path.write_text(json.dumps(self.state, indent=2))

    # ---------- etapa 1: normalización ----------
    def normalize(self) -> Path:
        out = self.work / "01_normalizado.mkv"
        cfg = self.recipe["normalizar"]
        key = self._key("normalizar")
        if self._cached("normalizar", key, out):
            log("Normalización: en caché")
            return out
        vf, size = [], (self.info.width, self.info.height)
        if cfg.get("desentrelazar"):
            vf.append("bwdif=mode=send_frame:parity=auto")
        if cfg.get("recorte"):
            x, y, w, h = cfg["recorte"]
            w, h = w // 2 * 2, h // 2 * 2
            vf.append(f"crop={w}:{h}:{x}:{y}")
            size = (w, h)
        film_fps = Fraction(cfg["film_fps"]).limit_denominator(1001)
        log(f"Normalización → {film_fps} fps, duplicados={'sí' if cfg['quitar_duplicados'] else 'no'}, "
            f"filtros={vf or 'ninguno'}")
        recent: list[float] = []
        prev = None
        kept = dropped = 0
        with FrameWriter(out, size[0], size[1], film_fps) as wr:
            total = self.info.nb_frames
            for n_in, fr in enumerate(read_frames(self.src, ",".join(vf) or None, size)):
                if n_in % 25 == 0:
                    progress("normalizar", n_in, total)
                g = A.small_gray(fr)
                if prev is not None and cfg["quitar_duplicados"]:
                    d = A.frame_diff(prev, g)
                    ref = float(np.median(recent)) if len(recent) >= 5 else 7.5
                    if d <= min(1.5, 0.2 * ref):
                        dropped += 1
                        continue
                    recent.append(d)
                    recent[:] = recent[-60:]
                wr.write(fr)
                prev = g
                kept += 1
        progress("normalizar", total, total)
        self.stats["normalizar"] = {"conservados": kept, "descartados": dropped}
        log(f"  {kept} fotogramas conservados, {dropped} duplicados eliminados")
        self._done("normalizar", key)
        return out

    # ---------- etapa 2: análisis ----------
    def analyze(self, norm: Path) -> dict:
        out = self.work / "02_analisis.json"
        key = self._key("normalizar", "estabilizar", "deflicker", "color")
        if self._cached("analisis", key, out):
            log("Análisis: en caché")
            return json.loads(out.read_text())
        log("Análisis de movimiento, escenas, brillo y color")
        prev = None
        diffs, hists, transforms, lum, grids, chan, lows, highs = [], [], [], [], [], [], [], []
        shape_small = None
        total = probe(norm).nb_frames
        for i, fr in enumerate(read_frames(norm)):
            if i % 25 == 0:
                progress("analisis", i, total)
            g = A.small_gray(fr)
            shape_small = g.shape
            h, w = g.shape
            col = cv2.resize(fr, (w, h), interpolation=cv2.INTER_AREA)
            diffs.append(np.inf if prev is None else A.frame_diff(prev, g))
            hists.append(A.hsv_hist(col))
            transforms.append((0.0, 0.0, 0.0) if prev is None else A.rigid_transform(prev, g))
            lum.append(float(g.mean()))
            grids.append(cv2.resize(g.astype(np.float32), (4, 4), interpolation=cv2.INTER_AREA).tolist())
            chan.append(col.reshape(-1, 3).mean(axis=0).tolist())
            lo, hi = np.percentile(g, [0.5, 99.5])
            lows.append(float(lo))
            highs.append(float(hi))
            prev = g
        n = len(lum)
        cuts = A.detect_scene_cuts(hists, np.array(diffs))
        data = {"n": n, "cuts": cuts, "small_shape": list(shape_small or (1, 1)),
                "transforms": transforms, "lum": lum, "grids": grids, "chan": chan,
                "lows": lows, "highs": highs}
        out.write_text(json.dumps(data))
        progress("analisis", n, n)
        log(f"  {n} fotogramas, {len(cuts)} escenas")
        self._done("analisis", key)
        return data

    # ---------- planes derivados del análisis ----------
    @staticmethod
    def scenes(data: dict) -> list[tuple[int, int]]:
        c = data["cuts"] + [data["n"]]
        return [(c[i], c[i + 1]) for i in range(len(c) - 1) if c[i + 1] > c[i]]

    def stab_plan(self, data: dict, full_w: int) -> np.ndarray:
        cfg = self.recipe["estabilizar"]
        n = data["n"]
        corr = np.zeros((n, 3))
        if not cfg.get("activo", True) or n == 0:
            return corr
        t = np.array(data["transforms"], float)
        scale = full_w / data["small_shape"][1]
        radius = int(round(2 + 28 * float(cfg.get("camara", 0.2))))
        for s, e in self.scenes(data):
            seg = t[s:e].copy()
            seg[0] = 0
            traj = np.cumsum(seg, axis=0)
            smooth = np.stack([A.smooth_1d(traj[:, k], radius) for k in range(3)], axis=1)
            corr[s:e] = (smooth - traj) * float(cfg.get("vaiven", 1.0))
        corr[:, :2] *= scale
        # Límites de seguridad: ±5 % del ancho y ±1,5°
        lim = 0.05 * full_w
        corr[:, :2] = np.clip(corr[:, :2], -lim, lim)
        corr[:, 2] = np.clip(corr[:, 2], -np.radians(1.5), np.radians(1.5))
        if not cfg.get("rotacion", True):
            corr[:, 2] = 0
        return corr

    def flicker_plan(self, data: dict) -> tuple[np.ndarray, np.ndarray | None]:
        cfg = self.recipe["deflicker"]
        n = data["n"]
        gains = np.ones(n)
        grid_gains = None
        if not cfg.get("activo", True) or n == 0:
            return gains, None
        lum = np.maximum(np.array(data["lum"]), 1.0)
        r = int(cfg.get("ventana", 12))
        k = float(cfg.get("fuerza", 1.0))
        grids = np.maximum(np.array(data["grids"]), 1.0) if cfg.get("zonas") else None
        if grids is not None:
            grid_gains = np.ones_like(grids)
        for s, e in self.scenes(data):
            seg = lum[s:e]
            target = A.smooth_1d(seg, r)
            gains[s:e] = np.clip(1 + k * (target / seg - 1), 0.7, 1.4)
            if grids is not None:
                gseg = grids[s:e]
                tgt = np.stack([A.smooth_1d(gseg[:, i, j], r) for i in range(4) for j in range(4)], 1)
                tgt = tgt.reshape(gseg.shape)
                # Compensación parcial del 'hotspot' estático de la escena
                static = gseg.mean(axis=0)
                flat = (static.mean() / static) ** 0.5
                gg = (tgt / gseg) * flat[None]
                grid_gains[s:e] = np.clip(1 + k * (gg - 1), 0.6, 1.6)
                gains[s:e] = 1.0
        return gains, grid_gains

    def color_plan(self, data: dict) -> list[dict]:
        cfg = self.recipe["color"]
        n = data["n"]
        plan = [{"gains": [1, 1, 1], "low": 0.0, "high": 255.0}] * n
        if not cfg.get("activo", True) or n == 0:
            return plan
        chan = np.array(data["chan"])
        lows, highs = np.array(data["lows"]), np.array(data["highs"])
        bal, lev = float(cfg.get("balance", 0.8)), float(cfg.get("niveles", 0.7))
        plan = list(plan)
        for s, e in self.scenes(data):
            m = chan[s:e].mean(axis=0)
            gray = m.mean()
            g = np.clip(1 + bal * (gray / np.maximum(m, 1) - 1), 0.7, 1.45)
            lo = float(np.median(lows[s:e])) * lev
            hi = 255 - (255 - float(np.median(highs[s:e]))) * lev
            entry = {"gains": g.tolist(), "low": lo, "high": hi}
            for i in range(s, e):
                plan[i] = entry
        return plan

    # ---------- etapa 3: máster restaurado ----------
    def master(self, norm: Path, data: dict) -> Path:
        out = self.work / "03_master.mkv"
        key = self._key("normalizar", "estabilizar", "deflicker", "polvo", "ruido", "color", "nitidez_master")
        if self._cached("master", key, out):
            log("Máster: en caché")
            return out
        ninfo = probe(norm)
        W, H = ninfo.width, ninfo.height
        stab = self.stab_plan(data, W)
        gains, grid_gains = self.flicker_plan(data)
        colors = self.color_plan(data)
        scene_of = np.zeros(data["n"], int)
        for k, (s, e) in enumerate(self.scenes(data)):
            scene_of[s:e] = k
        zoom = float(self.recipe["estabilizar"].get("zoom", 1.03)) if self.recipe["estabilizar"].get("activo") else 1.0
        # Temblor antes y después, calculado sobre la trayectoria real (en píxeles del máster)
        try:
            t = np.array(data["transforms"], float)[:, :2] * (W / data["small_shape"][1])
            residual = []
            for traj in (np.cumsum(t, axis=0), np.cumsum(t, axis=0) + stab[:, :2]):
                suave = np.stack([A.smooth_1d(traj[:, k], 3) for k in range(2)], axis=1)
                residual.append(round(float(np.abs(traj - suave).mean()), 3))
            self.stats["estabilidad"] = {"temblor_antes_px": residual[0], "temblor_despues_px": residual[1]}
        except Exception:  # noqa: BLE001
            pass
        cd, cn, cc = self.recipe["polvo"], self.recipe["ruido"], self.recipe["color"]
        sharp = self.recipe["nitidez_master"]
        G.comprobar()
        log(f"Máster restaurado: {data['n']} fotogramas {W}x{H} — {G.describe()}")

        def pre(i, fr):
            fr = F.stabilize(fr, tuple(stab[i]), zoom) if (zoom != 1.0 or np.any(stab[i])) else fr
            if grid_gains is not None:
                fr = F.apply_gain(fr, F.gain_map(grid_gains[i], fr.shape[:2]))
            elif gains[i] != 1.0:
                fr = F.apply_gain(fr, float(gains[i]))
            return fr

        scratches = 0

        def post(i, fr):
            nonlocal scratches
            if cd.get("rayas", True):
                fr, k = F.remove_scratches(fr, float(cd.get("umbral_rayas", 5.0)))
                scratches += k
            fr = F.spatial_denoise(fr, float(cn.get("espacial", 0)))
            c = colors[i]
            fr = F.color_correct(fr, c["gains"], c["low"], c["high"], float(cc.get("saturacion", 1.0)))
            return F.adaptive_sharpen(fr, float(sharp.get("cantidad", 0)), float(sharp.get("radio", 1.2)))

        use_temporal = cd.get("activo", True) or float(cn.get("temporal", 0)) > 0
        dust_total = 0.0
        t0 = time.time()
        with FrameWriter(out, W, H, ninfo.fps) as wr:
            def process(prev, cur, nxt):
                nonlocal dust_total
                i, frame = cur
                if use_temporal:
                    p = prev[1] if prev is not None and scene_of[prev[0]] == scene_of[i] else None
                    q = nxt[1] if nxt is not None and scene_of[nxt[0]] == scene_of[i] else None
                    frame, ratio = F.temporal_clean(p, frame, q, cd, cn)
                    dust_total += ratio
                wr.write(post(i, frame))
                if (i + 1) % 10 == 0:
                    progress("master", i + 1, data["n"])
                if (i + 1) % 50 == 0:
                    log(f"  {i + 1}/{data['n']} ({(i + 1) / (time.time() - t0):.1f} fps)")

            prev = cur = None
            for i, fr in enumerate(read_frames(norm)):
                nxt = (i, pre(i, fr))
                if cur is not None:
                    process(prev, cur, nxt)
                prev, cur = cur, nxt
            if cur is not None:
                process(prev, cur, None)
        self.stats["master"] = {"polvo_medio_pct": round(100 * dust_total / max(data["n"], 1), 4),
                                "columnas_raya_por_fotograma": round(scratches / max(data["n"], 1), 2)}
        self._done("master", key)
        return out

    # Modelos de escalado lentos: con ellos compensa escalar antes de interpolar
    MODELOS_LENTOS = ("realesrgan-x4plus", "realesrnet-x4plus")

    def _escalar_primero(self) -> bool:
        cfg = self.recipe["mejora"]
        orden = cfg.get("orden", "auto")
        if orden in ("escalar_primero", "interpolar_primero"):
            return orden == "escalar_primero"
        if int(cfg.get("escala", 1)) <= 1 or not cfg.get("fps_salida"):
            return False
        try:
            if float(cfg["fps_salida"]) <= probe(self.work / "03_master.mkv").fps_float * 1.05:
                return False        # no se añaden fotogramas: da igual el orden
        except Exception:  # noqa: BLE001
            pass
        engine = B.resolve_upscaler(cfg.get("motor_escala", "auto"))
        if engine == "spandrel":
            return True
        return engine == "realesrgan-ncnn" and str(cfg.get("modelo_escala", "")).startswith(self.MODELOS_LENTOS)

    # ---------- etapa 4: interpolación (a la resolución del máster) ----------
    def interpolate(self, video: Path, data: dict) -> Path:
        cfg = self.recipe["mejora"]
        target = cfg.get("fps_salida")
        vinfo = probe(video)
        if not target or abs(float(target) - vinfo.fps_float) < 0.01:
            return video
        target = Fraction(target).limit_denominator(1001)
        engine = B.resolve_interpolator(cfg.get("motor_interpolacion", "auto"))
        out = self.work / "04_interpolado.mkv"
        sub = {k: cfg.get(k) for k in ("fps_salida", "motor_interpolacion", "modelo_interpolacion")}
        key = self._key(extra=f"{engine}|{json.dumps(sub, sort_keys=True)}|{self.state.get('master')}|"
                              f"{video.name}|{self.state.get('escalado') if video.name.startswith('05') else ''}")
        if self._cached("interpolado", key, out):
            log("Interpolación: en caché")
            return out
        log(f"Interpolación {vinfo.fps_float:g} → {float(target):g} fps con {engine}")
        lossless = ["-c:v", "ffv1", "-level", "3", "-g", "1"]
        progress("interpolacion", 0, 1)
        if engine == "repetir":
            run_ffmpeg(["-i", str(video), "-vf", f"fps={target}", *lossless, str(out)])
        elif engine == "minterpolate":
            run_ffmpeg(["-i", str(video), "-vf",
                        f"minterpolate=fps={target}:mi_mode=mci:mc_mode=obmc:me_mode=bidir:scd=fdiff",
                        *lossless, str(out)])
        else:
            self._interpolate_rife(video, vinfo, target, data, cfg, out)
        progress("interpolacion", 1, 1)
        self._done("interpolado", key)
        return out

    def _interpolate_rife(self, video, vinfo, target, data, cfg, out, chunk: int = 0):
        """RIFE por escena y por bloques (para no llenar el disco), sin mezclar escenas.
        rife-ncnn-vulkan con -n M sobre N imágenes genera la salida k en el instante k·N/M."""
        ratio = float(target) / vinfo.fps_float
        if not chunk:   # ~2 GB de PNG por bloque, sea cual sea la resolución
            chunk = int(np.clip(400 * (1534 * 948) / max(vinfo.width * vinfo.height, 1), 40, 400))
        model = B.pick_rife_model(cfg.get("modelo_interpolacion", "rife-v4"))
        log(f"  modelo RIFE: {model}")
        scenes = self.scenes(data)
        tmp = self.work / "tmp_rife"
        total_in = data["n"]
        done_in = 0
        png = [cv2.IMWRITE_PNG_COMPRESSION, 1]
        with FrameWriter(out, vinfo.width, vinfo.height, target) as wr:
            frames = read_frames(video)
            for s, e in scenes:
                L = e - s
                scene_frames = [next(frames) for _ in range(L)]
                if L < 2:
                    for _ in range(max(1, int(round(L * ratio)))):
                        wr.write(scene_frames[0])
                    done_in += L
                    continue
                pos = 0
                while pos < L:
                    n = min(chunk, L - pos)
                    extra = 1 if pos + n < L else 0          # un fotograma de solape
                    shutil.rmtree(tmp, ignore_errors=True)
                    (tmp / "in").mkdir(parents=True)
                    for j in range(n + extra):
                        cv2.imwrite(str(tmp / "in" / f"{j:08d}.png"), scene_frames[pos + j], png)
                    n_keep = int(round((pos + n) * ratio)) - int(round(pos * ratio))
                    step = 1.0 / ratio
                    m = n_keep + (int(round(extra / step)) if extra else 0)
                    m = max(m, 1)
                    B.run_rife(tmp / "in", tmp / "out", m, model, uhd=vinfo.width > 2000)
                    outs = sorted((tmp / "out").glob("*.png"))
                    for f in outs[:n_keep]:
                        wr.write(cv2.imread(str(f)))
                    pos += n
                    done_in += n
                    progress("interpolacion", done_in, total_in + 1)
                del scene_frames
        shutil.rmtree(tmp, ignore_errors=True)

    # ---------- etapa 5: escalado ----------
    MAX_ALTO = 2160

    def upscale(self, video: Path) -> Path:
        cfg = self.recipe["mejora"]
        scale = int(cfg.get("escala", 1))
        out = self.work / "05_escalado.mkv"
        if scale <= 1:
            return video
        engine = B.resolve_upscaler(cfg.get("motor_escala", "auto"))
        sub = {k: cfg.get(k) for k in ("escala", "motor_escala", "modelo_escala", "mezcla_ia", "tile")}
        key = self._key(extra=f"{engine}|{json.dumps(sub, sort_keys=True)}|{self.state.get('master')}|"
                              f"{self.state.get('interpolado') if video.name.startswith('04') else ''}|{video.name}")
        # (la clave incluye el nombre del archivo de entrada: 03_master o 04_interpolado)
        if self._cached("escalado", key, out):
            log("Escalado: en caché")
            return out
        vinfo = probe(video)
        W, H = vinfo.width * scale, vinfo.height * scale
        if H > self.MAX_ALTO:  # no tiene sentido pasar de 4K con material de 8 mm
            W, H = int(round(W * self.MAX_ALTO / H / 2)) * 2, self.MAX_ALTO
        mix = float(cfg.get("mezcla_ia", 0.7))
        use_ai = engine in ("realesrgan-ncnn", "spandrel") and mix > 0
        model = cfg.get("modelo_escala", "realesr-animevideov3")
        ai_scale = 4 if model.startswith("realesrgan-x4") else scale
        detalle = (f"{engine} · modelo {cfg.get('modelo_pth')}" if engine == "spandrel"
                   else f"{engine} · modelo {model}") if use_ai else "lanczos"
        log(f"Escalado x{scale} con {detalle} → {W}x{H} (peso IA {mix:.2f})")
        tmp = self.work / "tmp_esrgan"
        chunk = int(cfg.get("bloque_ia", 20))
        png = [cv2.IMWRITE_PNG_COMPRESSION, 1]
        total = vinfo.nb_frames
        done = 0
        with FrameWriter(out, W, H, vinfo.fps) as wr:
            buf: list[np.ndarray] = []

            def flush():
                nonlocal done
                if not buf:
                    return
                ais = None
                if use_ai and engine == "spandrel":
                    from . import torchmodels as TM
                    modelo = cfg.get("modelo_pth", "realesr-general-x4v3")
                    for j, fr in enumerate(buf):
                        base = cv2.resize(fr, (W, H), interpolation=cv2.INTER_LANCZOS4)
                        ai = TM.aplicar(fr, modelo, tile=int(cfg.get("tile", 0)) or 384)
                        if ai.shape[:2] != (H, W):
                            ai = cv2.resize(ai, (W, H), interpolation=cv2.INTER_AREA)
                        wr.write(ai if mix >= 1 else cv2.addWeighted(ai, mix, base, 1 - mix, 0))
                    done += len(buf)
                    buf.clear()
                    progress("escalado_ia", done, total)
                    return
                if use_ai:
                    shutil.rmtree(tmp, ignore_errors=True)
                    (tmp / "in").mkdir(parents=True)
                    for j, fr in enumerate(buf):
                        cv2.imwrite(str(tmp / "in" / f"{j:08d}.png"), fr, png)
                    B.run_realesrgan(tmp / "in", tmp / "out", ai_scale, model, tile=int(cfg.get("tile", 0)))
                    ais = sorted((tmp / "out").glob("*.png"))
                for j, fr in enumerate(buf):
                    base = cv2.resize(fr, (W, H), interpolation=cv2.INTER_LANCZOS4)
                    if ais is not None:
                        ai = cv2.imread(str(ais[j]))
                        if ai.shape[:2] != (H, W):
                            ai = cv2.resize(ai, (W, H), interpolation=cv2.INTER_AREA)
                        base = ai if mix >= 1 else cv2.addWeighted(ai, mix, base, 1 - mix, 0)
                    wr.write(base)
                done += len(buf)
                buf.clear()
                progress("escalado_ia" if use_ai else "escalado", done, total)

            for fr in read_frames(video):
                buf.append(fr)
                if len(buf) >= (chunk if use_ai else 20):
                    flush()
            flush()
        shutil.rmtree(tmp, ignore_errors=True)
        self._done("escalado", key)
        return out

    # ---------- etapa 6: acabado y exportación ----------
    def _audio_ok(self, video: Path) -> bool:
        if not self.info.has_audio:
            return False
        d = probe(video).duration
        return d > 0 and abs(d - self.info.duration) / max(self.info.duration, 1e-3) < 0.05

    def export(self, master: Path, enhanced: Path | None, out_dir: Path) -> dict:
        out_dir.mkdir(parents=True, exist_ok=True)
        stem = self.src.stem
        exp = self.recipe["exportar"]
        af = "afftdn=nf=-25,adeclick" if exp.get("audio_limpieza") else None
        results = {}

        # Máster fiel
        mfile = out_dir / f"{stem}_master.{'mov' if exp.get('master') == 'prores' else 'mkv'}"
        vcodec = (["-c:v", "prores_ks", "-profile:v", "3", "-pix_fmt", "yuv422p10le"]
                  if exp.get("master") == "prores" else ["-c:v", "copy"])
        args = ["-i", str(master)]
        if self._audio_ok(master):
            args += ["-i", str(self.src), "-map", "0:v:0", "-map", "1:a:0"]
            args += (["-af", af] if af else []) + ["-c:a", "pcm_s16le" if mfile.suffix == ".mov" else "flac"]
        run_ffmpeg([*args, *vcodec, str(mfile)])
        results["master"] = str(mfile)
        log(f"Máster exportado: {mfile.name}")

        # Copia mejorada
        if enhanced is not None and exp.get("compartir"):
            cfg = self.recipe["mejora"]
            einfo = probe(enhanced)
            ext = "mp4"
            crf = int(exp.get("crf", 18))
            hevc = exp["compartir"] == "h265"
            nv = "hevc_nvenc" if hevc else "h264_nvenc"
            if exp.get("codificador", "auto") == "auto" and encoder_works(nv):
                codec = ["-c:v", nv, "-preset", "p6", "-tune", "hq", "-rc", "vbr",
                         "-cq", str(crf + (2 if hevc else 1)), "-b:v", "0", "-spatial-aq", "1"]
            elif hevc:
                codec = ["-c:v", "libx265", "-crf", str(crf + 2), "-preset", "medium"]
            else:
                codec = ["-c:v", "libx264", "-crf", str(crf), "-preset", "medium"]
            if hevc:
                codec += ["-tag:v", "hvc1"]
            self.codificador = codec[1]
            log(f"  codificador: {codec[1]}")
            codec += ["-pix_fmt", "yuv420p", "-movflags", "+faststart"]
            efile = out_dir / f"{stem}_mejorado.{ext}"
            vf = F.fit_canvas_vf(einfo.width, einfo.height, cfg.get("lienzo", "16:9"))
            audio = self.src if self._audio_ok(enhanced) else None
            sharp, grain = float(cfg.get("nitidez", 0)), float(cfg.get("regranulado", 0))
            ccaras = self.recipe.get("caras", {})
            usar_caras = bool(ccaras.get("activo"))
            caras_tratadas = 0
            if usar_caras:
                from . import caras as CA
                log(f"  restauración de caras: {ccaras.get('modelo')} al {float(ccaras.get('intensidad', 0)) * 100:.0f} %")
            log(f"Acabado (nitidez {sharp}, grano {grain}) y codificación: {efile.name}")
            with FrameWriter(efile, einfo.width, einfo.height, einfo.fps, codec_args=codec,
                             audio_from=audio, audio_filter=af, vf=vf) as wr:
                for i, fr in enumerate(read_frames(enhanced)):
                    if usar_caras:
                        fr, n = CA.restaurar(fr, float(ccaras.get("intensidad", 0.6)),
                                             str(ccaras.get("modelo", "GFPGANv1.4")),
                                             int(ccaras.get("minimo_px", 80)))
                        caras_tratadas += n
                    wr.write(F.finish(fr, sharp, 1.0 * max(1, einfo.width / 1920), grain, i))
                    if (i + 1) % 10 == 0:
                        progress("acabado", i + 1, einfo.nb_frames)
            if usar_caras:
                self.stats["caras"] = {"tratadas": caras_tratadas,
                                       "por_fotograma": round(caras_tratadas / max(einfo.nb_frames, 1), 2)}
                log(f"  caras reconstruidas: {caras_tratadas}")
            results["mejorado"] = str(efile)
        return results

    # ---------- todo ----------
    def _cronometrar(self, nombre: str, fn, *a, **k):
        t = time.time()
        try:
            return fn(*a, **k)
        finally:
            self.tiempos[nombre] = self.tiempos.get(nombre, 0.0) + (time.time() - t)

    def run(self, out_dir: str | Path) -> dict:
        t0 = time.time()
        out_dir = Path(out_dir)
        log(f"Procesado en: {G.describe()}")
        if self.recipe["mejora"].get("activo"):   # sin copia mejorada no hacen falta los motores
            log(f"Escalado: {B.resolve_upscaler(self.recipe['mejora'].get('motor_escala', 'auto'))} · "
                f"Interpolación: {B.resolve_interpolator(self.recipe['mejora'].get('motor_interpolacion', 'auto'))}")
        libre = espacio_libre_gb(self.work)
        # Un máster sin pérdida ocupa ~1–2 MB por fotograma, más los bloques intermedios
        necesario = max(4.0, self.info.nb_frames * 0.0025)
        log(f"Espacio libre en la unidad de trabajo: {libre:.0f} GB (estimado necesario: {necesario:.0f} GB)")
        if libre < necesario:
            log(f"[aviso] Puede faltar espacio: hacen falta unos {necesario:.0f} GB y hay {libre:.0f} GB. "
                f"Libera espacio o borra datos\\cache antes de seguir.")
        norm = self._cronometrar("Normalización", self.normalize)
        data = self._cronometrar("Análisis", self.analyze, norm)
        master = self._cronometrar("Limpieza y estabilización", self.master, norm, data)
        enhanced = None
        if self.recipe["mejora"].get("activo"):
            if self._escalar_primero():
                log("  orden: escalar antes de interpolar (así el modelo procesa menos fotogramas)")
                up = self._cronometrar("Escalado", self.upscale, master)
                enhanced = self._cronometrar("Interpolación", self.interpolate, up, data)
            else:
                inter = self._cronometrar("Interpolación", self.interpolate, master, data)
                enhanced = self._cronometrar("Escalado", self.upscale, inter)
        results = self._cronometrar("Acabado y codificación", self.export, master, enhanced, out_dir)
        # Comparativo de TODA la duración (0 = no generarlo; recetas antiguas con 20 s también
        # obtienen el vídeo completo)
        seg = float(self.recipe.get("exportar", {}).get("comparacion_seg", -1) or 0)
        if seg != 0 and results.get("mejorado"):
            try:
                cmp_file = out_dir / f"{self.src.stem}_comparacion.mp4"
                log(f"Vídeo comparativo completo (original | restaurado): {cmp_file.name}")
                progress("comparacion", 0, 1)
                CMP.crear(self.src, results["mejorado"], cmp_file)
                progress("comparacion", 1, 1)
                results["comparacion"] = str(cmp_file)
            except Exception as exc:  # noqa: BLE001
                log(f"[aviso] No se pudo crear el vídeo comparativo: {exc}")
        if self.recipe.get("medir", True):
            try:
                log("Midiendo el resultado (ruido, nitidez, parpadeo, temblor)…")
                # El "antes" es el vídeo ya normalizado (mismo recorte y misma cadencia que el
                # máster): así la comparación aísla lo que han hecho los filtros, sin mezclar
                # el efecto del recorte ni el del recodificado.
                antes = MED.metricas(norm, 12)
                despues = MED.metricas(master, 12)
                est = self.stats.get("estabilidad") or {}
                if est:
                    antes["temblor"] = est["temblor_antes_px"]
                    despues["temblor"] = est["temblor_despues_px"]
                self.stats["medidas"] = {"antes": antes, "despues": despues}
            except Exception as exc:  # noqa: BLE001
                log(f"[aviso] No se pudieron calcular las medidas: {exc}")
        try:
            motores = {
                "escalado": B.resolve_upscaler(self.recipe["mejora"].get("motor_escala", "auto")),
                "interpolacion": B.resolve_interpolator(self.recipe["mejora"].get("motor_interpolacion", "auto")),
            }
        except Exception:  # noqa: BLE001  (sin mejora no importa)
            motores = {"escalado": "-", "interpolacion": "-"}
        report = {
            "origen": str(self.src),
            "receta": self.recipe,
            "estadisticas": self.stats,
            "escenas": len(data["cuts"]),
            "dispositivo": G.describe(),
            "motores": motores,
            "codificador": self.codificador,
            "tiempos": {k: round(v, 1) for k, v in self.tiempos.items()},
            "salidas": results,
            "segundos": round(time.time() - t0, 1),
        }
        (out_dir / f"{self.src.stem}_informe.json").write_text(
            json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        save_recipe(self.recipe, out_dir / f"{self.src.stem}_receta.json")
        try:
            ruta = INF.crear(out_dir / f"{self.src.stem}_informe.html", self.src, Path(results["master"]),
                             Path(results["mejorado"]) if results.get("mejorado") else None,
                             self.recipe, self.stats, self.tiempos, len(data["cuts"]), G.describe(),
                             motores, self.codificador, self.notas)
            report["salidas"]["informe"] = str(ruta)
            log(f"Informe: {ruta.name}")
        except Exception as exc:  # noqa: BLE001
            log(f"[aviso] No se pudo generar el informe HTML: {exc}")
        progress("fin", 1, 1)
        log(f"Terminado en {report['segundos']} s")
        return report
