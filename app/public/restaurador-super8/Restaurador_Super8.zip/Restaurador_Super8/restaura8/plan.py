"""Planificador: elige los parámetros a partir del material, de la máquina y del tiempo disponible.

La idea: medir en lugar de suponer. Se cronometra cada etapa con unos pocos fotogramas
del propio vídeo y se elige la mejor combinación que quepa en el presupuesto de tiempo.
"""
from __future__ import annotations

import copy
import shutil
import tempfile
import time
from pathlib import Path

import cv2
import numpy as np

from . import backends as B
from . import filters as F
from . import gpu as G
from . import medidas as MED
from .recipe import deep_update, load_preset
from .video_io import encoder_works, probe, progress, read_frames

ALTURAS = (720, 1080, 1440, 2160)

# Calidad relativa estimada de cada motor de escalado (1 = solo Lanczos).
CANDIDATOS = [
    {"id": "lanczos", "motor": "lanczos", "modelo": None, "calidad": 1.0},
    {"id": "animevideov3", "motor": "realesrgan-ncnn", "modelo": "realesr-animevideov3", "calidad": 1.5},
    {"id": "general-x4v3", "motor": "spandrel", "modelo": "realesr-general-x4v3", "calidad": 1.8},
    {"id": "x4plus", "motor": "realesrgan-ncnn", "modelo": "realesrgan-x4plus", "calidad": 2.0},
]


def _fotogramas(video: Path, n: int, salto: int = 1) -> list[np.ndarray]:
    fr = []
    for i, f in enumerate(read_frames(video)):
        if i % salto == 0:
            fr.append(f)
        if len(fr) >= n:
            break
    return fr


def historial(raiz: Path | None = None) -> dict:
    """Ritmos reales de trabajos anteriores (informe.json), que valen más que un cronómetro
    de cinco fotogramas: ahí están los tiempos con la máquina en condiciones reales."""
    import json

    raiz = Path(raiz or (Path(__file__).resolve().parent.parent / "resultados"))
    ritmos: dict = {}
    for inf in sorted(raiz.rglob("*_informe.json"))[-12:]:
        try:
            d = json.loads(inf.read_text(encoding="utf-8"))
            t = d.get("tiempos") or {}
            n = int((d.get("estadisticas", {}).get("normalizar") or {}).get("conservados") or 0)
            if not n or "Limpieza y estabilización" not in t:
                continue
            ritmos.setdefault("limpieza", []).append(t["Limpieza y estabilización"] / n)
            mej = d.get("receta", {}).get("mejora", {})
            modelo = mej.get("modelo_pth") if d.get("motores", {}).get("escalado") == "spandrel" else mej.get("modelo_escala")
            fps_sal = mej.get("fps_salida")
            n_salida = int(n * (float(fps_sal) / float(d["receta"]["normalizar"]["film_fps"]))) if fps_sal else n
            if modelo and t.get("Escalado") and int(mej.get("escala", 1)) > 1:
                clave = {"realesr-animevideov3": "animevideov3", "realesrgan-x4plus": "x4plus",
                         "realesr-general-x4v3": "general-x4v3"}.get(modelo)
                if clave:
                    ritmos.setdefault(f"escala_{clave}", []).append(t["Escalado"] / max(n_salida, 1))
            if t.get("Interpolación") and fps_sal:
                ritmos.setdefault("interpolacion", []).append(t["Interpolación"] / max(n_salida, 1))
            if t.get("Acabado y codificación"):
                ritmos.setdefault("codificacion", []).append(t["Acabado y codificación"] / max(n_salida, 1))
        except Exception:  # noqa: BLE001
            continue
    return {k: round(float(np.median(v)), 4) for k, v in ritmos.items() if v}


class _Vigia:
    """Vigila una etapa de la medición que corre dentro de este proceso (CUDA, flujo óptico).
    Si se cuelga, no hay forma segura de interrumpirla desde dentro: se explica el motivo y se
    termina el proceso, para que el trabajo falle con un mensaje claro en vez de quedarse
    «midiendo» para siempre."""

    def __init__(self, etapa: str, limite: float):
        self.etapa, self.limite, self._t = etapa, limite, None

    def _disparar(self):
        import os
        print(f"[aviso] La medición se ha quedado bloqueada en «{self.etapa}» más de "
              f"{self.limite:.0f} s. Lo más probable es que la GPU esté ocupada por otro programa "
              "o que el controlador no responda. Cierra programas que usen la GPU (juegos, "
              "editores de vídeo, otra restauración) o reinicia con EJECUTAR.bat y vuelve a "
              "intentarlo.", flush=True)
        try:
            G.volcado_diagnostico()
        except Exception:  # noqa: BLE001
            pass
        os._exit(3)

    def __enter__(self):
        import threading
        self._t = threading.Timer(self.limite, self._disparar)
        self._t.daemon = True
        self._t.start()
        return self

    def __exit__(self, *exc):
        self._t.cancel()
        return False


_BENCH_TORCH = r"""
import sys, time, cv2
from restaura8 import torchmodels as TM
f = cv2.imread(sys.argv[1]); modelo = sys.argv[2]
TM.aplicar(f[:64, :64], modelo, tile=0)
t0 = time.time(); TM.aplicar(f, modelo, tile=384)
print("SEG", time.time() - t0, flush=True)
"""


def _medir_torch(fotograma: np.ndarray, modelo: str, tmp: Path, limite: float) -> float:
    """Mide un modelo PyTorch en un proceso aparte: si la GPU se cuelga, se mata sin arrastrar
    al planificador."""
    import subprocess
    import sys
    png = tmp / "torch_in.png"
    cv2.imwrite(str(png), fotograma)
    raiz = str(Path(__file__).resolve().parent.parent)
    try:
        r = subprocess.run([sys.executable, "-c", _BENCH_TORCH, str(png), modelo], cwd=raiz,
                           capture_output=True, text=True, timeout=limite)
    except subprocess.TimeoutExpired as exc:
        raise TimeoutError(f"el modelo PyTorch no respondió en {limite:.0f} s") from exc
    for linea in r.stdout.splitlines():
        if linea.startswith("SEG "):
            return float(linea.split()[1])
    raise RuntimeError((r.stderr or "sin salida").strip().splitlines()[-1][:300])


def cronometrar(video: str | Path, recorte: list[int] | None = None, verbose: bool = True) -> dict:
    """Mide en este equipo el coste por fotograma de cada etapa. Suele tardar uno o dos minutos.
    Cada motor tiene un tiempo máximo: si no responde, se omite (y se avisa) en lugar de colgarse."""
    video = Path(video)
    marcas: dict = {"dispositivo": G.describe()}
    pasos = ["Leyendo fotogramas", "Limpieza", "Interpolación"] + \
            [f"Escalado {c['id']}" for c in CANDIDATOS if c["motor"] != "lanczos"] + ["Codificador"]
    total = len(pasos)

    def paso(i: int, texto: str) -> None:
        if verbose:
            print(f"  · {texto}…", flush=True)
        progress("medicion", i, total)

    paso(0, pasos[0])
    fr = _fotogramas(video, 5, salto=3)
    if recorte:
        x, y, w, h = recorte
        fr = [f[y:y + h, x:x + w] for f in fr]
    if len(fr) < 3:
        return marcas
    # Límites generosos en proporción al tamaño del fotograma (1 = 1920×1080)
    megapix = max(fr[0].shape[0] * fr[0].shape[1] / 2.07e6, 0.3)

    # Limpieza + estabilización. El primer fotograma incluye el arranque de CUDA y del
    # flujo óptico, así que se descarta: si no, la estimación se dispara.
    paso(1, pasos[1])
    with _Vigia("limpieza (flujo óptico y GPU)", 300 * megapix + 120):
        G.comprobar(intentos=1)
        F.temporal_clean(fr[0], fr[1], fr[2], {"activo": True}, {"temporal": 0.6, "grano": 0.5})
        t0 = time.time()
        medidos = 0
        for i in range(1, len(fr) - 1):
            F.temporal_clean(fr[i - 1], fr[i], fr[i + 1], {"activo": True}, {"temporal": 0.6, "grano": 0.5})
            F.remove_scratches(fr[i])
            F.adaptive_sharpen(fr[i], 0.3)
            medidos += 1
        marcas["limpieza"] = (time.time() - t0) / max(medidos, 1)

        # Variante rápida: sin flujo óptico (ni motas ni promedio temporal), que es lo que más cuesta
        t0 = time.time()
        for i in range(1, len(fr) - 1):
            F.remove_scratches(fr[i])
            F.adaptive_sharpen(fr[i], 0.3)
        marcas["limpieza_rapida"] = (time.time() - t0) / max(medidos, 1)

    # Interpolación (RIFE) y escalado, con los motores realmente disponibles
    tmp = Path(tempfile.mkdtemp(prefix="restaura8_bench_"))
    omitidos = []
    try:
        paso(2, pasos[2])
        if B.rife_bin() and B.vulkan_ok():
            try:
                ent, sal = tmp / "ri", tmp / "ro"
                ent.mkdir()
                for j, f in enumerate(fr[:4]):
                    cv2.imwrite(str(ent / f"{j:08d}.png"), f, [cv2.IMWRITE_PNG_COMPRESSION, 1])
                t0 = time.time()
                B.run_rife(ent, sal, 8, B.pick_rife_model("rife-v4.6"), uhd=fr[0].shape[1] > 2000,
                           timeout=180 * megapix + 60)
                marcas["interpolacion"] = (time.time() - t0) / 8
            except Exception as exc:  # noqa: BLE001
                omitidos.append("interpolación RIFE")
                print(f"[aviso] No se pudo medir RIFE: {exc}. Se estimará sin él.", flush=True)
        n = 3
        for cand in CANDIDATOS:
            if cand["motor"] == "lanczos":
                marcas[f"escala_{cand['id']}"] = 0.01
                continue
            paso(n, f"Escalado con {cand['id']}")
            n += 1
            try:
                if cand["motor"] == "realesrgan-ncnn":
                    if not B.realesrgan_bin() or not B.vulkan_ok():
                        continue
                    x4 = "x4plus" in cand["modelo"]
                    limite = (240 if x4 else 90) * megapix + 60
                    # Dos pasadas (1 y 3 fotogramas) para descontar el arranque del ejecutable,
                    # que si no se reparte entre pocos fotogramas y falsea la medida.
                    tiempos = {}
                    for cuantos in (1, 3):
                        ent = tmp / f"e{cand['id']}_{cuantos}"
                        sal = tmp / f"s{cand['id']}_{cuantos}"
                        ent.mkdir()
                        for j in range(cuantos):
                            cv2.imwrite(str(ent / f"{j:08d}.png"), fr[j % len(fr)],
                                        [cv2.IMWRITE_PNG_COMPRESSION, 1])
                        t0 = time.time()
                        B.run_realesrgan(ent, sal, 4 if x4 else 2, cand["modelo"], timeout=limite)
                        tiempos[cuantos] = time.time() - t0
                    por_fotograma = max((tiempos[3] - tiempos[1]) / 2, 0.01)
                    marcas[f"escala_{cand['id']}"] = por_fotograma
                    marcas[f"arranque_{cand['id']}"] = round(max(tiempos[1] - por_fotograma, 0), 2)
                else:
                    if not B.hay_spandrel():
                        continue
                    marcas[f"escala_{cand['id']}"] = _medir_torch(fr[1], cand["modelo"], tmp,
                                                                  300 * megapix + 120)
            except Exception as exc:  # noqa: BLE001
                omitidos.append(cand["id"])
                print(f"[aviso] No se pudo medir {cand['id']}: {exc}. Esa opción no se propondrá.",
                      flush=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    paso(total - 1, pasos[-1])
    marcas["nvenc"] = encoder_works("h264_nvenc")
    marcas["codificacion"] = 0.02 if marcas["nvenc"] else 0.16
    progress("medicion", total, total)
    if omitidos:
        marcas["omitidos"] = omitidos
    # Lo medido en trabajos reales manda sobre el cronómetro de unos pocos fotogramas,
    # salvo para los motores que hoy no han respondido
    hist = historial()
    for k, v in hist.items():
        if k.startswith("escala_") and k[len("escala_"):] in omitidos:
            continue
        if k == "interpolacion" and "interpolación RIFE" in omitidos:
            continue
        if k in marcas or k.startswith("escala_"):
            marcas[k] = v
            marcas.setdefault("_historial", []).append(k)
    return marcas


def escala_maxima(corte: float) -> float:
    """Cuánto tiene sentido escalar, según hasta dónde llega el detalle real.

    `corte` es la fracción de la frecuencia máxima donde la imagen aún tiene información
    por encima del grano. Un escaneo blando (0,2) no gana nada al ampliarlo; uno bien
    resuelto (0,5) admite el doble.
    """
    if corte >= 0.45:
        return 2.0
    if corte >= 0.30:
        return 1.75
    if corte >= 0.20:
        return 1.5
    return 1.0


def _altura_objetivo(corte: float, alto_master: int, tope: int) -> tuple[int, int]:
    alto_max = min(int(alto_master * escala_maxima(corte)), tope)
    alturas = [a for a in ALTURAS if a <= alto_max]
    alto = max(alturas) if alturas else min(alto_max, ALTURAS[0])
    if alto < alto_master:          # nunca reducir por debajo del máster
        alto = alto_master
    escala = 1 if alto <= alto_master * 1.1 else (2 if alto <= alto_master * 2.2 else 4)
    return alto, escala


def proponer(diagnostico: dict, medidas: dict, marcas: dict, minutos: float,
             prioridad: float = 0.5, tope_alto: int = 2160, fluidez: bool = True) -> dict:
    """Devuelve {receta, estimado_s, explicacion[], alternativas[]}.

    prioridad: 0 = lo más rápido posible, 1 = la mejor calidad que quepa en el tiempo.
    """
    rec = load_preset("equilibrado")
    deep_update(rec, {"normalizar": diagnostico["receta_propuesta"]["normalizar"],
                      "deflicker": diagnostico["receta_propuesta"]["deflicker"],
                      "polvo": diagnostico["receta_propuesta"]["polvo"],
                      "ruido": diagnostico["receta_propuesta"]["ruido"],
                      "color": diagnostico["receta_propuesta"]["color"]})

    n = max(int(diagnostico.get("fotogramas_analizados", 0)), 1)
    info_w, info_h = diagnostico["resolucion"]
    recorte = rec["normalizar"].get("recorte")
    w_m, h_m = (recorte[2], recorte[3]) if recorte else (info_w, info_h)
    fps_origen = float(rec["normalizar"]["film_fps"])
    dur = float(diagnostico.get("duracion", 0)) or 1.0
    n_master = int(round(dur * fps_origen))

    corte = float(medidas.get("corte_espectral", 0.4))
    alto, escala = _altura_objetivo(corte, h_m, tope_alto)
    presupuesto = minutos * 60
    explic = []

    # Ruido y grano según lo medido
    ruido = medidas.get("ruido", 0)
    rec["ruido"]["temporal"] = float(np.clip(ruido / 6.0, 0.3, 0.95))
    rec["ruido"]["grano"] = float(np.clip(0.8 - ruido / 12.0, 0.2, 0.8))

    opciones = []
    limpiezas = [("completa", marcas.get("limpieza", 0.3), 0.0),
                 ("rapida", marcas.get("limpieza_rapida", marcas.get("limpieza", 0.3) * 0.35), -0.6)]
    fps_opciones = [None]
    if fluidez and "interpolación RIFE" not in marcas.get("omitidos", []):
        fps_opciones += [f for f in (30, 50, 60) if f > fps_origen * 1.15][:2]
    for cand in CANDIDATOS:
        clave = f"escala_{cand['id']}"
        if clave not in marcas:
            continue
        for fps in fps_opciones:
            for nombre_limp, coste_limp, penal in limpiezas:
                n_salida = int(round(n_master * (fps / fps_origen))) if fps else n_master
                # Con modelos lentos conviene escalar antes de interpolar
                n_escalar = n_master if (marcas[clave] > 1.0 and fps) else n_salida
                coste = (coste_limp * n_master
                         + (marcas.get("interpolacion", 0.15) * n_salida if fps else 0)
                         + (marcas[clave] * n_escalar if escala > 1 else 0)
                         + marcas.get("codificacion", 0.1) * n_salida
                         + 60)
                calidad = cand["calidad"] * (1.0 if escala > 1 else 0.9) + (0.5 if fps else 0) + penal
                opciones.append({"cand": cand, "fps": fps, "coste": coste, "calidad": calidad,
                                 "limpieza": nombre_limp})

    if not opciones:
        opciones = [{"cand": CANDIDATOS[0], "fps": None, "limpieza": "completa",
                     "coste": marcas.get("limpieza", 0.3) * n_master + 60, "calidad": 1.0}]

    caben = [o for o in opciones if o["coste"] <= presupuesto]
    if caben:
        # Dentro del presupuesto: la mejor calidad, penalizando el tiempo según la prioridad
        elegida = max(caben, key=lambda o: o["calidad"] - (1 - prioridad) * o["coste"] / max(presupuesto, 1))
        explic.append(f"Cabe en el presupuesto de {minutos:.0f} min: se elige {elegida['cand']['id']}"
                      + (f" con interpolación a {elegida['fps']} fps." if elegida["fps"] else " sin interpolar.")
                      + f" Tiempo estimado: {elegida['coste'] / 60:.0f} min.")
    else:
        elegida = min(opciones, key=lambda o: o["coste"])
        explic.append(f"Nada cabe en {minutos:.0f} min. Se propone lo más rápido "
                      f"({elegida['cand']['id']}), que tardaría {elegida['coste'] / 60:.0f} min.")

    if elegida.get("limpieza") == "rapida":
        rec["polvo"]["activo"] = False
        rec["polvo"]["rayas"] = False
        rec["ruido"]["temporal"] = 0.0
        explic.append("Limpieza rápida: sin detección de motas ni promedio temporal, que es lo que "
                      "más tiempo consume. Si el material tiene suciedad, desactívala en Ajustes.")
    cand = elegida["cand"]
    rec["mejora"].update({
        "activo": escala > 1 or bool(elegida["fps"]),
        "escala": escala,
        "motor_escala": cand["motor"],
        "modelo_escala": cand["modelo"] or rec["mejora"]["modelo_escala"],
        "modelo_pth": cand["modelo"] if cand["motor"] == "spandrel" else rec["mejora"].get("modelo_pth"),
        "mezcla_ia": 1.0 if cand["motor"] != "lanczos" else 0.0,
        "fps_salida": elegida["fps"],
        "orden": "auto",
        "lienzo": rec["mejora"].get("lienzo", "16:9"),
    })
    rec["exportar"]["codificador"] = "auto"

    explic.insert(0, f"El detalle real del escaneo llega al {corte * 100:.0f} % de la frecuencia máxima "
                     f"(por encima solo hay grano), así que ampliar más de ×{escala_maxima(corte):g} no añade "
                     f"información. Salida fijada en {alto} px de alto (escala ×{escala}).")
    explic.append(f"Ruido medido σ={ruido}: reducción temporal al {rec['ruido']['temporal'] * 100:.0f} %, "
                  f"conservando el {rec['ruido']['grano'] * 100:.0f} % del grano.")
    if marcas.get("nvenc"):
        explic.append("La codificación final irá por NVENC (GPU).")

    # Decir en voz alta qué queda activado y qué no, y por qué: nada de decisiones mudas
    d = diagnostico
    estado = [
        f"motas: {'sí' if rec['polvo']['activo'] else 'no'} (medido {d.get('polvo_pct_pixeles', 0)} % de "
        f"píxeles con suciedad" + (f", umbral {rec['polvo']['umbral']})" if rec["polvo"]["activo"] else ")"),
        f"rayas: {'sí' if rec['polvo'].get('rayas') else 'no'}",
        f"parpadeo: {'sí' if rec['deflicker']['activo'] else 'no'} (medido {d.get('parpadeo_std', 0)})",
        f"estabilización: {'sí' if rec['estabilizar']['activo'] else 'no'}",
        f"duplicados: {'se quitan' if rec['normalizar']['quitar_duplicados'] else 'no hay'} "
        f"({d.get('duplicados_pct', 0)} %)",
        f"desentrelazado: {'sí' if rec['normalizar']['desentrelazar'] else 'no'} "
        f"({d.get('entrelazado_pct', 0)} %)",
    ]
    explic.append("Etapas de limpieza — " + "; ".join(estado) + ".")
    if marcas.get("omitidos"):
        explic.append("No respondieron durante la medición y se han descartado: "
                      + ", ".join(marcas["omitidos"]) + " (puede que la GPU estuviera ocupada).")

    vistas, alternativas = set(), []
    for o in sorted(opciones, key=lambda o: (-o["calidad"], o["coste"])):
        k = (o["cand"]["id"], o["fps"], o.get("limpieza"))
        if k in vistas:
            continue
        vistas.add(k)
        alternativas.append(o)
        if len(alternativas) >= 6:
            break
    return {
        "receta": rec,
        "estimado_s": int(elegida["coste"]),
        "alto_objetivo": alto,
        "explicacion": explic,
        "alternativas": [{"modelo": o["cand"]["id"], "fps": o["fps"], "minutos": round(o["coste"] / 60),
                          "limpieza": o.get("limpieza", "completa"), "calidad": round(o["calidad"], 2)}
                         for o in alternativas],
        "marcas": {k: (round(v, 3) if isinstance(v, float) else v) for k, v in marcas.items()},
        "medidas": medidas,
    }
