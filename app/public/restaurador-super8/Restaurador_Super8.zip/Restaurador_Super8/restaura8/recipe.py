"""Recetas de procesado (JSON) y preajustes."""
from __future__ import annotations

import copy
import json
from pathlib import Path

PRESET_DIR = Path(__file__).resolve().parent.parent / "presets"

DEFAULT = {
    "normalizar": {
        "film_fps": 18.0,            # cadencia de rodaje: 16 (8 mm), 18 o 24 (Super 8)
        "quitar_duplicados": True,
        "desentrelazar": False,
        "recorte": None,             # [x, y, ancho, alto] en píxeles del original, o null
    },
    "estabilizar": {
        "activo": True,
        "vaiven": 1.0,               # 0–1: cuánto vaivén de ventanilla se elimina
        "camara": 0.2,               # 0–1: cuánto se suaviza el movimiento de cámara (0 = se conserva)
        "zoom": 1.03,                # ampliación para ocultar los bordes compensados
        "rotacion": True,            # corregir también el giro
    },
    "deflicker": {"activo": True, "ventana": 12, "fuerza": 1.0, "zonas": False},
    "polvo": {"activo": True, "umbral": 28, "area_max": 400, "rayas": True, "umbral_rayas": 5.0},
    "ruido": {
        "temporal": 0.6,             # 0–1: promedio temporal con compensación de movimiento
        "espacial": 0.0,             # 0–1: NL-means espacial (lento)
        "grano": 0.5,                # 0–1: proporción de grano original que se conserva
    },
    "color": {"activo": True, "balance": 0.8, "niveles": 0.7, "saturacion": 1.05},
    "caras": {                       # solo afecta a la copia mejorada, nunca al máster
        "activo": False,             # reconstruye rostros: puede inventar rasgos
        "modelo": "GFPGANv1.4",
        "intensidad": 0.6,           # 0–1: mezcla con la cara original
        "minimo_px": 80,             # caras más pequeñas se dejan como están
    },
    "nitidez_master": {"cantidad": 0.3, "radio": 1.2},
    "mejora": {
        "activo": True,
        "escala": 2,                 # 1, 2 o 4
        "motor_escala": "auto",      # auto | realesrgan-ncnn | spandrel | lanczos
        "modelo_escala": "realesr-animevideov3",   # modelos ncnn incluidos
        "modelo_pth": "realesr-general-x4v3",       # modelo PyTorch (motor spandrel)
        "mezcla_ia": 0.7,            # 0 = solo lanczos (máxima fidelidad), 1 = solo IA
        "fps_salida": 25,            # null = cadencia de rodaje
        "motor_interpolacion": "auto",  # auto | rife-ncnn | minterpolate | repetir
        "modelo_interpolacion": "rife-v4.6",
        "nitidez": 0.35,
        "regranulado": 0.15,
        "lienzo": "16:9",            # 16:9 añade bandas laterales; "original" conserva 4:3
        "orden": "auto",             # auto | interpolar_primero | escalar_primero
                                     # Con modelos pesados sale a cuenta escalar primero:
                                     # se escalan menos fotogramas (los que había antes de interpolar).
    },
    "exportar": {
        "master": "ffv1",            # ffv1 | prores
        "compartir": "h264",         # h264 | h265 | null
        "crf": 18,
        "audio_limpieza": True,
        "comparacion_seg": -1,       # vídeo comparativo completo al terminar (0 = no generarlo)
        "codificador": "auto",       # auto (NVENC si hay GPU NVIDIA) | cpu
    },
}


def deep_update(base: dict, upd: dict) -> dict:
    for k, v in upd.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            deep_update(base[k], v)
        else:
            base[k] = v
    return base


def load_preset(name: str) -> dict:
    rec = copy.deepcopy(DEFAULT)
    p = PRESET_DIR / f"{name}.json"
    if not p.exists():
        raise FileNotFoundError(f"Preajuste desconocido: {name}")
    return deep_update(rec, json.loads(p.read_text(encoding="utf-8")))


def load_recipe(path_or_preset: str) -> dict:
    p = Path(path_or_preset)
    if p.suffix == ".json" and p.exists():
        return deep_update(copy.deepcopy(DEFAULT), json.loads(p.read_text(encoding="utf-8")))
    return load_preset(path_or_preset)


def save_recipe(rec: dict, path: str | Path) -> None:
    Path(path).write_text(json.dumps(rec, indent=2, ensure_ascii=False), encoding="utf-8")
