"""Modelos de PyTorch cargados con spandrel: escalado y restauración de caras.

Permite usar cualquier modelo .pth de los catálogos habituales (OpenModelDB, Real-ESRGAN,
GFPGAN...) en vez de los modelos ncnn incluidos. Se descargan bajo demanda a herramientas\\modelos.
"""
from __future__ import annotations

import os
import urllib.request
from pathlib import Path

import cv2
import numpy as np

from . import gpu as G

MODELOS = Path(__file__).resolve().parent.parent / "herramientas" / "modelos"

# Modelos que la app sabe descargar sola (nombre -> (url, para qué sirve))
CATALOGO = {
    "realesr-general-x4v3": (
        "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesr-general-x4v3.pth",
        "Escalado ×4 general, ligero y natural. Buen punto de partida para película real."),
    "RealESRGAN_x4plus": (
        "https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth",
        "Escalado ×4 para imagen real, más detalle y más lento."),
    "GFPGANv1.4": (
        "https://github.com/TencentARC/GFPGAN/releases/download/v1.3.4/GFPGANv1.4.pth",
        "Restauración de caras (reconstruye rostros: puede inventar rasgos)."),
    "yunet": (
        "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/"
        "face_detection_yunet/face_detection_yunet_2023mar.onnx",
        "Detector de caras (OpenCV YuNet)."),
}

_CACHE: dict = {}


def ruta_modelo(nombre: str) -> Path:
    ext = ".onnx" if nombre == "yunet" else ".pth"
    p = MODELOS / f"{nombre}{ext}"
    if p.exists():
        return p
    # ¿lo ha dejado el usuario con otra extensión?
    for alt in MODELOS.glob(f"{nombre}.*"):
        return alt
    if nombre in CATALOGO:
        MODELOS.mkdir(parents=True, exist_ok=True)
        url = CATALOGO[nombre][0]
        print(f"[aviso] Descargando el modelo {nombre} ({url})", flush=True)
        tmp = p.with_suffix(p.suffix + ".parcial")
        with urllib.request.urlopen(url, timeout=600) as r, open(tmp, "wb") as fh:
            while True:
                trozo = r.read(1 << 20)
                if not trozo:
                    break
                fh.write(trozo)
        os.replace(tmp, p)
        return p
    raise FileNotFoundError(f"No se encuentra el modelo '{nombre}' en {MODELOS}")


def disponibles() -> list[str]:
    """Modelos .pth presentes en herramientas\\modelos, más los descargables."""
    locales = sorted({p.stem for p in MODELOS.glob("*.pth")}) if MODELOS.exists() else []
    return sorted(set(locales) | {k for k in CATALOGO if k != "yunet"})


def cargar(nombre: str):
    """Carga un modelo con spandrel en la GPU (o CPU) y lo deja listo para inferencia."""
    if nombre in _CACHE:
        return _CACHE[nombre]
    import torch
    from spandrel import ImageModelDescriptor, ModelLoader

    d = G.device() or torch.device("cpu")
    modelo = ModelLoader().load_from_file(str(ruta_modelo(nombre)))
    if not isinstance(modelo, ImageModelDescriptor):
        raise TypeError(f"El modelo {nombre} no es de imagen")
    modelo.to(d).eval()
    if d.type == "cuda" and modelo.supports_half:
        modelo.model.half()
    _CACHE[nombre] = modelo
    return modelo


def _tensor(img: np.ndarray, modelo):
    import torch

    d = next(modelo.model.parameters())
    t = torch.from_numpy(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)).to(d.device)
    t = t.permute(2, 0, 1).unsqueeze(0).to(d.dtype) / 255.0
    return t


def _imagen(t) -> np.ndarray:
    a = t.squeeze(0).permute(1, 2, 0).float().clamp(0, 1).cpu().numpy()
    return cv2.cvtColor((a * 255).round().astype(np.uint8), cv2.COLOR_RGB2BGR)


def aplicar(img: np.ndarray, nombre: str, tile: int = 384, solape: int = 32) -> np.ndarray:
    """Pasa la imagen por el modelo, por baldosas con solape para no agotar la VRAM."""
    import torch

    modelo = cargar(nombre)
    escala = int(getattr(modelo, "scale", 1) or 1)
    H, W = img.shape[:2]
    salida = np.zeros((H * escala, W * escala, 3), np.uint8)
    paso = max(64, tile - solape)
    with torch.inference_mode():
        if tile <= 0 or (H <= tile and W <= tile):
            return _imagen(modelo(_tensor(img, modelo)))
        for y in range(0, H, paso):
            for x in range(0, W, paso):
                y1, x1 = min(y + tile, H), min(x + tile, W)
                y0, x0 = max(0, y1 - tile), max(0, x1 - tile)
                trozo = _imagen(modelo(_tensor(img[y0:y1, x0:x1], modelo)))
                # Se recorta el solape para quedarse con el centro de cada baldosa
                cy = 0 if y0 == 0 else solape // 2
                cx = 0 if x0 == 0 else solape // 2
                salida[(y0 + cy) * escala: y1 * escala, (x0 + cx) * escala: x1 * escala] = \
                    trozo[cy * escala:, cx * escala:]
    return salida


def escala_de(nombre: str) -> int:
    return int(getattr(cargar(nombre), "scale", 1) or 1)
