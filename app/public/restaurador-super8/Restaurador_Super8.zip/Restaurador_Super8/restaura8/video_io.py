"""Lectura y escritura de vídeo mediante tuberías de FFmpeg (fotogramas BGR uint8)."""
from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Iterator, Optional

import numpy as np


def require(binary: str) -> str:
    path = shutil.which(binary)
    if not path:
        raise RuntimeError(f"No se encuentra '{binary}' en el PATH. Instálalo antes de continuar.")
    return path


@dataclass
class VideoInfo:
    path: Path
    width: int
    height: int
    fps: Fraction
    nb_frames: int
    duration: float
    has_audio: bool
    codec: str
    field_order: str

    @property
    def fps_float(self) -> float:
        return float(self.fps)


def probe(path: str | Path) -> VideoInfo:
    require("ffprobe")
    path = Path(path)
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-print_format", "json", "-show_streams", "-show_format", str(path)],
        capture_output=True, text=True, check=True,
    ).stdout
    data = json.loads(out)
    v = next(s for s in data["streams"] if s["codec_type"] == "video")
    has_audio = any(s["codec_type"] == "audio" for s in data["streams"])
    fps = Fraction(v.get("avg_frame_rate") or v.get("r_frame_rate") or "25/1")
    if fps == 0:
        fps = Fraction(v.get("r_frame_rate", "25/1"))
    duration = float(v.get("duration") or data["format"].get("duration") or 0)
    nb = int(v.get("nb_frames") or 0) or int(round(duration * float(fps)))
    return VideoInfo(
        path=path, width=int(v["width"]), height=int(v["height"]), fps=fps,
        nb_frames=nb, duration=duration, has_audio=has_audio,
        codec=v.get("codec_name", "?"), field_order=v.get("field_order", "unknown"),
    )


def read_frames(path: str | Path, vf: Optional[str] = None, size: Optional[tuple[int, int]] = None,
                ) -> Iterator[np.ndarray]:
    """Genera fotogramas BGR uint8. `vf` es una cadena de filtros FFmpeg opcional;
    si cambia el tamaño, hay que pasar `size=(w, h)` con el tamaño resultante."""
    require("ffmpeg")
    info = probe(path)
    w, h = size or (info.width, info.height)
    cmd = ["ffmpeg", "-v", "error", "-i", str(path), "-an"]
    if vf:
        cmd += ["-vf", vf]
    cmd += ["-fps_mode", "passthrough", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    import tempfile
    err = tempfile.TemporaryFile()
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=err)
    frame_bytes = w * h * 3
    finished = False
    try:
        while True:
            buf = proc.stdout.read(frame_bytes)
            if len(buf) < frame_bytes:
                finished = True
                break
            yield np.frombuffer(buf, np.uint8).reshape(h, w, 3).copy()
    finally:
        if not finished:
            proc.kill()  # el consumidor dejó de leer: no es un error
        proc.stdout.close()
        rc = proc.wait()
        if finished and rc != 0:
            err.seek(0)
            msg = err.read().decode("utf-8", "replace").strip()
            err.close()
            raise RuntimeError(f"FFmpeg no pudo leer {path}: {msg[-500:]}")
        err.close()


class FrameWriter:
    """Escribe fotogramas BGR uint8 a un archivo mediante FFmpeg."""

    LOSSLESS = ["-c:v", "ffv1", "-level", "3", "-g", "1", "-pix_fmt", "bgr0"]

    def __init__(self, path: str | Path, width: int, height: int, fps: Fraction | float,
                 codec_args: Optional[list[str]] = None, audio_from: Optional[Path] = None,
                 audio_filter: Optional[str] = None, vf: Optional[str] = None):
        require("ffmpeg")
        self.w, self.h = width, height
        fps = Fraction(fps).limit_denominator(1001)
        cmd = ["ffmpeg", "-v", "error", "-y",
               "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{width}x{height}",
               "-r", f"{fps.numerator}/{fps.denominator}", "-i", "-"]
        if audio_from is not None:
            cmd += ["-i", str(audio_from), "-map", "0:v:0", "-map", "1:a:0?", "-shortest"]
            if audio_filter:
                cmd += ["-af", audio_filter]
            cmd += ["-c:a", "flac" if str(path).endswith(".mkv") else "aac"]
        if vf:
            cmd += ["-vf", vf]
        cmd += (codec_args or self.LOSSLESS) + [str(path)]
        self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        self.count = 0

    def write(self, frame: np.ndarray) -> None:
        if frame.shape[:2] != (self.h, self.w):
            raise ValueError(f"Tamaño {frame.shape[:2]} distinto del esperado {(self.h, self.w)}")
        self.proc.stdin.write(np.ascontiguousarray(frame, dtype=np.uint8).tobytes())
        self.count += 1

    def close(self) -> None:
        self.proc.stdin.close()
        if self.proc.wait() != 0:
            raise RuntimeError("FFmpeg terminó con error al escribir el vídeo")

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def run_ffmpeg(args: list[str]) -> None:
    require("ffmpeg")
    subprocess.run(["ffmpeg", "-v", "error", "-y", *args], check=True)


_ENC_CACHE: dict = {}


def encoder_works(name: str) -> bool:
    """Comprueba con una codificación mínima que el codificador funciona (p. ej. NVENC)."""
    if name in _ENC_CACHE:
        return _ENC_CACHE[name]
    try:
        r = subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "color=black:s=256x256:d=0.2",
                            "-c:v", name, "-f", "null", "-"], capture_output=True, timeout=60)
        ok = r.returncode == 0
    except Exception:  # noqa: BLE001
        ok = False
    _ENC_CACHE[name] = ok
    return ok


def progress(stage: str, done: int, total: int) -> None:
    """Línea de progreso legible por la interfaz."""
    print(f"@@PROGRESO {stage} {done} {total}", flush=True)
