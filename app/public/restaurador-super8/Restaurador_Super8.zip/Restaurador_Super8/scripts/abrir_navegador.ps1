﻿param([int]$Puerto = 8765)
$ErrorActionPreference = 'SilentlyContinue'
$url = "http://127.0.0.1:$Puerto"
for ($i = 0; $i -lt 120; $i++) {
    try {
        $r = Invoke-WebRequest -UseBasicParsing -Uri "$url/api/salud" -TimeoutSec 2
        if ($r.StatusCode -eq 200) { Start-Process $url; exit 0 }
    } catch { }
    Start-Sleep -Milliseconds 750
}
exit 1
