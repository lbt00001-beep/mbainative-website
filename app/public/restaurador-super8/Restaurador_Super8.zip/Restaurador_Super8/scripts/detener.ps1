﻿<#
  Cierra la ejecución anterior de Restaurador Super 8:
  terminal (cmd) anterior, servidor, trabajos en curso, lo que escuche en el puerto
  y cualquier proceso restante de la app (python del entorno, ffmpeg, RIFE, Real-ESRGAN).
  Nunca cierra el propio proceso ni sus antecesores (la terminal actual).
#>
param(
    [int]$Puerto = 8765,
    [switch]$RegistrarConsola,   # tras limpiar, guarda el PID de la terminal actual
    [switch]$SoloRegistrar       # no limpia; solo guarda el PID de la terminal actual
)
$ErrorActionPreference = 'Continue'
$App = (Split-Path -Parent $PSScriptRoot).TrimEnd('\')
$Run = Join-Path $App 'run'
New-Item -ItemType Directory -Force -Path (Join-Path $Run 'trabajos') | Out-Null

function Instantanea {
    $t = @{}
    Get-CimInstance Win32_Process | ForEach-Object { $t[[int]$_.ProcessId] = $_ }
    return $t
}
$procs = Instantanea

# Antecesores del proceso actual: no se tocan
$excluir = New-Object 'System.Collections.Generic.HashSet[int]'
$p = [int]$PID
while ($p -gt 0 -and $procs.ContainsKey($p) -and $excluir.Add($p)) { $p = [int]$procs[$p].ParentProcessId }

function Guardar-Consola {
    # La terminal actual es el cmd.exe antecesor que ejecuta EJECUTAR.bat
    $p = [int]$PID
    $visto = @{}
    while ($p -gt 0 -and $procs.ContainsKey($p) -and -not $visto.ContainsKey($p)) {
        $visto[$p] = $true
        $pr = $procs[$p]
        if ($pr.Name -ieq 'cmd.exe' -and ([string]$pr.CommandLine) -like '*EJECUTAR*') {
            Set-Content -Path (Join-Path $Run 'consola.pid') -Value $p -Encoding ASCII
            return
        }
        $p = [int]$pr.ParentProcessId
    }
}

if ($SoloRegistrar) { Guardar-Consola; exit 0 }

$cerrados = 0
function Matar([int]$id, [string]$motivo) {
    if ($id -le 4 -or $excluir.Contains($id) -or -not $procs.ContainsKey($id)) { return }
    Write-Host ("      - {0} (PID {1}): {2}" -f $procs[$id].Name, $id, $motivo)
    & taskkill.exe /PID $id /T /F 2>&1 | Out-Null
    $script:cerrados++
}
function Leer-Pid([string]$f) {
    try { return [int]((Get-Content -Path $f -ErrorAction Stop | Select-Object -First 1).Trim()) } catch { return 0 }
}

# 1. Terminal anterior (comprobando que sigue siendo la de EJECUTAR.bat)
$f = Join-Path $Run 'consola.pid'
if (Test-Path $f) {
    $id = Leer-Pid $f
    if ($procs.ContainsKey($id) -and $procs[$id].Name -ieq 'cmd.exe' -and ([string]$procs[$id].CommandLine) -like '*EJECUTAR*') {
        Matar $id 'terminal anterior'
    }
    Remove-Item $f -Force -ErrorAction SilentlyContinue
}

# 2. Servidor
$f = Join-Path $Run 'servidor.pid'
if (Test-Path $f) {
    $id = Leer-Pid $f
    if ($procs.ContainsKey($id) -and $procs[$id].Name -like 'python*') { Matar $id 'servidor' }
    Remove-Item $f -Force -ErrorAction SilentlyContinue
}

# 3. Trabajos en curso
Get-ChildItem -Path (Join-Path $Run 'trabajos') -Filter '*.pid' -ErrorAction SilentlyContinue | ForEach-Object {
    $id = Leer-Pid $_.FullName
    if ($procs.ContainsKey($id) -and $procs[$id].Name -like 'python*') { Matar $id 'trabajo en curso' }
    Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
}

# 4. Procesos que escuchan en el puerto
function Pids-Puerto {
    $r = @()
    try {
        $r = @(Get-NetTCPConnection -LocalPort $Puerto -State Listen -ErrorAction Stop |
               Select-Object -ExpandProperty OwningProcess -Unique)
    } catch {
        # Alternativa independiente del idioma de Windows (LISTENING / ESCUCHANDO)
        foreach ($l in (netstat -ano -p tcp)) {
            $t = $l.Trim() -split '\s+'
            if ($t.Count -ge 5 -and $t[1] -match (":$Puerto$") -and $t[3] -match 'LISTEN|ESCUCHA') { $r += [int]$t[4] }
        }
    }
    return $r | Where-Object { $_ -gt 4 } | Select-Object -Unique
}
foreach ($id in (Pids-Puerto)) { Matar ([int]$id) "escuchaba en el puerto $Puerto" }

# 5. Restos de la app (procesos huérfanos)
$procs = Instantanea
$appLow = $App.ToLower()
foreach ($pr in @($procs.Values)) {
    $exe = ([string]$pr.ExecutablePath).ToLower()
    $cl = [string]$pr.CommandLine
    $esApp = $exe.StartsWith($appLow + '\')
    $esPy = ($pr.Name -like 'python*') -and (($cl -like '*servidor.py*' -and $cl.ToLower().Contains($appLow)) -or $cl -like '*-m restaura8*')
    if ($esApp -or $esPy) { Matar ([int]$pr.ProcessId) 'proceso de la app' }
}

# 6. Ventanas con el título de la app (consola clásica)
Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like 'RESTAURA8_SRV*' } | ForEach-Object {
    Matar ([int]$_.Id) 'ventana anterior'
}

# Esperar a que el puerto quede libre
for ($i = 0; $i -lt 30; $i++) {
    if (-not (Pids-Puerto)) { break }
    Start-Sleep -Milliseconds 500
}
if (Pids-Puerto) {
    Write-Host "      AVISO: el puerto $Puerto sigue ocupado." -ForegroundColor Yellow
}
if ($cerrados -eq 0) { Write-Host '      No quedaba nada abierto.' }
else { Write-Host ("      Cerrados: {0}" -f $cerrados) }

if ($RegistrarConsola) { $procs = Instantanea; Guardar-Consola }
exit 0
