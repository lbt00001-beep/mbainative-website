﻿<#
  Instalación y comprobación de dependencias de Restaurador Super 8.
  Solo descarga lo que falte. Opciones:
    -SinTorch   no instala PyTorch (todo el procesado en CPU)
    -Reintentar vuelve a intentar PyTorch con CUDA aunque haya fallado antes
#>
param([switch]$SinTorch, [switch]$Reintentar)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

$App   = (Split-Path -Parent $PSScriptRoot).TrimEnd('\')
$Herr  = Join-Path $App 'herramientas'
$Venv  = Join-Path $App '.venv'
$Py    = Join-Path $Venv 'Scripts\python.exe'
$Run   = Join-Path $App 'run'
$Tmp   = Join-Path $Herr '_descargas'
New-Item -ItemType Directory -Force -Path $Herr, $Run, $Tmp | Out-Null

# pip descarga y descomprime varios GB: que use la unidad de la app, no C:
$env:PIP_CACHE_DIR = Join-Path $Herr '_pipcache'
$env:TMP = Join-Path $Herr '_temp'
$env:TEMP = $env:TMP
New-Item -ItemType Directory -Force -Path $env:PIP_CACHE_DIR, $env:TMP | Out-Null

function Espacio-Libre-GB {
    try {
        $letra = (Split-Path -Qualifier $App).TrimEnd(':')
        return [math]::Round((Get-PSDrive $letra).Free / 1GB, 1)
    } catch { return -1 }
}

$URL_FFMPEG = 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip'
$URL_ESRGAN = 'https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-windows.zip'
$URL_RIFE   = 'https://github.com/nihui/rife-ncnn-vulkan/releases/download/20221029/rife-ncnn-vulkan-20221029-windows.zip'

function Paso([string]$t) { Write-Host "      $t" -ForegroundColor Cyan }
function Ok([string]$t)   { Write-Host "      OK  $t" -ForegroundColor Green }
function Aviso([string]$t){ Write-Host "      !!  $t" -ForegroundColor Yellow }
function Fallo([string]$t){ Write-Host "      ERROR  $t" -ForegroundColor Red; exit 1 }

function Descargar([string]$url, [string]$dest) {
    Paso "Descargando $url"
    if (Test-Path $dest) { Remove-Item $dest -Force }
    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if ($curl) {
        & $curl.Source -L --fail --retry 3 --progress-bar -o $dest $url
        if ($LASTEXITCODE -eq 0 -and (Test-Path $dest)) { return $true }
    }
    try {
        Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $dest -ErrorAction Stop
        return (Test-Path $dest)
    } catch {
        Aviso "No se pudo descargar: $($_.Exception.Message)"
        return $false
    }
}

function Instalar-Zip([string]$url, [string]$nombre, [string]$exe) {
    # Descarga y descomprime en herramientas\<nombre>; devuelve la ruta del ejecutable.
    $destino = Join-Path $Herr $nombre
    $hallado = Get-ChildItem -Path $destino -Recurse -Filter $exe -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($hallado) { return $hallado.FullName }
    $zip = Join-Path $Tmp "$nombre.zip"
    if (-not (Descargar $url $zip)) { return $null }
    Paso "Descomprimiendo $nombre"
    if (Test-Path $destino) { Remove-Item $destino -Recurse -Force }
    try { Expand-Archive -Path $zip -DestinationPath $destino -Force -ErrorAction Stop }
    catch { Aviso "No se pudo descomprimir $($zip): $($_.Exception.Message)"; return $null }
    Remove-Item $zip -Force -ErrorAction SilentlyContinue
    $hallado = Get-ChildItem -Path $destino -Recurse -Filter $exe -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($hallado) { return $hallado.FullName }
    return $null
}

# ------------------------------------------------------------------ Python
function Version-Python([string]$exe) {
    $v = & $exe -c "import sys;print('%d.%d' % sys.version_info[:2])" 2>$null
    if ($LASTEXITCODE -eq 0 -and $v) { return [version]($v | Select-Object -First 1).Trim() }
    return $null
}

function Buscar-Python {
    $py = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($py) {
        foreach ($v in '3.12', '3.11', '3.13', '3.10') {
            $exe = & $py.Source "-$v" -c "import sys;print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $exe) { return ($exe | Select-Object -First 1).Trim() }
        }
    }
    $candidatos = @()
    foreach ($n in 'python.exe', 'python3.exe') {
        Get-Command $n -All -ErrorAction SilentlyContinue | ForEach-Object { $candidatos += $_.Source }
    }
    foreach ($v in '312', '311', '313', '310') {
        $candidatos += (Join-Path $env:LOCALAPPDATA "Programs\Python\Python$v\python.exe")
        $candidatos += (Join-Path $env:ProgramFiles "Python$v\python.exe")
    }
    foreach ($c in $candidatos) {
        if (-not $c -or -not (Test-Path $c) -or $c -like '*WindowsApps*') { continue }
        $ver = Version-Python $c
        if ($ver -and $ver -ge [version]'3.10' -and $ver -lt [version]'3.14') { return $c }
    }
    return $null
}

if (-not (Test-Path $Py)) {
    Paso 'Buscando Python 3.10-3.13...'
    $base = Buscar-Python
    if (-not $base) {
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if ($winget) {
            Paso 'Instalando Python 3.12 con winget (solo para tu usuario)...'
            & $winget.Source install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
            $env:Path = [Environment]::GetEnvironmentVariable('Path', 'User') + ';' + [Environment]::GetEnvironmentVariable('Path', 'Machine')
            $base = Buscar-Python
        }
    }
    if (-not $base) { Fallo 'No se encontró Python 3.10-3.13. Instala Python 3.12 desde https://www.python.org/downloads/ y vuelve a ejecutar.' }
    Ok "Python: $base"
    Paso 'Creando el entorno virtual .venv'
    & $base -m venv $Venv
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $Py)) { Fallo 'No se pudo crear el entorno virtual.' }
    & $Py -m pip install --upgrade pip --disable-pip-version-check -q
}

# ------------------------------------------------------------------ paquetes
$req = Join-Path $App 'requirements.txt'
$marca = Join-Path $Venv 'restaura8_requisitos.txt'
$hash = (Get-FileHash $req -Algorithm SHA256).Hash
$previo = if (Test-Path $marca) { (Get-Content $marca -Raw).Trim() } else { '' }
if ($previo -ne $hash) {
    Paso 'Instalando paquetes de Python (numpy, OpenCV, FastAPI, uvicorn)...'
    & $Py -m pip install --disable-pip-version-check -r $req
    if ($LASTEXITCODE -ne 0) { Fallo 'pip no pudo instalar los paquetes.' }
    Set-Content -Path $marca -Value $hash -Encoding ASCII
}
Ok 'Paquetes de Python'

# ------------------------------------------------------------------ PyTorch CUDA
$nvsmi = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue
if (-not $nvsmi -and (Test-Path "$env:SystemRoot\System32\nvidia-smi.exe")) { $nvsmi = Get-Item "$env:SystemRoot\System32\nvidia-smi.exe" }
$marcaTorch = Join-Path $Venv 'restaura8_torch_fallido.txt'
$dllCuda = Join-Path $Venv 'Lib\site-packages\torch\lib\torch_cuda.dll'
$dirTorch = Join-Path $Venv 'Lib\site-packages\torch'

function Torch-Cuda {
    # No basta con torch.cuda.is_available(): hay que reservar memoria de verdad.
    # Con un driver antiguo, is_available() dice Sí y luego el primer tensor falla.
    & $Py -c "import torch,sys;t=torch.zeros(8,8,device='cuda');sys.exit(0 if float(t.sum())==0 else 1)" 2>$null
    return ($LASTEXITCODE -eq 0)
}

function Version-Driver {
    $v = (& $nvsmi.Source --query-gpu=driver_version --format=csv,noheader 2>$null | Select-Object -First 1)
    if ($v) { try { return [double](($v.Trim() -split '\.')[0..1] -join '.') } catch { return 0 } }
    return 0
}

function Cuda-Del-Driver {
    # nvidia-smi dice hasta qué CUDA llega el controlador instalado.
    $txt = & $nvsmi.Source 2>$null | Out-String
    if ($txt -match 'CUDA Version:\s*([0-9]+\.[0-9]+)') { return [double]$Matches[1] }
    return 0
}

function Indices-Cuda {
    # Se elige la compilación más nueva de PyTorch cuya CUDA no supere la del controlador.
    # (Con una CUDA más nueva que la del driver, la tarjeta se ve pero el primer tensor falla.)
    $cuda = Cuda-Del-Driver
    $drv = Version-Driver
    Paso ("Controlador NVIDIA {0}, admite hasta CUDA {1}" -f $drv, $cuda)
    $builds = @(
        @{ n = 'cu128'; v = 12.8 },
        @{ n = 'cu126'; v = 12.6 },
        @{ n = 'cu124'; v = 12.4 },
        @{ n = 'cu121'; v = 12.1 },
        @{ n = 'cu118'; v = 11.8 }
    )
    if ($cuda -le 0) { return @('cu124', 'cu118') }
    $ok = @($builds | Where-Object { $_.v -le $cuda } | ForEach-Object { $_.n })
    if (-not $ok) {
        Aviso 'El controlador NVIDIA es demasiado antiguo para cualquier PyTorch con CUDA. Actualízalo.'
        return @()
    }
    return $ok
}
function Torch-Roto {
    # Instalación interrumpida: queda la carpeta torch pero sin la parte de CUDA
    return ((Test-Path $dirTorch) -and -not (Test-Path $dllCuda))
}

if ($SinTorch) {
    Aviso 'PyTorch omitido (-SinTorch): la limpieza irá por CPU.'
} elseif (-not $nvsmi) {
    Aviso 'No se detecta una GPU NVIDIA (nvidia-smi): la limpieza irá por CPU.'
} elseif (Torch-Cuda) {
    Ok 'PyTorch con CUDA'
} elseif ((Test-Path $marcaTorch) -and -not $Reintentar -and -not (Torch-Roto)) {
    Aviso 'PyTorch con CUDA falló en un intento anterior; se usa CPU. Para reintentar: scripts\instalar.ps1 -Reintentar'
} else {
    $libre = Espacio-Libre-GB
    Paso ("Instalando PyTorch con CUDA. Necesita unos 8 GB libres en la unidad de la app; hay {0} GB." -f $libre)
    if ($libre -ge 0 -and $libre -lt 8) {
        Aviso 'Espacio insuficiente: libera espacio (o mueve la carpeta de la app a un disco con sitio) y vuelve a ejecutar.'
    } else {
        try { $drv = & $nvsmi.Source --query-gpu=name,driver_version --format=csv,noheader 2>$null; if ($drv) { Paso ("GPU: {0}" -f ($drv | Select-Object -First 1)) } } catch { }
        if (Torch-Roto) {
            Paso 'La instalación anterior de PyTorch quedó incompleta: se desinstala antes de reinstalar.'
            & $Py -m pip uninstall -y torch 2>&1 | Out-Null
            if (Test-Path $dirTorch) { Remove-Item $dirTorch -Recurse -Force -ErrorAction SilentlyContinue }
        }
        $hecho = $false
        $indices = Indices-Cuda
        if (-not $indices) { $indices = @('cu118') }
        foreach ($idx in $indices) {
            Paso "Descargando PyTorch $idx (unos 2,5 GB)..."
            & $Py -m pip install --disable-pip-version-check --upgrade --force-reinstall torch --index-url "https://download.pytorch.org/whl/$idx"
            if ($LASTEXITCODE -eq 0 -and (Test-Path $dllCuda) -and (Torch-Cuda)) { $hecho = $true; break }
            if (-not (Test-Path $dllCuda)) { Aviso "La instalación de PyTorch $idx quedó incompleta (¿espacio en disco?)." }
            else { Aviso "PyTorch $idx se instaló pero no puede usar la tarjeta con este controlador; probando una compilación más antigua..." }
        }
        if ($hecho) {
            Remove-Item $marcaTorch -Force -ErrorAction SilentlyContinue
            $gpu = & $Py -c "import torch;print(torch.cuda.get_device_name(0))" 2>$null
            Ok "PyTorch con CUDA: $gpu"
        } else {
            Set-Content -Path $marcaTorch -Value (Get-Date) -Encoding ASCII
            Aviso 'No se pudo activar CUDA en PyTorch. La limpieza irá por CPU; el resto (RIFE, Real-ESRGAN y NVENC) sigue usando la GPU.'
            Aviso 'Solución recomendada: actualizar el controlador NVIDIA desde https://www.nvidia.es/Download/index.aspx y volver a ejecutar EJECUTAR.bat.'
            Aviso ("Espacio libre ahora: {0} GB" -f (Espacio-Libre-GB))
        }
    }
}
# Liberar los temporales de pip (la caché se conserva para no volver a descargar)
Remove-Item $env:TMP -Recurse -Force -ErrorAction SilentlyContinue

# ------------------------------------------------------------------ spandrel (modelos .pth)
# Se instala DESPUÉS de PyTorch y sin dependencias, para que pip no sustituya la versión
# con CUDA por la de CPU de PyPI. torchvision se toma del mismo índice que torch.
if (-not $SinTorch -and (Torch-Cuda)) {
    & $Py -c "import spandrel" 2>$null
    if ($LASTEXITCODE -ne 0) {
        Paso 'Instalando spandrel (permite usar modelos .pth de OpenModelDB, GFPGAN, etc.)'
        $idx = & $Py -c "import torch;v=torch.version.cuda or '';print('cu'+v.replace('.',''))" 2>$null
        if ($idx) { & $Py -m pip install --disable-pip-version-check torchvision --index-url "https://download.pytorch.org/whl/$idx" }
        & $Py -m pip install --disable-pip-version-check --no-deps spandrel
        & $Py -m pip install --disable-pip-version-check einops safetensors
        & $Py -c "import spandrel" 2>$null
        if ($LASTEXITCODE -eq 0) { Ok 'spandrel' } else { Aviso 'No se pudo instalar spandrel: seguirá usándose Real-ESRGAN ncnn.' }
    } else { Ok 'spandrel' }
}

# ------------------------------------------------------------------ FFmpeg (con NVENC)
function Tiene-Nvenc([string]$exe) {
    $txt = & $exe -hide_banner -encoders 2>&1 | Out-String
    return ($txt -match 'h264_nvenc')
}

$ffBin = $null
$ffLocal = Get-ChildItem -Path (Join-Path $Herr 'ffmpeg') -Recurse -Filter 'ffmpeg.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
if ($ffLocal) {
    $ffBin = $ffLocal.DirectoryName
    Ok ("FFmpeg propio: {0}{1}" -f $ffBin, $(if (Tiene-Nvenc $ffLocal.FullName) { ' (con NVENC)' } else { ' (sin NVENC)' }))
} else {
    $sys = Get-Command ffmpeg.exe -ErrorAction SilentlyContinue
    if ($sys -and (Tiene-Nvenc $sys.Source)) {
        Ok 'FFmpeg del sistema (con NVENC)'
    } else {
        if ($sys) { Paso 'El FFmpeg del sistema no trae NVENC: se instala uno propio que codifica en la GPU.' }
        $exe = Instalar-Zip $URL_FFMPEG 'ffmpeg' 'ffmpeg.exe'
        if ($exe) {
            $ffBin = Split-Path -Parent $exe
            Ok ("FFmpeg propio: {0}{1}" -f $ffBin, $(if (Tiene-Nvenc $exe) { ' (con NVENC)' } else { ' (sin NVENC)' }))
        } elseif ($sys) {
            Aviso 'No se pudo descargar FFmpeg con NVENC: se usará el del sistema y la codificación final irá por CPU.'
        } else {
            Fallo 'FFmpeg es imprescindible y no se pudo instalar. Descárgalo de https://www.gyan.dev/ffmpeg/builds/ y ponlo en herramientas\ffmpeg.'
        }
    }
}

# ------------------------------------------------------------------ Real-ESRGAN y RIFE
$esrgan = Instalar-Zip $URL_ESRGAN 'realesrgan' 'realesrgan-ncnn-vulkan.exe'
if ($esrgan) { Ok "Real-ESRGAN: $esrgan" } else { Aviso 'Real-ESRGAN no disponible: se escalará con Lanczos.' }
$rife = Instalar-Zip $URL_RIFE 'rife' 'rife-ncnn-vulkan.exe'
if ($rife) { Ok "RIFE: $rife" } else { Aviso 'RIFE no disponible: se interpolará con FFmpeg (lento).' }
Remove-Item $Tmp -Recurse -Force -ErrorAction SilentlyContinue

# ------------------------------------------------------------------ rutas para EJECUTAR.bat
$lineas = @('@echo off')
if ($ffBin) { $lineas += "set `"PATH=$ffBin;%PATH%`"" }
if ($esrgan) { $lineas += "set `"RESTAURA8_REALESRGAN=$esrgan`"" }
if ($rife)   { $lineas += "set `"RESTAURA8_RIFE=$rife`"" }
$utf8 = New-Object System.Text.UTF8Encoding($false)
[IO.File]::WriteAllText((Join-Path $Herr 'rutas.cmd'), (($lineas -join "`r`n") + "`r`n"), $utf8)

# Comprobación final del motor
Push-Location $App
& $Py -c "import cv2, numpy, fastapi, uvicorn, restaura8"
$rc = $LASTEXITCODE
Pop-Location
if ($rc -ne 0) { Fallo 'La instalación está incompleta (ver el error de arriba).' }
Ok 'Instalación lista'
exit 0
