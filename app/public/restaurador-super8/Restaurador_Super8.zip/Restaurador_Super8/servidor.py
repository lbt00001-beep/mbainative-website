"""Servidor local de la app Restaurador Super 8 (FastAPI).

Se arranca con EJECUTAR.bat. Escucha solo en 127.0.0.1."""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response

BASE = Path(__file__).resolve().parent
DATOS = BASE / "datos"
SUBIDAS = DATOS / "subidas"
TRABAJOS = DATOS / "trabajos"
RESULTADOS = BASE / "resultados"
RUN = BASE / "run"
for d in (SUBIDAS, TRABAJOS, RESULTADOS, RUN / "trabajos"):
    d.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(BASE))
from restaura8 import backends as B  # noqa: E402
from restaura8 import gpu as G  # noqa: E402
from restaura8.recipe import DEFAULT, load_preset  # noqa: E402
from restaura8.video_io import encoder_works, probe, run_ffmpeg  # noqa: E402

PUERTO = int(os.environ.get("RESTAURA8_PUERTO", "8765"))


class Espejo:
    """Duplica la salida de la consola en run\servidor_log.txt para poder diagnosticar."""

    def __init__(self, flujo, destino):
        self.flujo = flujo
        try:
            self.archivo = open(destino, "a", encoding="utf-8", errors="replace")
            self.archivo.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} =====\n")
        except Exception:  # noqa: BLE001
            self.archivo = None

    def write(self, texto):
        try:
            self.flujo.write(texto)
        except Exception:  # noqa: BLE001
            pass
        if self.archivo:
            try:
                self.archivo.write(texto)
                self.archivo.flush()
            except Exception:  # noqa: BLE001
                pass
        return len(texto)

    def flush(self):
        for f in (self.flujo, self.archivo):
            try:
                if f:
                    f.flush()
            except Exception:  # noqa: BLE001
                pass

    def isatty(self):
        return False


def _espejar_salida() -> None:
    destino = RUN / "servidor_log.txt"
    try:
        if destino.exists() and destino.stat().st_size > 2_000_000:
            destino.unlink()
    except Exception:  # noqa: BLE001
        pass
    sys.stdout = Espejo(sys.stdout, destino)
    sys.stderr = Espejo(sys.stderr, destino)
EXTENSIONES = {".mp4", ".mov", ".mkv", ".avi", ".m4v", ".mts", ".m2ts", ".mpg", ".mpeg", ".wmv", ".dv", ".webm"}
IS_WIN = os.name == "nt"

from contextlib import asynccontextmanager  # noqa: E402


@asynccontextmanager
async def ciclo_vida(_app):
    al_arrancar()
    try:
        yield
    finally:
        al_parar()


app = FastAPI(title="Restaurador Super 8", lifespan=ciclo_vida)
lock = threading.RLock()


# ---------------------------------------------------------------- utilidades
def ahora() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def leer_json(p: Path, defecto=None):
    with lock:
        for intento in range(5):
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except FileNotFoundError:
                return defecto
            except (PermissionError, json.JSONDecodeError):
                time.sleep(0.05 * (intento + 1))
            except Exception:  # noqa: BLE001
                return defecto
        return defecto


def escribir_json(p: Path, data) -> None:
    with lock:
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        for intento in range(10):
            try:
                os.replace(tmp, p)
                return
            except PermissionError:
                time.sleep(0.05 * (intento + 1))
        raise RuntimeError(f"No se pudo escribir {p}")


def nombre_seguro(nombre: str) -> str:
    nombre = Path(nombre).name
    nombre = re.sub(r"[^\w.\- ]+", "_", nombre, flags=re.UNICODE).strip() or "video"
    return nombre[:120]


def matar_arbol(pid: int) -> None:
    if not pid:
        return
    try:
        if IS_WIN:
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True)
        else:
            import signal
            os.killpg(os.getpgid(pid), signal.SIGTERM)
    except Exception:  # noqa: BLE001
        pass


def info_video(ruta: Path) -> dict:
    i = probe(ruta)
    return {"ancho": i.width, "alto": i.height, "fps": round(i.fps_float, 3), "fotogramas": i.nb_frames,
            "duracion": round(i.duration, 2), "audio": i.has_audio, "codec": i.codec}


# ---------------------------------------------------------------- vídeos
VIDEOS = DATOS / "videos.json"


def videos() -> dict:
    return leer_json(VIDEOS, {}) or {}


def registrar_video(ruta: Path, subido: bool) -> dict:
    info = info_video(ruta)
    vid = uuid.uuid4().hex[:10]
    entry = {"id": vid, "nombre": ruta.name, "ruta": str(ruta), "subido": subido, "fecha": ahora(), "info": info}
    with lock:
        v = videos()
        # Evitar duplicados de la misma ruta
        for k, e in list(v.items()):
            if e["ruta"] == str(ruta):
                entry["id"] = k
        v[entry["id"]] = entry
        escribir_json(VIDEOS, v)
    return entry


def video_o_404(vid: str) -> dict:
    v = videos().get(vid)
    if not v or not Path(v["ruta"]).exists():
        raise HTTPException(404, "Vídeo no encontrado")
    return v


# ---------------------------------------------------------------- trabajos
_HIST: dict = {}   # id -> [(instante, pct)] para estimar el tiempo restante


def _estimar_restante(tid: str, pct: float, activo: bool) -> int | None:
    """Segundos que faltan, a partir del ritmo de los últimos minutos."""
    if not activo or pct <= 0 or pct >= 100:
        _HIST.pop(tid, None)
        return None
    h = _HIST.setdefault(tid, [])
    ahora_s = time.time()
    if not h or pct > h[-1][1] + 1e-9 or ahora_s - h[-1][0] > 30:
        h.append((ahora_s, pct))
        del h[:-40]
    if len(h) < 2:
        return None
    # Ventana de al menos 90 s para que la estimación no baile
    base = next((p for p in h if ahora_s - p[0] <= 900), h[0])
    dt, dp = ahora_s - base[0], pct - base[1]
    if dt < 90 or dp <= 0.05:
        return None
    return int((100 - pct) * dt / dp)


PESOS = {"normalizar": 5, "analisis": 5, "master": 40, "interpolacion": 10, "escalado_ia": 30,
         "escalado": 5, "acabado": 10, "comparacion": 4}
NOMBRES_ETAPA = {"plan": "Planificando", "normalizar": "Normalización", "analisis": "Análisis", "master": "Limpieza y estabilización",
                 "escalado_ia": "Escalado IA", "escalado": "Escalado", "interpolacion": "Interpolación",
                 "acabado": "Acabado y codificación", "comparacion": "Vídeo comparativo", "diagnostico": "Diagnóstico", "fin": "Terminado"}


def dir_trabajo(tid: str) -> Path:
    return TRABAJOS / tid


def estado(tid: str) -> dict | None:
    return leer_json(dir_trabajo(tid) / "estado.json")


def guardar_estado(tid: str, **cambios) -> dict:
    with lock:
        st = estado(tid)
        if st is None:
            if (dir_trabajo(tid) / "estado.json").exists():
                raise RuntimeError(f"No se pudo leer el estado de {tid}")
            st = {}
        st.update(cambios)
        escribir_json(dir_trabajo(tid) / "estado.json", st)
        return st


def progreso(tid: str, st: dict) -> dict:
    log = dir_trabajo(tid) / "registro.txt"
    etapas: dict[str, tuple[int, int]] = {}
    ultima = None
    comparacion = None
    lineas: list[str] = []
    avisos: list[str] = []
    parcial = 0.0     # avance dentro del bloque que está procesando Real-ESRGAN
    if log.exists():
        with open(log, encoding="utf-8", errors="replace") as fh:
            for line in fh:
                if line.startswith("@@PROGRESO"):
                    _, et, d, t = line.split()
                    etapas[et] = (int(d), int(t))
                    ultima = et
                elif line.startswith("@@COMPARACION"):
                    comparacion = line.split(" ", 1)[1].strip()
                elif line.rstrip().endswith("%") and len(line.strip()) <= 8:
                    try:
                        parcial = float(line.strip().rstrip("%").replace(",", ".")) / 100
                    except ValueError:
                        pass
                elif line.startswith("[aviso]"):
                    avisos.append(line[7:].strip())
                    lineas.append(line.rstrip("\n"))
                else:
                    lineas.append(line.rstrip("\n"))
    if st.get("tipo") in ("diagnostico", "plan"):
        pct = 100.0 if st.get("estado") == "terminado" else 30.0 if st.get("estado") == "en_curso" else 0.0
        etiqueta = "Diagnóstico"
        if st.get("estado") == "en_curso" and "medicion" in etapas:
            d, t = etapas["medicion"]
            pct, etiqueta = 30.0 + 65.0 * d / max(t, 1), "Midiendo la velocidad del equipo"
            paso = next((l.strip(" ·…") for l in reversed(lineas) if l.startswith("  · ")), "")
            try:
                quieto = time.time() - log.stat().st_mtime
            except OSError:
                quieto = 0
            if quieto > 600:
                avisos.append(f"Sin avances desde hace {int(quieto // 60)} min en «{paso or 'medición'}». "
                              "Si sigue así, cancela y vuelve a lanzar; la app omitirá el motor que no responda.")
        return {"pct": pct, "etapa": etiqueta, "registro": lineas[-60:], "comparacion": None,
                "avisos": avisos, "detalle": "", "restante": None}
    esperadas = ["normalizar", "analisis", "master"]
    rec = st.get("receta", {})
    mejora = rec.get("mejora", {})
    if mejora.get("activo"):
        if mejora.get("fps_salida"):
            esperadas.append("interpolacion")
        if int(mejora.get("escala", 1)) > 1:
            ia = mejora.get("_motor_escala") == "realesrgan-ncnn" and float(mejora.get("mezcla_ia", 0)) > 0
            esperadas.append("escalado_ia" if ia else "escalado")
        esperadas.append("acabado")
        if (rec.get("exportar", {}).get("comparacion_seg", -1) or 0) != 0:
            esperadas.append("comparacion")
    total = sum(PESOS[e] for e in esperadas)
    hecho = 0.0
    for e in esperadas:
        if e in etapas:
            d, t = etapas[e]
            frac = (min(1.0, d / t) if t else 0.0)
            if e == ultima and t and parcial > 0 and d < t:
                # El bloque en curso también cuenta: así la barra no parece parada
                frac = min(1.0, (d + parcial * min(60, t - d)) / t)
            hecho += PESOS[e] * frac
    pct = 100.0 if "fin" in etapas else round(100 * hecho / total, 1)
    d_t = etapas.get(ultima or "", (0, 0))
    detalle = f"{d_t[0]}/{d_t[1]}" if d_t[1] and d_t[1] > 1 else ""
    restante = _estimar_restante(st["id"], pct, st.get("estado") == "en_curso")
    return {"pct": pct, "etapa": NOMBRES_ETAPA.get(ultima or "", "En cola" if st.get("estado") == "en_cola" else ""),
            "detalle": detalle, "restante": restante,
            "registro": lineas[-60:], "comparacion": comparacion, "avisos": avisos}


def salidas(st: dict) -> list[dict]:
    if not st.get("salida"):
        return []
    out = Path(st["salida"])
    if not out.is_dir():
        return []
    res = []
    for p in sorted(out.iterdir()):
        if p.is_file() and not p.name.startswith("."):
            res.append({"nombre": p.name, "bytes": p.stat().st_size, "url": f"/archivos/{st['id']}/{p.name}",
                        "video": p.suffix.lower() in {".mp4", ".webm"},
                        "informe": p.suffix.lower() == ".html"})
    return res


class Cola:
    """Dos colas: diagnósticos (ligeros) y procesos (GPU, de uno en uno)."""

    def __init__(self, nombre: str):
        self.nombre = nombre
        self.pendientes: list[str] = []
        self.actual: str | None = None
        self.proc: subprocess.Popen | None = None
        self.cv = threading.Condition()
        threading.Thread(target=self._bucle, daemon=True, name=f"cola-{nombre}").start()

    def poner(self, tid: str) -> None:
        with self.cv:
            self.pendientes.append(tid)
            self.cv.notify()

    def cancelar(self, tid: str) -> bool:
        with self.cv:
            if tid in self.pendientes:
                self.pendientes.remove(tid)
                guardar_estado(tid, estado="cancelado", fin=ahora())
                return True
            if self.actual == tid and self.proc:
                guardar_estado(tid, cancelando=True)
                matar_arbol(self.proc.pid)
                return True
        return False

    def _bucle(self):
        while True:
            with self.cv:
                while not self.pendientes:
                    self.cv.wait()
                tid = self.pendientes.pop(0)
                self.actual = tid
            try:
                self._ejecutar(tid)
            except Exception as exc:  # noqa: BLE001
                guardar_estado(tid, estado="error", error=str(exc), fin=ahora())
            finally:
                with self.cv:
                    self.actual = None
                    self.proc = None

    def _ejecutar(self, tid: str):
        st = estado(tid)
        if not st or st.get("estado") == "cancelado":
            return
        d = dir_trabajo(tid)
        env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8")
        kw = {}
        if IS_WIN:
            kw["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kw["start_new_session"] = True
        guardar_estado(tid, estado="en_curso", inicio=ahora())
        with open(d / "registro.txt", "a", encoding="utf-8") as log:
            log.write(f"[{time.strftime('%H:%M:%S')}] Inicio: {' '.join(st['cmd'][2:])}\n")
            log.flush()
            self.proc = subprocess.Popen(st["cmd"], cwd=str(BASE), stdout=log, stderr=subprocess.STDOUT,
                                         env=env, **kw)
            pidf = RUN / "trabajos" / f"{tid}.pid"
            pidf.write_text(str(self.proc.pid))
            guardar_estado(tid, pid=self.proc.pid)
            rc = self.proc.wait()
            pidf.unlink(missing_ok=True)
        st = estado(tid)
        if st.get("cancelando"):
            guardar_estado(tid, estado="cancelado", fin=ahora(), cancelando=False)
        elif rc == 0:
            extra = {}
            if st["tipo"] == "diagnostico":
                extra["informe"] = leer_json(d / "diagnostico.json")
            guardar_estado(tid, estado="terminado", fin=ahora(), **extra)
        else:
            guardar_estado(tid, estado="error", fin=ahora(), error=f"El proceso terminó con código {rc}")


COLA_DIAG = Cola("diagnostico")
COLA_PROC = Cola("proceso")


def crear_trabajo(tipo: str, video: dict, cmd_fn, salida: Path | None, receta: dict | None,
                  extra: dict | None = None) -> dict:
    """cmd_fn(carpeta_del_trabajo) -> lista de argumentos."""
    tid = time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]
    d = dir_trabajo(tid)
    d.mkdir(parents=True)
    cmd = cmd_fn(d)
    st = {"id": tid, "tipo": tipo, "video": video["id"], "nombre_video": video["nombre"], "estado": "en_cola",
          "creado": ahora(), "cmd": cmd, "salida": str(salida) if salida else "", "receta": receta or {}}
    st.update(extra or {})
    escribir_json(d / "estado.json", st)
    (COLA_DIAG if tipo in ("diagnostico", "plan") else COLA_PROC).poner(tid)
    return st


def recuperar_al_arrancar():
    for d in TRABAJOS.iterdir():
        st = estado(d.name)
        if st and st.get("estado") in ("en_curso", "en_cola"):
            guardar_estado(d.name, estado="interrumpido", fin=ahora(),
                           error="La app se cerró antes de terminar. Puedes relanzarlo (usa la caché).")
    for p in (RUN / "trabajos").glob("*.pid"):
        p.unlink(missing_ok=True)


# ---------------------------------------------------------------- API
@app.get("/", response_class=HTMLResponse)
def inicio():
    return HTMLResponse((BASE / "web" / "index.html").read_text(encoding="utf-8"),
                        headers={"Cache-Control": "no-store"})


def estado_gpu() -> dict:
    """Estado de la tarjeta sin tocar CUDA. No se culpa a nadie por la lista de procesos:
    en Windows nvidia-smi lista también los que solo dibujan la pantalla (C+G)."""
    info = {"resumen": "", "modo": "", "aviso": "", "probada": _PRUEBA.get("ok"), "cuando": _PRUEBA.get("cuando")}
    exe = shutil.which("nvidia-smi") or r"C:\Windows\System32\nvidia-smi.exe"
    try:
        r = subprocess.run([exe, "--query-gpu=compute_mode,memory.used,memory.total,driver_version",
                            "--format=csv,noheader"], capture_output=True, text=True, timeout=15)
        if r.returncode == 0 and r.stdout.strip():
            cm, usada, total, drv = [x.strip() for x in r.stdout.strip().splitlines()[0].split(",")]
            info["modo"] = cm
            info["resumen"] = f"{usada} de {total} · driver {drv}"
    except Exception:  # noqa: BLE001
        return info
    if _PRUEBA.get("ok") is False:
        info["aviso"] = G.diagnostico_gpu() or _PRUEBA.get("texto", "")[-300:]
    return info


_PRUEBA: dict = {"ok": None, "cuando": 0, "texto": ""}


def probar_gpu(forzar: bool = False) -> dict:
    """Prueba real de CUDA en un proceso aparte. Se guarda para no repetirla en cada consulta."""
    if not forzar and _PRUEBA["ok"] is not None and time.time() - _PRUEBA["cuando"] < 600:
        return _PRUEBA
    ok, texto = G.prueba_en_subproceso()
    _PRUEBA.update(ok=ok, cuando=time.time(), texto=texto)
    escribir_json(RUN / "gpu_estado.json", {"ok": ok, "fecha": ahora(), "detalle": texto[-500:]})
    if not ok:
        G.volcado_diagnostico(RUN / "gpu_diagnostico.txt")
    return _PRUEBA


_SISTEMA = None


@app.get("/api/sistema")
def sistema():
    global _SISTEMA
    if _SISTEMA is None:
        try:
            ff = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True).stdout.split("\n")[0]
        except Exception:  # noqa: BLE001
            ff = ""
        _SISTEMA = {
            "procesado": ("GPU " + G.nombre_gpu() if probar_gpu()["ok"] else "CPU"),
            "gpu": bool(probar_gpu()["ok"]),
            "gpu_estado": estado_gpu(),
            "ffmpeg": ff,
            "nvenc": encoder_works("h264_nvenc"),
            "realesrgan": bool(B.realesrgan_bin()),
            "modelos_escala": B.realesrgan_models(),
            "rife": bool(B.rife_bin()),
            "modelos_rife": B.rife_models(),
            "python": sys.version.split()[0],
            "resultados": str(RESULTADOS),
            "puerto": PUERTO,
        }
    return _SISTEMA


@app.post("/api/plan/{vid}")
async def plan_automatico(vid: str, request: Request):
    """Analiza el vídeo, mide este equipo y propone parámetros para el tiempo disponible."""
    v = video_o_404(vid)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        body = {}

    previo = None    # diagnóstico reciente del mismo vídeo: así no se repite el análisis
    for carpeta in sorted(TRABAJOS.iterdir(), reverse=True):
        st = estado(carpeta.name)
        if st and st.get("tipo") == "diagnostico" and st.get("video") == vid and st.get("estado") == "terminado":
            if (carpeta / "diagnostico.json").exists():
                previo = carpeta / "diagnostico.json"
            break

    def cmd(d: Path):
        c = [sys.executable, "-m", "restaura8", "planificar", v["ruta"],
             "--minutos", str(float(body.get("minutos", 60))),
             "--prioridad", str(float(body.get("prioridad", 0.5))),
             "--tope-alto", str(int(body.get("tope_alto", 2160))),
             "--formato", "8mm" if body.get("formato") == "8mm" else "super8",
             "--salida-json", str(d / "plan.json"),
             "--guardar-receta", str(d / "receta.json")]
        if previo:
            c += ["--diagnostico", str(previo)]
        if not body.get("fluidez", True):
            c.append("--sin-fluidez")
        return c
    return crear_trabajo("plan", v, cmd, None, None, {"minutos": body.get("minutos", 60)})


@app.get("/api/plan/{tid}/resultado")
def plan_resultado(tid: str):
    d = dir_trabajo(tid)
    plan = leer_json(d / "plan.json")
    receta = leer_json(d / "receta.json")
    if not plan:
        raise HTTPException(404, "El plan aún no está listo")
    return {"plan": plan, "receta": receta}


@app.post("/api/gpu/diagnostico")
def gpu_diagnostico():
    global _SISTEMA
    _SISTEMA = None
    probar_gpu(forzar=True)
    """Comprueba CUDA en un proceso limpio y guarda el detalle en run\gpu_diagnostico.txt.
    No toca CUDA en el servidor."""
    texto = G.volcado_diagnostico(RUN / "gpu_diagnostico.txt")
    ok = bool(_PRUEBA["ok"])
    return {"ok": ok, "texto": texto, "archivo": str(RUN / "gpu_diagnostico.txt"),
            "estado": estado_gpu(), "remota": G.sesion_remota()}


@app.get("/api/modelos")
def modelos():
    """Modelos PyTorch disponibles (los presentes en herramientas\\modelos y los descargables)."""
    try:
        from restaura8 import torchmodels as TM
        return {"pth": TM.disponibles(), "catalogo": {k: v[1] for k, v in TM.CATALOGO.items() if k != "yunet"},
                "spandrel": B.hay_spandrel()}
    except Exception as exc:  # noqa: BLE001
        return {"pth": [], "catalogo": {}, "spandrel": False, "error": str(exc)}


@app.get("/api/preajustes")
def preajustes():
    return {"defecto": DEFAULT, "preajustes": {n: load_preset(n) for n in ("fiel", "equilibrado", "maximo")}}


@app.get("/api/videos")
def lista_videos():
    v = [e for e in videos().values() if Path(e["ruta"]).exists()]
    return sorted(v, key=lambda e: e["fecha"], reverse=True)


@app.put("/api/subir")
async def subir(request: Request, nombre: str):
    nombre = nombre_seguro(nombre)
    if Path(nombre).suffix.lower() not in EXTENSIONES:
        raise HTTPException(400, f"Formato no admitido: {Path(nombre).suffix}")
    destino = SUBIDAS / f"{time.strftime('%Y%m%d-%H%M%S')}_{nombre}"
    parcial = destino.with_suffix(destino.suffix + ".parcial")
    with open(parcial, "wb") as fh:
        async for chunk in request.stream():
            fh.write(chunk)
    os.replace(parcial, destino)
    try:
        return registrar_video(destino, subido=True)
    except Exception as exc:  # noqa: BLE001
        destino.unlink(missing_ok=True)
        raise HTTPException(400, f"No se puede leer el vídeo: {exc}") from exc


@app.post("/api/ruta")
async def ruta_local(request: Request):
    body = await request.json()
    ruta = Path(str(body.get("ruta", "")).strip().strip('"'))
    if not ruta.is_file():
        raise HTTPException(400, "No existe ese archivo")
    if ruta.suffix.lower() not in EXTENSIONES:
        raise HTTPException(400, f"Formato no admitido: {ruta.suffix}")
    try:
        return registrar_video(ruta.resolve(), subido=False)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, f"No se puede leer el vídeo: {exc}") from exc


@app.delete("/api/videos/{vid}")
def quitar_video(vid: str):
    with lock:
        v = videos()
        e = v.pop(vid, None)
        escribir_json(VIDEOS, v)
    if e and e.get("subido"):
        Path(e["ruta"]).unlink(missing_ok=True)
    return {"ok": True}


# ---------------------------------------------------------------- copias reproducibles
PROXIES = DATOS / "proxies"
PROXIES.mkdir(parents=True, exist_ok=True)
CODECS_WEB = {"h264", "avc1", "vp8", "vp9", "av1"}
_PROXY_EST: dict = {}


def _clave_proxy(ruta: Path) -> str:
    st = ruta.stat()
    return hashlib.sha1(f"{ruta}|{st.st_size}|{int(st.st_mtime)}".encode()).hexdigest()[:16]


def _necesita_proxy(ruta: Path) -> bool:
    """El navegador solo reproduce unos pocos códecs. MPEG-4 parte 2, DV, FFV1 o HEVC no."""
    try:
        i = probe(ruta)
    except Exception:  # noqa: BLE001
        return True
    return i.codec.lower() not in CODECS_WEB or ruta.suffix.lower() not in (".mp4", ".webm", ".m4v", ".mov")


def _generar_proxy(origen: Path, destino: Path, clave: str) -> None:
    """Copia ligera en H.264 a 720p para poder verla en el navegador."""
    tmp = destino.with_suffix(".parcial.mp4")
    codec = (["-c:v", "h264_nvenc", "-preset", "p4", "-cq", "24"] if encoder_works("h264_nvenc")
             else ["-c:v", "libx264", "-crf", "23", "-preset", "veryfast"])
    try:
        run_ffmpeg(["-i", str(origen), "-vf", "scale=-2:min(720\,ih):flags=bicubic", *codec,
                    "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(tmp)])
        os.replace(tmp, destino)
        _PROXY_EST[clave] = {"estado": "listo"}
    except Exception as exc:  # noqa: BLE001
        _PROXY_EST[clave] = {"estado": "error", "detalle": str(exc)[:300]}
        tmp.unlink(missing_ok=True)


def _fuente(ruta: Path, url_directa: str) -> dict:
    """Decide si el navegador puede con el archivo o hay que prepararle una copia."""
    if not ruta.exists():
        raise HTTPException(404, "No existe el archivo")
    if not _necesita_proxy(ruta):
        return {"estado": "listo", "url": url_directa, "convertido": False}
    clave = _clave_proxy(ruta)
    destino = PROXIES / f"{clave}.mp4"
    if destino.exists():
        return {"estado": "listo", "url": f"/api/proxy/{clave}", "convertido": True}
    est = _PROXY_EST.get(clave)
    if not est or est.get("estado") == "error":
        _PROXY_EST[clave] = {"estado": "generando"}
        threading.Thread(target=_generar_proxy, args=(ruta, destino, clave), daemon=True,
                         name=f"proxy-{clave}").start()
    return {"estado": _PROXY_EST[clave]["estado"], "url": f"/api/proxy/{clave}", "convertido": True,
            "detalle": (est or {}).get("detalle", "")}


@app.get("/api/proxy/{clave}")
def proxy(clave: str):
    p = PROXIES / f"{clave}.mp4"
    if not p.is_file():
        raise HTTPException(404, "La copia aún se está preparando")
    return FileResponse(p, content_disposition_type="inline")


@app.get("/api/videos/{vid}/fuente")
def fuente_video(vid: str):
    v = video_o_404(vid)
    return _fuente(Path(v["ruta"]), f"/api/videos/{vid}/archivo")


@app.get("/api/trabajos/{tid}/fuente/{nombre}")
def fuente_salida(tid: str, nombre: str):
    st = estado(tid)
    if not st or not st.get("salida"):
        raise HTTPException(404)
    base = Path(st["salida"]).resolve()
    p = (base / nombre).resolve()
    if base not in p.parents:
        raise HTTPException(404)
    return _fuente(p, f"/archivos/{tid}/{nombre}")


@app.get("/api/videos/{vid}/archivo")
def archivo_video(vid: str):
    """Sirve el vídeo original para poder compararlo en el navegador (admite saltos)."""
    v = video_o_404(vid)
    p = Path(v["ruta"])
    return FileResponse(p, filename=p.name, content_disposition_type="inline")


@app.get("/api/videos/{vid}/miniatura")
def miniatura(vid: str, t: float = 1.0):
    v = video_o_404(vid)
    r = subprocess.run(["ffmpeg", "-v", "error", "-ss", str(max(0.0, t)), "-i", v["ruta"], "-frames:v", "1",
                        "-vf", "scale=-2:360", "-f", "image2", "-c:v", "mjpeg", "-q:v", "4", "-"],
                       capture_output=True)
    if r.returncode != 0 or not r.stdout:
        raise HTTPException(500, "No se pudo extraer el fotograma")
    return Response(r.stdout, media_type="image/jpeg", headers={"Cache-Control": "max-age=3600"})


@app.post("/api/diagnosticar/{vid}")
async def diagnosticar(vid: str, request: Request):
    v = video_o_404(vid)
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        body = {}
    formato = "8mm" if body.get("formato") == "8mm" else "super8"

    def cmd(d: Path):
        return [sys.executable, "-m", "restaura8", "diagnosticar", v["ruta"], "--formato", formato,
                "--salida-json", str(d / "diagnostico.json")]
    return crear_trabajo("diagnostico", v, cmd, None, None, {"formato": formato})


def carpeta_resultado(v: dict, tipo: str) -> Path:
    base = RESULTADOS / ("muestras" if tipo == "muestra" else "")
    return base / f"{Path(v['nombre']).stem}_{time.strftime('%Y%m%d-%H%M%S')}"


@app.post("/api/procesar/{vid}")
async def procesar(vid: str, request: Request):
    v = video_o_404(vid)
    body = await request.json()
    tipo = body.get("tipo", "completo")
    receta = body.get("receta") or load_preset("equilibrado")
    salida = carpeta_resultado(v, tipo)
    salida.mkdir(parents=True, exist_ok=True)
    receta_path = salida / "receta_entrada.json"
    escribir_json(receta_path, receta)
    receta = dict(receta)
    receta["mejora"] = dict(receta.get("mejora", {}))
    try:
        receta["mejora"]["_motor_escala"] = B.resolve_upscaler(receta["mejora"].get("motor_escala", "auto"))
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, str(exc)) from exc
    trabajo_dir = DATOS / "cache" / v["id"]
    if tipo == "muestra":
        inicio = str(body.get("inicio", "0"))
        dur = float(body.get("duracion", 10))
        cmd = [sys.executable, "-m", "restaura8", "muestra", v["ruta"], "-o", str(salida),
               "--receta", str(receta_path), "--inicio", inicio, "--duracion", str(dur)]
        # ojo: 'inicio' lo usa el estado del trabajo para la hora de arranque
        extra = {"inicio_muestra": inicio, "duracion": dur}
    else:
        cmd = [sys.executable, "-m", "restaura8", "restaurar", v["ruta"], "-o", str(salida),
               "--receta", str(receta_path), "--trabajo", str(trabajo_dir)]
        extra = {}
    return crear_trabajo(tipo, v, lambda d: cmd, salida, receta, extra)


@app.get("/api/trabajos")
def lista_trabajos():
    res = []
    for d in sorted(TRABAJOS.iterdir(), reverse=True)[:60]:
        st = estado(d.name)
        if not st:
            continue
        p = progreso(d.name, st)
        res.append({k: st.get(k) for k in ("id", "tipo", "video", "nombre_video", "estado", "creado", "inicio",
                                            "fin", "error", "salida")}
                   | {"pct": p["pct"], "etapa": p["etapa"], "detalle": p["detalle"], "restante": p["restante"]})
    return res


@app.get("/api/trabajos/{tid}")
def detalle(tid: str):
    st = estado(tid)
    if not st:
        raise HTTPException(404, "Trabajo no encontrado")
    p = progreso(tid, st)
    comp = None
    if p["comparacion"] and Path(p["comparacion"]).exists():
        comp = f"/archivos/{tid}/{Path(p['comparacion']).name}"
    out = {k: v for k, v in st.items() if k not in ("cmd",)}
    if st.get("tipo") == "muestra" and st.get("estado") == "terminado":
        inf = leer_json(Path(st.get("salida", ".")) / f"{Path(st.get('nombre_video', '')).stem}_fragmento_informe.json")
        v = videos().get(st.get("video", ""), {})
        dur_total = (v.get("info") or {}).get("duracion")
        dur_muestra = float(st.get("duracion") or 0)
        if inf and dur_total and dur_muestra > 0:
            out["segundos_total"] = inf.get("segundos")
            out["estimado_completo"] = int(inf.get("segundos", 0) * dur_total / dur_muestra)
    out.update(pct=p["pct"], etapa=p["etapa"], registro=p["registro"], comparacion=comp,
               salidas=salidas(st), avisos=p["avisos"], detalle=p["detalle"], restante=p["restante"])
    return out


@app.post("/api/trabajos/{tid}/cancelar")
def cancelar(tid: str):
    ok = COLA_PROC.cancelar(tid) or COLA_DIAG.cancelar(tid)
    return {"ok": ok}


@app.post("/api/trabajos/{tid}/relanzar")
def relanzar(tid: str):
    st = estado(tid)
    if not st or st.get("estado") in ("en_cola", "en_curso"):
        raise HTTPException(400, "No se puede relanzar")
    guardar_estado(tid, estado="en_cola", error=None, fin=None)
    with open(dir_trabajo(tid) / "registro.txt", "a", encoding="utf-8") as fh:
        fh.write(f"\n[{time.strftime('%H:%M:%S')}] --- Relanzado ---\n")
    (COLA_DIAG if st["tipo"] == "diagnostico" else COLA_PROC).poner(tid)
    return {"ok": True}


@app.delete("/api/trabajos/{tid}")
def borrar_trabajo(tid: str):
    st = estado(tid)
    if st and st.get("estado") in ("en_cola", "en_curso"):
        raise HTTPException(400, "Cancélalo antes de borrarlo")
    shutil.rmtree(dir_trabajo(tid), ignore_errors=True)
    return {"ok": True}


@app.post("/api/trabajos/{tid}/abrir")
def abrir_carpeta(tid: str):
    st = estado(tid)
    if not st or not st.get("salida"):
        raise HTTPException(404, "Sin carpeta de resultados")
    carpeta = Path(st["salida"])
    if IS_WIN:
        os.startfile(str(carpeta))  # type: ignore[attr-defined]
    else:
        subprocess.Popen(["xdg-open", str(carpeta)])
    return {"ok": True}


@app.get("/archivos/{tid}/{nombre}")
def archivo(tid: str, nombre: str):
    st = estado(tid)
    if not st or not st.get("salida"):
        raise HTTPException(404)
    base = Path(st["salida"]).resolve()
    p = (base / nombre).resolve()
    if base not in p.parents or not p.is_file():
        raise HTTPException(404)
    return FileResponse(p, filename=p.name, content_disposition_type="inline")


def al_arrancar():
    recuperar_al_arrancar()
    threading.Thread(target=probar_gpu, daemon=True, name="prueba-gpu").start()
    (RUN / "servidor.pid").write_text(str(os.getpid()))
    (RUN / "servidor.puerto").write_text(str(PUERTO))


def al_parar():
    for c in (COLA_PROC, COLA_DIAG):
        if c.proc:
            matar_arbol(c.proc.pid)
    (RUN / "servidor.pid").unlink(missing_ok=True)


@app.get("/api/salud")
def salud():
    return JSONResponse({"ok": True, "pid": os.getpid()})


if __name__ == "__main__":
    _espejar_salida()
    print(f"Restaurador Super 8 en http://127.0.0.1:{PUERTO}  (cierra esta ventana para detenerlo)", flush=True)
    print(f"Python {sys.version.split()[0]} · {sys.executable}", flush=True)
    try:
        import uvicorn
    except Exception as exc:  # noqa: BLE001
        print(f"ERROR: falta uvicorn en el entorno ({exc}). Ejecuta scripts\\instalar.ps1", flush=True)
        raise
    try:
        uvicorn.run(app, host="127.0.0.1", port=PUERTO, log_level="info", access_log=False)
    except OSError as exc:
        print(f"ERROR: no se pudo abrir el puerto {PUERTO}: {exc}", flush=True)
        raise
    except Exception:
        import traceback
        traceback.print_exc()
        raise
